-- ========================================
-- ALL-IN-ONE FIX - Creates Tables + Fixes RLS
-- Copy this ENTIRE script and run in Supabase SQL Editor
-- This will work even if you haven't created tables yet!
-- ========================================

-- Step 1: Create tables (if they don't exist)
-- ========================================

CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT DEFAULT 'user',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.honeypots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.decoy_environments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]'::jsonb,
  files JSONB DEFAULT '[]'::jsonb,
  services TEXT[] DEFAULT '{}'::text[],
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.attack_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT,
  attack_type TEXT NOT NULL,
  severity TEXT DEFAULT 'low',
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);


-- Step 2: Enable RLS on all tables
-- ========================================

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attack_logs ENABLE ROW LEVEL SECURITY;


-- Step 3: Drop ALL existing policies (clean slate)
-- ========================================

-- Users table
DROP POLICY IF EXISTS "Users can view own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;
DROP POLICY IF EXISTS "Enable insert for users" ON public.users;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.users;
DROP POLICY IF EXISTS "Allow all access to users" ON public.users;

-- Honeypots table
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON public.honeypots;
DROP POLICY IF EXISTS "Enable all for honeypots" ON public.honeypots;
DROP POLICY IF EXISTS "Allow all access to honeypots" ON public.honeypots;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON public.honeypots;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.honeypots;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.honeypots;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.honeypots;

-- Decoy Environments table
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON public.decoy_environments;
DROP POLICY IF EXISTS "Enable all for decoy_environments" ON public.decoy_environments;
DROP POLICY IF EXISTS "Allow all access to decoy_environments" ON public.decoy_environments;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON public.decoy_environments;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.decoy_environments;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.decoy_environments;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.decoy_environments;

-- Attack Logs table
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON public.attack_logs;
DROP POLICY IF EXISTS "Enable all for attack_logs" ON public.attack_logs;
DROP POLICY IF EXISTS "Allow all access to attack_logs" ON public.attack_logs;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON public.attack_logs;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON public.attack_logs;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON public.attack_logs;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON public.attack_logs;


-- Step 4: Create NEW simple policies (allow authenticated + anon)
-- ========================================

-- Users table policies
CREATE POLICY "Users can view own data" 
ON public.users FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update own data" 
ON public.users FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Enable insert for users" 
ON public.users FOR INSERT 
WITH CHECK (true);

-- Honeypots - Allow ALL for authenticated OR anon
CREATE POLICY "Allow all access to honeypots"
ON public.honeypots
FOR ALL
TO public
USING (true)
WITH CHECK (true);

-- Decoy Environments - Allow ALL for authenticated OR anon
CREATE POLICY "Allow all access to decoy_environments"
ON public.decoy_environments
FOR ALL
TO public
USING (true)
WITH CHECK (true);

-- Attack Logs - Allow ALL for authenticated OR anon
CREATE POLICY "Allow all access to attack_logs"
ON public.attack_logs
FOR ALL
TO public
USING (true)
WITH CHECK (true);


-- Step 5: Grant permissions to anon and authenticated roles
-- ========================================

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON public.honeypots TO anon, authenticated;
GRANT ALL ON public.decoy_environments TO anon, authenticated;
GRANT ALL ON public.attack_logs TO anon, authenticated;
GRANT ALL ON public.users TO anon, authenticated;


-- Step 6: Verify setup
-- ========================================

DO $$
DECLARE
  honeypot_count INTEGER;
  decoy_count INTEGER;
  attack_count INTEGER;
BEGIN
  -- Count existing records
  SELECT COUNT(*) INTO honeypot_count FROM public.honeypots;
  SELECT COUNT(*) INTO decoy_count FROM public.decoy_environments;
  SELECT COUNT(*) INTO attack_count FROM public.attack_logs;
  
  -- Display results
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
  RAISE NOTICE '✅ SETUP COMPLETE!';
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
  RAISE NOTICE '';
  RAISE NOTICE '📊 Tables created:';
  RAISE NOTICE '   ✅ users';
  RAISE NOTICE '   ✅ honeypots';
  RAISE NOTICE '   ✅ decoy_environments';
  RAISE NOTICE '   ✅ attack_logs';
  RAISE NOTICE '';
  RAISE NOTICE '🔐 RLS Policies: ACTIVE';
  RAISE NOTICE '   ✅ Anon access: ENABLED';
  RAISE NOTICE '   ✅ Authenticated access: ENABLED';
  RAISE NOTICE '';
  RAISE NOTICE '📈 Current data:';
  RAISE NOTICE '   • Honeypots: %', honeypot_count;
  RAISE NOTICE '   • Decoy Environments: %', decoy_count;
  RAISE NOTICE '   • Attack Logs: %', attack_count;
  RAISE NOTICE '';
  RAISE NOTICE '🎯 Next step:';
  RAISE NOTICE '   1. Go to your app';
  RAISE NOTICE '   2. Click "Seed Database" button';
  RAISE NOTICE '   3. Watch the magic happen! ✨';
  RAISE NOTICE '';
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
END $$;
