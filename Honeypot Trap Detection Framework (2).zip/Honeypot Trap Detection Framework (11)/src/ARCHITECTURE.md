# 🏗️ System Architecture

Complete architecture overview of the Honeypot Defense Grid.

---

## 🎯 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER'S BROWSER                          │
│                     (Chrome, Firefox, etc.)                     │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ HTTPS (Production)
                             │ HTTP (Development)
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                    FRONTEND APPLICATION                         │
│                  React + TypeScript + Vite                      │
│                  http://localhost:5173                          │
│                                                                  │
│  Components:                                                     │
│  ├─ LandingPage.tsx      (Marketing page)                      │
│  ├─ AuthPage.tsx         (Login/Register + 2FA)                │
│  ├─ Dashboard            (Main application)                     │
│  │  ├─ ThreatMap.tsx     (3D attack visualization)             │
│  │  ├─ ThreatFeed.tsx    (Real-time threat stream)             │
│  │  ├─ AttackChart.tsx   (Analytics graphs)                    │
│  │  ├─ DecoyEnvironments (Fake systems display)                │
│  │  ├─ HoneypotStatus    (Active honeypots)                    │
│  │  └─ CommandLog        (Captured commands)                   │
│  │                                                               │
│  Services:                                                       │
│  ├─ api.ts               (Backend communication)                │
│  ├─ totp.ts              (2FA client-side)                     │
│  └─ mockBackend.ts       (Deprecated - now using real backend) │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ REST API Calls
                             │ Authorization: Bearer <JWT>
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                      BACKEND API SERVER                         │
│                  Node.js + Express.js                           │
│                  http://localhost:5000                          │
│                                                                  │
│  Middleware:                                                     │
│  ├─ CORS                 (Cross-origin security)                │
│  ├─ Helmet               (Security headers)                     │
│  ├─ Rate Limiter         (DDoS protection)                     │
│  ├─ JWT Auth             (Token verification)                   │
│  └─ Request Logger       (Audit trail)                         │
│                                                                  │
│  Routes:                                                         │
│  ├─ /api/auth            (Authentication + 2FA)                 │
│  │   ├─ POST /register                                          │
│  │   ├─ POST /login                                             │
│  │   ├─ POST /setup-2fa                                         │
│  │   ├─ POST /verify-2fa                                        │
│  │   └─ POST /verify-setup                                      │
│  │                                                               │
│  ├─ /api/honeypots       (Honeypot management)                 │
│  │   ├─ GET /            (List all)                             │
│  │   ├─ POST /           (Create new)                           │
│  │   ├─ PUT /:id         (Update)                               │
│  │   └─ DELETE /:id      (Remove)                               │
│  │                                                               │
│  ├─ /api/decoys          (Decoy environments)                  │
│  │   ├─ GET /            (List all fake systems)                │
│  │   ├─ POST /           (Create new decoy)                     │
│  │   ├─ PUT /:id         (Update decoy)                         │
│  │   └─ DELETE /:id      (Remove decoy)                         │
│  │                                                               │
│  ├─ /api/attacks         (Attack logs)                         │
│  │   ├─ GET /            (List attacks)                         │
│  │   ├─ GET /stats       (Statistics)                           │
│  │   └─ POST /           (Log new attack)                       │
│  │                                                               │
│  ├─ /api/threats         (Threat intelligence)                 │
│  │   ├─ GET /            (Threat feed)                          │
│  │   └─ GET /stats       (Threat stats)                         │
│  │                                                               │
│  └─ /api/health          (System status)                        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ Mongoose ODM
                             │ (Object-Document Mapping)
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                      MONGODB ATLAS                              │
│            cluster0.15rkrdo.mongodb.net                         │
│            Database: honeypot-defense                           │
│                                                                  │
│  Collections:                                                    │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ users                                                      │  │
│  │ ├─ _id: ObjectId                                          │  │
│  │ ├─ username: String (unique)                              │  │
│  │ ├─ email: String (unique)                                 │  │
│  │ ├─ password: String (bcrypt hashed)                       │  │
│  │ ├─ totpSecret: String (encrypted)                         │  │
│  │ ├─ is2FAVerified: Boolean                                 │  │
│  │ └─ role: String                                            │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ honeypots                                                  │  │
│  │ ├─ _id: ObjectId                                          │  │
│  │ ├─ name: String                                            │  │
│  │ ├─ type: String (SSH, HTTP, FTP, etc.)                    │  │
│  │ ├─ protocol: String                                        │  │
│  │ ├─ port: Number                                            │  │
│  │ ├─ status: String (active/inactive)                       │  │
│  │ ├─ location: String                                        │  │
│  │ ├─ attackCount: Number                                     │  │
│  │ └─ lastActivity: Date                                      │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ decoyenvironments                                          │  │
│  │ ├─ _id: ObjectId                                          │  │
│  │ ├─ name: String                                            │  │
│  │ ├─ type: String (database, fileserver, etc.)             │  │
│  │ ├─ credentials: Array                                      │  │
│  │ │  ├─ username: String (FAKE!)                            │  │
│  │ │  ├─ password: String (FAKE!)                            │  │
│  │ │  └─ accessLevel: String                                 │  │
│  │ ├─ files: Array                                            │  │
│  │ │  ├─ name: String (bait files)                           │  │
│  │ │  ├─ type: String                                         │  │
│  │ │  ├─ size: String                                         │  │
│  │ │  └─ isBait: Boolean                                      │  │
│  │ ├─ services: Array                                         │  │
│  │ └─ accessCount: Number                                     │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ attacklogs                                                 │  │
│  │ ├─ _id: ObjectId                                          │  │
│  │ ├─ sourceIp: String                                        │  │
│  │ ├─ targetHoneypot: String                                 │  │
│  │ ├─ attackType: String                                      │  │
│  │ ├─ severity: String                                        │  │
│  │ ├─ protocol: String                                        │  │
│  │ ├─ payload: String (captured attack data)                 │  │
│  │ ├─ location: Object                                        │  │
│  │ │  ├─ country: String                                      │  │
│  │ │  ├─ city: String                                         │  │
│  │ │  ├─ lat: Number                                          │  │
│  │ │  └─ lon: Number                                          │  │
│  │ ├─ timestamp: Date                                         │  │
│  │ └─ blocked: Boolean                                        │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔐 Authentication Flow

```
┌─────────┐
│ Browser │
└────┬────┘
     │
     │ 1. POST /api/auth/register
     │    { username, email, password }
     ▼
┌─────────────┐
│   Backend   │──────► Hash password with bcrypt
└─────┬───────┘       Save to MongoDB
      │
      │ 2. Return userId
      ▼
┌─────────┐
│ Browser │──────► Show 2FA setup page
└────┬────┘
     │
     │ 3. POST /api/auth/setup-2fa
     │    { userId }
     ▼
┌─────────────┐
│   Backend   │──────► Generate TOTP secret
└─────┬───────┘       Create QR code
      │               Save secret to MongoDB
      │
      │ 4. Return QR code + secret
      ▼
┌─────────┐
│ Browser │──────► User scans QR with Google Authenticator
└────┬────┘
     │
     │ 5. POST /api/auth/verify-setup
     │    { userId, code }
     ▼
┌─────────────┐
│   Backend   │──────► Verify TOTP code
└─────┬───────┘       Mark 2FA as verified
      │               Generate JWT token
      │
      │ 6. Return JWT token
      ▼
┌─────────┐
│ Browser │──────► Store token in sessionStorage
└────┬────┘       Redirect to dashboard
     │
     │ 7. All API requests include:
     │    Authorization: Bearer <JWT>
     ▼
┌─────────────┐
│   Backend   │──────► Verify JWT
└─────┬───────┘       Check expiration
      │               Allow/deny request
      │
      ▼
   Success!
```

---

## 🎭 Decoy Environment Strategy

The system creates fake environments to mislead attackers:

```
Real Security System                Fake Honeypot System
─────────────────                  ────────────────────

Production Database    ✅ Real     Production Database    ❌ FAKE
├─ Real credentials                ├─ admin/admin123      ← TRAP!
├─ Actual customer data            ├─ Fake customer data  ← BAIT!
└─ Protected access                └─ Easy to "hack"      ← TRAP!

Corporate File Server  ✅ Real     Corporate File Server  ❌ FAKE
├─ Real passwords                  ├─ Password123!        ← TRAP!
├─ Actual documents                ├─ company_secrets.doc ← BAIT!
└─ Encrypted                       └─ Unencrypted         ← TRAP!

Git Repository        ✅ Real     Git Repository         ❌ FAKE
├─ Real API keys                   ├─ .env file           ← BAIT!
├─ Actual source code              ├─ aws_credentials.txt ← BAIT!
└─ Private                         └─ Public              ← TRAP!
```

**When an attacker accesses the fake system:**
1. ✅ Access is logged to MongoDB
2. ✅ IP address is captured
3. ✅ Attack type is identified
4. ✅ Alert is triggered
5. ✅ Real system remains protected

---

## 📊 Data Flow

### Creating a Honeypot

```
┌─────────────┐     POST /api/honeypots      ┌──────────┐
│  Dashboard  │────────────────────────────►  │ Backend  │
│  (React)    │  { name, type, port, ... }    │ (Node.js)│
└─────────────┘                               └────┬─────┘
                                                   │
                                                   │ Validate data
                                                   │ Create document
                                                   ▼
                                              ┌──────────┐
                                              │ MongoDB  │
                                              │ Insert   │
                                              └────┬─────┘
                                                   │
                                                   │ Return new honeypot
                                                   ▼
┌─────────────┐         Success!             ┌────���─────┐
│  Dashboard  │◄────────────────────────────│ Backend  │
│  Updates UI │  { success, honeypot }       │          │
└─────────────┘                               └──────────┘
```

### Viewing Attack Logs

```
┌─────────────┐     GET /api/attacks         ┌──────────┐
│  Dashboard  │────────────────────────────►  │ Backend  │
│             │  Authorization: Bearer <JWT>  │          │
└─────────────┘                               └────┬─────┘
                                                   │
                                                   │ Verify JWT
                                                   │ Query database
                                                   ▼
                                              ┌──────────┐
                                              │ MongoDB  │
                                              │ Find all │
                                              └────┬─────┘
                                                   │
                                                   │ Return 200 attacks
                                                   ▼
┌─────────────┐      { attacks: [...] }      ┌──────────┐
│  Dashboard  │◄────────────────────────────│ Backend  │
│  Renders    │                               │          │
│  ThreatMap  │                               └──────────┘
│  AttackChart│
└─────────────┘
```

---

## 🛡️ Security Layers

```
Layer 1: Network Security
├─ MongoDB Atlas IP Whitelist
├─ HTTPS/TLS encryption (production)
└─ Rate limiting (100 requests/15 min)

Layer 2: Authentication
├─ Password hashing (bcrypt, 12 rounds)
├─ JWT tokens (signed, time-limited)
└─ Mandatory 2FA (TOTP)

Layer 3: Authorization
├─ JWT verification on all protected routes
├─ Role-based access control
└─ Session management

Layer 4: Input Validation
├─ Request body validation
├─ SQL injection prevention (Mongoose)
├─ XSS prevention (sanitization)
└─ CSRF protection

Layer 5: Security Headers
├─ Helmet middleware
├─ CORS policy
├─ Content Security Policy
└─ X-Frame-Options

Layer 6: Monitoring
├─ Request logging
├─ Error tracking
├─ Attack detection
└─ Anomaly alerts
```

---

## 🔄 State Management

```
Frontend State:
├─ currentPage: 'landing' | 'auth' | 'dashboard'
├─ authToken: string (in sessionStorage)
├─ user: { id, username, email, role }
├─ honeypots: Array<Honeypot>
├─ decoys: Array<DecoyEnvironment>
├─ attacks: Array<AttackLog>
└─ threats: Array<Threat>

Backend State:
├─ MongoDB connection pool
├─ Active JWT tokens (in memory)
├─ Rate limit counters
└─ Session data
```

---

## 🌐 Deployment Architecture (Production)

```
┌────────────────────────────────────────────────────────┐
│                    CDN (Cloudflare)                    │
│              Caches static assets                       │
└─────────────────────┬──────────────────────────────────┘
                      │
                      │ HTTPS
                      ▼
┌────────────────────────────────────────────────────────┐
│              Frontend (Vercel/Netlify)                 │
│         Static React build                              │
│         https://honeypot-defense.app                    │
└─────────────────────┬──────────────────────────────────┘
                      │
                      │ API calls
                      ▼
┌────────────────────────────────────────────────────────┐
│         Backend API (Render/Railway/Fly.io)            │
│         Node.js + Express                               │
│         https://api.honeypot-defense.app                │
└─────────────────────┬──────────────────────────────────┘
                      │
                      │ Mongoose
                      ▼
┌────────────────────────────────────────────────────────┐
│               MongoDB Atlas (Cloud)                     │
│         Hosted database cluster                         │
│         Automatic backups                               │
│         Replica sets                                    │
└────────────────────────────────────────────────────────┘
```

---

## 📈 Scalability

### Current Setup (Development)
- ✅ Single backend instance
- ✅ MongoDB Atlas (cloud)
- ✅ Suitable for testing and development

### Production Scaling
- 🚀 Multiple backend instances (load balancer)
- 🚀 MongoDB sharding (horizontal scaling)
- 🚀 Redis cache (session management)
- 🚀 Message queue (async processing)
- 🚀 CDN (static assets)
- 🚀 WebSocket server (real-time updates)

---

## 🔧 Technology Stack

### Frontend
- **Framework**: React 18
- **Language**: TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS v4
- **UI Components**: shadcn/ui
- **Animation**: Motion (Framer Motion)
- **Charts**: Recharts
- **Icons**: Lucide React
- **HTTP Client**: Fetch API
- **State**: React Hooks
- **Routing**: React Router (future)

### Backend
- **Runtime**: Node.js 18+
- **Framework**: Express.js
- **Database**: MongoDB (Mongoose ODM)
- **Authentication**: JWT + bcrypt
- **2FA**: Speakeasy (TOTP)
- **Security**: Helmet, CORS, Rate Limit
- **QR Codes**: qrcode library
- **Logging**: Morgan
- **Compression**: Compression middleware

### Database
- **Type**: NoSQL Document Store
- **Provider**: MongoDB Atlas
- **ORM**: Mongoose
- **Collections**: 4 (users, honeypots, decoys, attacks)
- **Indexes**: Username, email, timestamps
- **Backups**: Automatic (Atlas)

---

## 📊 Performance Metrics

### Target Performance
- Frontend load time: < 2s
- API response time: < 100ms
- Database query time: < 50ms
- WebSocket latency: < 100ms
- 2FA verification: < 1s

### Optimization Strategies
- ✅ Database indexing
- ✅ Response compression
- ✅ Asset minification
- ✅ Code splitting
- ✅ Lazy loading
- ✅ Caching (future)

---

**System designed for maximum deception and minimal detection time!** 🎭🛡️
