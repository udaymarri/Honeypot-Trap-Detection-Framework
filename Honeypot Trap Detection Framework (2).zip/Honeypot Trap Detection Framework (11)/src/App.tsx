import { useState } from 'react';
import { Shield, Menu, Bell, Settings, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { ThreatStats } from './components/ThreatStats';
import { ThreatFeed } from './components/ThreatFeed';
import { AttackChart } from './components/AttackChart';
import { ThreatMap } from './components/ThreatMap';
import { CommandLog } from './components/CommandLog';
import { HoneypotStatus } from './components/HoneypotStatus';
import { AlertBanner } from './components/AlertBanner';
import { MatrixBackground } from './components/MatrixBackground';
import { NotificationPanel } from './components/NotificationPanel';
import { AddHoneypotDialog } from './components/AddHoneypotDialog';
import { AttackSummary } from './components/AttackSummary';
import { SettingsDialog } from './components/SettingsDialog';
import { DecoyEnvironments } from './components/DecoyEnvironments';
import { DatabaseSeeder } from './components/DatabaseSeeder';
import { Button } from './components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './components/ui/dropdown-menu';
import { Toaster } from './components/ui/sonner';
import { SessionStorage } from './services/mockBackend';

type PageState = 'landing' | 'auth' | 'dashboard';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageState>('landing');
  const [notificationCount] = useState(20);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Show landing page
  if (currentPage === 'landing') {
    return <LandingPage onGetStarted={() => setCurrentPage('auth')} />;
  }

  // Show auth page
  if (currentPage === 'auth') {
    return (
      <AuthPage 
        onAuthenticated={() => setCurrentPage('dashboard')} 
        onBack={() => setCurrentPage('landing')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      {/* Matrix rain background */}
      <MatrixBackground />

      {/* Alert banner */}
      <AlertBanner />

      {/* Notification panel */}
      <NotificationPanel 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />

      {/* Settings dialog */}
      <SettingsDialog 
        open={showSettings} 
        onOpenChange={setShowSettings} 
      />

      {/* Toast notifications */}
      <Toaster />

      {/* Main container */}
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              {/* Logo and title */}
              <div className="flex items-center gap-3">
                <motion.div
                  className="relative"
                  animate={{ 
                    rotate: [0, 360],
                    scale: [1, 1.1, 1],
                  }}
                  transition={{ 
                    rotate: { duration: 20, repeat: Infinity, ease: 'linear' },
                    scale: { duration: 2, repeat: Infinity },
                  }}
                >
                  <Shield className="w-8 h-8 text-primary" />
                  <div className="absolute inset-0 blur-lg bg-primary opacity-50" />
                </motion.div>
                <div>
                  <h1 className="text-2xl font-mono tracking-tight">
                    <span className="text-primary">HONEYPOT</span>
                    <span className="text-muted-foreground"> // </span>
                    <span>DEFENSE GRID</span>
                  </h1>
                  <p className="text-xs text-muted-foreground font-mono">
                    Cyber Deception & Intrusion Analysis System
                  </p>
                </div>
              </div>

              {/* Right section */}
              <div className="flex items-center gap-4">
                {/* Status indicator */}
                <div className="hidden md:flex items-center gap-2 px-3 py-2 bg-muted/50 rounded-lg border border-border">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                    <span className="text-xs font-mono text-muted-foreground">SYSTEM ACTIVE</span>
                  </div>
                  <div className="w-px h-4 bg-border mx-2" />
                  <span className="text-xs font-mono text-foreground">
                    {new Date().toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                {/* Add Honeypot */}
                <div className="hidden lg:block">
                  <AddHoneypotDialog />
                </div>

                {/* Notifications */}
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="relative"
                  onClick={() => setShowNotifications(true)}
                >
                  <Bell className="w-5 h-5" />
                  {notificationCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground rounded-full text-xs flex items-center justify-center">
                      {notificationCount}
                    </span>
                  )}
                </Button>

                {/* Settings */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <Settings className="w-5 h-5" />
                      <ChevronDown className="w-4 h-4 ml-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuLabel className="font-mono">Admin Panel</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setShowSettings(true)}>
                      Configure Honeypots
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowSettings(true)}>
                      Alert Settings
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowSettings(true)}>
                      Export Logs
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowSettings(true)}>
                      System Reports
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="text-destructive"
                      onClick={() => {
                        SessionStorage.clearToken();
                        setCurrentPage('landing');
                      }}
                    >
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                {/* Mobile menu */}
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="p-6 space-y-6">
          {/* Stats cards */}
          <ThreatStats />

          {/* Main grid and Attack Chart - no gap */}
          <div className="space-y-0">
            {/* Main grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start mb-6">
              {/* Left column - Threat map */}
              <div className="lg:col-span-2">
                <ThreatMap />
              </div>

              {/* Right column - Threat feed and summary */}
              <div className="flex flex-col gap-6">
                <div className="h-[500px] flex-shrink-0">
                  <ThreatFeed />
                </div>
                <div className="h-[350px]">
                  <AttackSummary />
                </div>
              </div>
            </div>

            {/* Full width Attack Chart - no top gap */}
            <div className="h-[400px]">
              <AttackChart />
            </div>
          </div>

          {/* Decoy Environments Section */}
          <div className="w-full">
            <DecoyEnvironments />
          </div>

          {/* Bottom grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Command log */}
            <div className="h-[500px] lg:col-span-2">
              <CommandLog />
            </div>

            {/* Right column - Database Seeder */}
            <div>
              <DatabaseSeeder />
            </div>
          </div>

          {/* Honeypot Status */}
          <div className="h-[500px]">
            <HoneypotStatus />
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-border bg-card/80 backdrop-blur-sm mt-12">
          <div className="px-6 py-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="text-xs text-muted-foreground font-mono">
                <span className="text-primary">HONEYPOT TRAP DETECTION FRAMEWORK</span>
                <span className="mx-2">//</span>
                <span>v2.4.1</span>
                <span className="mx-2">|</span>
                <span>© 2025 Cyber Defense Systems</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
                <span>Deception is the new defense.</span>
                <span className="hidden md:inline">|</span>
                <span className="hidden md:inline">Catch the hacker before the hack.</span>
              </div>
            </div>
          </div>
        </footer>
      </div>

      {/* Scanline overlay effect */}
      <div 
        className="fixed inset-0 pointer-events-none z-50 opacity-10"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 255, 0.8) 2px, rgba(0, 255, 255, 0.8) 4px)',
          animation: 'scan 8s linear infinite',
        }}
      />

      <style>
        {`
          @keyframes scan {
            0% { transform: translateY(0); }
            100% { transform: translateY(10px); }
          }
          
          .scrollbar-thin::-webkit-scrollbar {
            width: 6px;
          }
          
          .scrollbar-thin::-webkit-scrollbar-track {
            background: rgba(0, 255, 255, 0.1);
            border-radius: 3px;
          }
          
          .scrollbar-thin::-webkit-scrollbar-thumb {
            background: rgba(0, 255, 255, 0.3);
            border-radius: 3px;
          }
          
          .scrollbar-thin::-webkit-scrollbar-thumb:hover {
            background: rgba(0, 255, 255, 0.5);
          }
        `}
      </style>
    </div>
  );
}
