# 🍯 Honeypot Backend Implementation Guide

## Overview

This project implements a **comprehensive mock backend** that simulates a Node.js + TypeScript + MongoDB system with full authentication, 2FA (TOTP + Email OTP), and honeypot fake data environment.

## 🏗️ Architecture

### Mock Backend Stack
- **Language**: TypeScript (simulated)
- **Database**: MongoDB with Mongoose (simulated in-memory)
- **Authentication**: JWT sessions (localStorage-based)
- **2FA Methods**: 
  - TOTP (Time-based One-Time Password) via speakeasy simulation
  - Email OTP (fallback method)
- **Honeypot System**: Fake accounts with realistic data

---

## 📁 File Structure

```
/services/
├── mockBackend.ts      # Main backend API simulation
└── totp.ts            # TOTP implementation (speakeasy alternative)

/components/
└── AuthPage.tsx       # Integrated authentication UI
└── HoneypotStats.tsx  # Dashboard honeypot statistics
```

---

## 🔐 Authentication Flow

### 1. **Registration (Sign Up)** - 2FA MANDATORY

```typescript
await MockBackendAPI.register(username, email, password)
```

**Process:**
1. Validates username uniqueness
2. Generates TOTP secret automatically
3. Creates user in "database" with 2FA enabled
4. Returns QR code for authenticator app setup
5. User MUST scan QR code with Google Authenticator/Authy
6. User MUST verify by entering 6-digit code (2-minute time limit)
7. Setup complete only after verification

**⚠️ IMPORTANT: 2FA is COMPULSORY for all new accounts**

**Response:**
```json
{
  "success": true,
  "user": { "id": "usr_xxx", "username": "...", "email": "..." },
  "totp": {
    "secret": "BASE32SECRET",
    "qrCode": "https://api.qrserver.com/..."
  }
}
```

---

### 2. **Login (Sign In)** - 2FA ALWAYS REQUIRED

```typescript
await MockBackendAPI.login(username, password)
```

**Process:**
1. Checks if user exists (including honeypot accounts)
2. Verifies password hash
3. **Logs honeypot access** if account is fake
4. Creates session token
5. **Always requires 2FA for registered accounts**
6. User opens authenticator app
7. User enters current 6-digit TOTP code
8. Session verified and authenticated

**⚠️ NO OPTION TO SKIP 2FA - It's mandatory!**

**Response:**
```json
{
  "success": true,
  "requires2FA": true,
  "token": "tok_xxx",
  "user": { ... }
}
```

---

### 3. **2FA Verification**

#### Method A: TOTP (Authenticator App)

```typescript
await MockBackendAPI.verify2FA(token, totpCode)
```

**Process:**
1. Validates session token
2. Retrieves user's TOTP secret
3. Verifies 6-digit code using time-based algorithm
4. Allows ±30 second window for clock drift
5. Updates session to "verified"

#### Method B: Email OTP (Fallback)

```typescript
// Request OTP
await MockBackendAPI.requestEmailOTP(token)

// Verify OTP
await MockBackendAPI.verifyEmailOTP(token, otp)
```

**Process:**
1. Generates random 6-digit OTP
2. Stores OTP with 5-minute expiry
3. "Sends" email (console log in demo)
4. User enters OTP from email
5. Validates OTP and expiry

---

## 🍯 Honeypot System

### Fake Account Categories

The system seeds **9 honeypot accounts** across 4 categories:

#### 1. **Admin Accounts** (3 accounts)
```
- admin / admin123
- administrator / password
- root / root
```

#### 2. **Developer Accounts** (2 accounts)
```
- developer / dev123
- testuser / test123
```

#### 3. **Service Accounts** (2 accounts)
```
- backup / backup2024
- monitoring / monitor123
```

#### 4. **Weak Password Traps** (2 accounts)
```
- user / password123
- guest / guest
```

### How Honeypots Work

1. **Realistic Decoys**: Accounts look legitimate to attackers
2. **Intentional Weaknesses**: Common usernames + weak passwords
3. **Silent Logging**: Every login attempt is tracked
4. **Attacker Profiling**: IP, timestamp, behavior patterns recorded

### Honeypot Detection

```typescript
db.logHoneypotAccess(username, success)
```

**Console Output:**
```
🚨 HONEYPOT TRIGGERED! {
  username: 'admin',
  timestamp: '2025-01-11T12:00:00Z',
  success: true,
  alert: 'Potential attacker detected - accessing fake account'
}
```

**In Production, This Would:**
- Send alerts to SOC team
- Log to SIEM system
- Deploy additional honeypots
- Track attacker fingerprint
- Initiate automated response

---

## 🔒 TOTP Implementation

### Algorithm Details

Based on **RFC 6238** (TOTP) and **RFC 4226** (HOTP):

```typescript
// 1. Generate secret (20 bytes, Base32 encoded)
const secret = TOTP.generateSecret()
// Example: "JBSWY3DPEHPK3PXP"

// 2. Generate QR code
const qrCode = TOTP.generateQRCode(email, secret)
// otpauth://totp/Honeypot%20Defense%20Grid:user@example.com?secret=...

// 3. Generate current token
const token = await TOTP.generate(secret)
// Example: "123456"

// 4. Verify token (±30 second window)
const isValid = await TOTP.verify(userToken, secret)
```

### How It Works

1. **Time-based Counter**: `floor(currentTime / 30)`
2. **HMAC-SHA1**: Hash counter with secret
3. **Dynamic Truncation**: Extract 6-digit code
4. **Window Tolerance**: Accepts previous/current/next period

---

## 🗄️ Database Schema (Simulated)

### User Model

```typescript
interface User {
  _id: string;              // "usr_abc123def456"
  username: string;         // Unique identifier
  email: string;            // For OTP delivery
  passwordHash: string;     // Hashed password
  totpSecret?: string;      // Base32 TOTP secret
  twoFactorEnabled: boolean; // 2FA status
  emailOtpSecret?: string;  // Current email OTP
  emailOtpExpiry?: number;  // OTP expiration timestamp
  createdAt: Date;          // Account creation
  lastLogin?: Date;         // Last successful login
  isHoneypot?: boolean;     // Fake account flag
}
```

### Session Model

```typescript
interface Session {
  userId: string;           // User reference
  token: string;            // "tok_xyz789abc123"
  createdAt: Date;          // Session start
  expiresAt: Date;          // 24-hour expiry
  verified2FA: boolean;     // 2FA completion status
}
```

---

## 🎯 Try It Out

### Test Credentials

#### Real Account (Registration Required)
1. Click "Sign Up"
2. Create account with any username/email
3. Scan QR code with authenticator app
4. Sign in with 2FA

#### Honeypot Accounts (Instant Access)
1. Click "Sign In"
2. Try: `admin` / `admin123`
3. Check browser console for honeypot alert 🚨
4. Observe system logs

---

## 🚀 API Reference

### Authentication Endpoints

| Method | Description | Parameters |
|--------|-------------|------------|
| `register()` | Create new account | username, email, password |
| `login()` | Authenticate user | username, password |
| `verify2FA()` | Verify TOTP code | token, totpCode |
| `requestEmailOTP()` | Send email OTP | token |
| `verifyEmailOTP()` | Verify email OTP | token, otp |
| `getCurrentUser()` | Get session user | token |
| `logout()` | End session | token |
| `enable2FA()` | Enable 2FA for user | token |

### Honeypot Endpoints

| Method | Description | Returns |
|--------|-------------|---------|
| `getHoneypotStats()` | Database statistics | Account counts, types |

---

## 🔧 Configuration

### Session Duration
```typescript
expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
```

### Email OTP Expiry
```typescript
emailOtpExpiry: Date.now() + 5 * 60 * 1000 // 5 minutes
```

### TOTP Window
```typescript
async verify(token, secret, window = 1) // ±30 seconds
```

---

## 📊 Monitoring

### Honeypot Statistics Dashboard

View real-time honeypot metrics:
- Total accounts
- Honeypot vs real accounts
- Deception rate percentage
- Category breakdown

### Console Logging

All honeypot access attempts are logged:
```javascript
console.log('🍯 Honeypot Database Seeded: 9 fake accounts created')
console.log('🚨 HONEYPOT TRIGGERED!', { username, timestamp, success })
console.log('📧 Email OTP sent to user@example.com: 123456')
```

---

## 🛡️ Security Features

### Implemented
- ✅ Password hashing (simulated)
- ✅ Session tokens with expiry
- ✅ TOTP 2FA (RFC 6238)
- ✅ Email OTP fallback
- ✅ Rate limiting (simulated delays)
- ✅ Honeypot logging
- ✅ Secure token generation

### Production Recommendations
- 🔒 Use bcrypt for password hashing
- 🔒 Implement HTTPS/TLS
- 🔒 Add CSRF protection
- 🔒 Rate limiting with Redis
- 🔒 IP-based blocking
- 🔒 Audit logging to SIEM
- 🔒 Email verification on signup
- 🔒 Password complexity requirements

---

## 🎓 Educational Value

This implementation demonstrates:

1. **Full-stack architecture** without a real backend
2. **Cryptographic algorithms** (TOTP, HMAC-SHA1)
3. **Security best practices** (2FA, sessions)
4. **Deception tactics** (honeypots)
5. **Threat detection** (logging, monitoring)

Perfect for learning cybersecurity concepts in a safe, controlled environment!

---

## 📝 Notes

- This is a **client-side simulation** of a backend
- Data is stored in **browser memory** (lost on refresh)
- Session tokens use **localStorage** for persistence
- Email OTPs are **logged to console** (demo mode)
- Honeypot alerts are **console-based**

For production deployment, replace with:
- Real Node.js/Express backend
- Actual MongoDB database
- Email service (SendGrid, AWS SES)
- SIEM integration (Splunk, ELK)
- Real-time alerting (PagerDuty, Slack)

---

## 🎯 Next Steps

1. Try creating an account
2. Set up 2FA with Google Authenticator
3. Test honeypot detection with `admin/admin123`
4. View honeypot stats in dashboard
5. Explore TOTP algorithm in DevTools

**Happy Hacking! (Ethically, of course 😉)**
