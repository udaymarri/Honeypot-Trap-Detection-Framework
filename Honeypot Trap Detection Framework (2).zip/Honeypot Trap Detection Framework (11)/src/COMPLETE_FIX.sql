-- ========================================
-- COMPLETE FIX FOR SEEDING ERROR
-- Copy this ENTIRE script and run in Supabase SQL Editor
-- ========================================

-- Step 1: Drop ALL existing policies (clean slate)
-- ========================================

-- Drop all policies on honeypots table
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;
DROP POLICY IF EXISTS "Enable all for honeypots" ON honeypots;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON honeypots;

-- Drop all policies on decoy_environments table
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for decoy_environments" ON decoy_environments;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON decoy_environments;

-- Drop all policies on attack_logs table
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;
DROP POLICY IF EXISTS "Enable all for attack_logs" ON attack_logs;
DROP POLICY IF EXISTS "Enable read for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON attack_logs;


-- Step 2: Create NEW policies that allow BOTH authenticated AND anon users
-- ========================================

-- Honeypots table - Allow ALL operations for authenticated OR anon
CREATE POLICY "Allow all access to honeypots"
ON honeypots
FOR ALL
USING (
  auth.role() = 'authenticated' 
  OR 
  auth.role() = 'anon'
);

-- Decoy Environments table - Allow ALL operations for authenticated OR anon
CREATE POLICY "Allow all access to decoy_environments"
ON decoy_environments
FOR ALL
USING (
  auth.role() = 'authenticated' 
  OR 
  auth.role() = 'anon'
);

-- Attack Logs table - Allow ALL operations for authenticated OR anon
CREATE POLICY "Allow all access to attack_logs"
ON attack_logs
FOR ALL
USING (
  auth.role() = 'authenticated' 
  OR 
  auth.role() = 'anon'
);


-- Step 3: Verify tables exist and RLS is enabled
-- ========================================

-- Verify honeypots table
DO $$
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'honeypots') THEN
    RAISE NOTICE '✅ honeypots table exists';
  ELSE
    RAISE EXCEPTION '❌ honeypots table NOT found! Run table creation script first.';
  END IF;
END $$;

-- Verify decoy_environments table
DO $$
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'decoy_environments') THEN
    RAISE NOTICE '✅ decoy_environments table exists';
  ELSE
    RAISE EXCEPTION '❌ decoy_environments table NOT found! Run table creation script first.';
  END IF;
END $$;

-- Verify attack_logs table
DO $$
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'attack_logs') THEN
    RAISE NOTICE '✅ attack_logs table exists';
  ELSE
    RAISE EXCEPTION '❌ attack_logs table NOT found! Run table creation script first.';
  END IF;
END $$;


-- Step 4: Display success message
-- ========================================

DO $$
BEGIN
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
  RAISE NOTICE '✅ RLS POLICIES UPDATED SUCCESSFULLY!';
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
  RAISE NOTICE '';
  RAISE NOTICE '📋 Next steps:';
  RAISE NOTICE '   1. Go back to your app';
  RAISE NOTICE '   2. Click "Seed Database" button';
  RAISE NOTICE '   3. Wait for success message';
  RAISE NOTICE '';
  RAISE NOTICE '✨ All tables now allow anon access for seeding!';
  RAISE NOTICE '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━';
END $$;
