# 🆘 Error Cheat Sheet - Quick Fixes

**Quick reference for common errors and instant solutions**

---

## 🔴 Error: "Could not find the table 'public.honeypots'"

**Seen in:** Browser console or Database Seeder component

### Diagnosis:

**Step 1:** Go to Supabase Dashboard → Table Editor

**Do you see 4 tables?** (users, honeypots, decoy_environments, attack_logs)

#### ❌ NO - Tables don't exist

**Fix:** Run the table creation SQL

1. Supabase Dashboard → SQL Editor → + New Query
2. Copy SQL from: [QUICK_FIX.md](./QUICK_FIX.md) or [STEP_BY_STEP.md](./STEP_BY_STEP.md)
3. Paste & Click "Run"
4. **Time to fix:** 2 minutes

#### ✅ YES - Tables exist, but RLS blocks access

**Fix:** Update RLS policies to allow anon users

1. Supabase Dashboard → SQL Editor → + New Query
2. Copy SQL from: [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)
3. Paste & Click "Run"
4. **Time to fix:** 30 seconds

**Quick SQL:**
```sql
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

**Full guide:** [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md)

---

## 🔴 Error: "permission denied for table honeypots"

**Cause:** RLS policies too restrictive

**Fix:** Same as above - run [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)

**Time to fix:** 30 seconds

---

## 🔴 Error: Dashboard shows no data after seeding

**Possible causes:**

### 1. Seed didn't actually run
- **Check:** Browser console (F12) for errors
- **Fix:** Click "Seed Database" button again

### 2. Data inserted but page not refreshed
- **Fix:** Press F5 to refresh page

### 3. RLS blocking reads
- **Check:** Supabase Dashboard → Table Editor → Click table → Check if data exists
- **Fix:** If data exists but invisible in app, run [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)

---

## 🔴 Error: "Port 5173 already in use"

**Fix:**
```bash
pkill -f vite
npm run dev
```

**Or use different port:**
```bash
npm run dev -- --port 3000
```

---

## 🔴 Error: "Invalid 2FA code"

**Causes:**
- Code expired (codes change every 30 seconds)
- Wrong code typed
- Phone time not synced

**Fix:**
1. Wait for NEW code in Google Authenticator
2. Type it quickly
3. Check phone time is correct

---

## 🔴 Error: "Cannot find module '@supabase/supabase-js'"

**Fix:**
```bash
rm -rf node_modules package-lock.json
npm install
npm run dev
```

---

## 🔴 Error: TypeScript errors in VS Code

**Fix:**
1. Ctrl+Shift+P → "TypeScript: Restart TS Server"
2. Or: Ctrl+Shift+P → "Developer: Reload Window"

---

## 🔴 Error: Supabase client shows "System Offline"

**Check:**
1. Supabase project active? (https://supabase.com/dashboard)
2. Internet connection working?
3. `/utils/supabase/info.tsx` file exists?

**Fix:**
- Hard refresh: Ctrl+Shift+R
- Check Supabase status: https://status.supabase.com/

---

## 🔴 Seed button says "Success" but no data appears

**Diagnosis:**

**Step 1:** Check browser console (F12)
- Green checkmarks = Data inserted
- Red errors = Something failed

**Step 2:** Check Supabase directly
- Dashboard → Table Editor → Click `honeypots`
- Should see 6 rows

**Step 3:** If data exists in Supabase but not in app
- Press F5 to refresh
- Check RLS policies (run [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql))

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] Tables exist (Supabase → Table Editor → See 4 tables)
- [ ] App runs (`npm run dev` works)
- [ ] Can register new user
- [ ] Can login with 2FA
- [ ] Dashboard loads
- [ ] Seed Database button visible
- [ ] Clicking Seed shows success message
- [ ] Dashboard shows data (threat stats, charts, maps)
- [ ] Attack logs appear in feed

---

## 🎯 Most Common Issue

**95% of errors are caused by RLS policies blocking access!**

**Quick fix:**
1. Go to Supabase SQL Editor
2. Run [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)
3. Try again

---

## 📚 Detailed Guides

| Error Type | Guide |
|------------|-------|
| Seeding errors | [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md) |
| All errors | [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) |
| RLS explained | [RLS_EXPLAINED.md](./RLS_EXPLAINED.md) |
| Setup from scratch | [STEP_BY_STEP.md](./STEP_BY_STEP.md) |

---

## 🆘 Still Stuck?

**Before asking for help, collect:**

1. **What you did:** Step-by-step actions
2. **Error message:** Exact text or screenshot
3. **Browser console:** F12 → Console tab → Screenshot errors
4. **Tables exist?** Check Supabase Table Editor
5. **Node version:** Run `node --version`

**Then check:**
- [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) - Comprehensive solutions
- [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md) - Seeding-specific help
- [RLS_EXPLAINED.md](./RLS_EXPLAINED.md) - Understanding RLS

---

## ⚡ Quick Actions

```bash
# Restart dev server
pkill -f vite && npm run dev

# Reinstall dependencies
rm -rf node_modules package-lock.json && npm install

# Check Node version (need 18+)
node --version

# Clear browser cache
# Ctrl+Shift+R (hard refresh)
```

---

**Remember: Check [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql) first - it fixes 95% of issues!** 🎯
