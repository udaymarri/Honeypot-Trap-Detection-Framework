-- ⚡ QUICK FIX: Update RLS Policies to Allow Seeding
-- Run this in Supabase SQL Editor to fix "Tables not found" error

-- Drop old policies
DROP POLICY IF EXISTS "Enable read for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;

DROP POLICY IF EXISTS "Enable read for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;

DROP POLICY IF EXISTS "Enable read for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;

-- Create new policies that allow BOTH authenticated AND anon access
-- (This allows seeding from the browser)

-- Honeypots policies
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

-- Decoy Environments policies
CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

-- Attack Logs policies
CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
