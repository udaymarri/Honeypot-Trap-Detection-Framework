# 🚀 MongoDB Atlas Integration Guide

Complete guide to connect your Honeypot Defense Grid to MongoDB Atlas.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [MongoDB Atlas Setup](#mongodb-atlas-setup)
3. [Backend Configuration](#backend-configuration)
4. [Frontend Configuration](#frontend-configuration)
5. [Running the Application](#running-the-application)
6. [Seeding Fake Data](#seeding-fake-data)
7. [Testing](#testing)
8. [Troubleshooting](#troubleshooting)

---

## 1️⃣ Prerequisites

Before starting, make sure you have:

- ✅ Node.js (v18 or higher)
- ✅ npm or yarn
- ✅ MongoDB Atlas account
- ✅ Your MongoDB connection string

---

## 2️⃣ MongoDB Atlas Setup

### Step 1: Get Your Password

Your connection string is:
```
mongodb+srv://ganeshmunaga@cluster0.15rkrdo.mongodb.net/
```

You need to replace the password in the backend `.env` file.

### Step 2: Whitelist Your IP

1. Go to MongoDB Atlas Dashboard
2. Click **Network Access** (left sidebar)
3. Click **Add IP Address**
4. Choose one:
   - **Add Current IP Address** (for your current IP)
   - **Allow Access from Anywhere** (0.0.0.0/0) - for development only!

### Step 3: Create Database User (if not exists)

1. Go to **Database Access**
2. Click **Add New Database User**
3. Username: `ganeshmunaga`
4. Password: (create a strong password)
5. **Database User Privileges**: Read and write to any database
6. Click **Add User**

---

## 3️⃣ Backend Configuration

### Step 1: Navigate to Backend Folder

```bash
cd backend
```

### Step 2: Install Dependencies

```bash
npm install
```

This will install:
- express - Web framework
- mongoose - MongoDB ODM
- cors - Cross-origin requests
- dotenv - Environment variables
- bcryptjs - Password hashing
- jsonwebtoken - JWT tokens
- speakeasy - TOTP 2FA
- helmet - Security headers
- express-rate-limit - Rate limiting

### Step 3: Configure Environment Variables

Open `backend/.env` and update:

```env
# Replace YOUR_PASSWORD_HERE with your actual MongoDB password
MONGODB_URI=mongodb+srv://ganeshmunaga:YOUR_ACTUAL_PASSWORD@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority

# Server Configuration
PORT=5000
NODE_ENV=development

# Frontend URL (for CORS)
FRONTEND_URL=http://localhost:5173

# JWT Secret (change this to a random string!)
JWT_SECRET=your_super_secret_jwt_key_here_change_this

# Session Secret (change this to a random string!)
SESSION_SECRET=your_super_secret_session_key_here_change_this
```

⚠️ **IMPORTANT**: Replace:
- `YOUR_ACTUAL_PASSWORD` - Your MongoDB Atlas password
- `JWT_SECRET` - A strong random string (use a password generator)
- `SESSION_SECRET` - Another strong random string

### Step 4: Test MongoDB Connection

```bash
npm start
```

You should see:
```
✅ Connected to MongoDB Atlas
📊 Database: honeypot-defense
🚀 Server running on port 5000
```

---

## 4️⃣ Frontend Configuration

### Step 1: Navigate to Root Folder

```bash
cd ..
```

### Step 2: Install Frontend Dependencies

```bash
npm install
```

### Step 3: Configure Frontend Environment

The `.env` file in the root should have:

```env
VITE_API_URL=http://localhost:5000/api
VITE_ENABLE_MOCK_DATA=false
VITE_ENABLE_DEBUG_MODE=true
```

---

## 5️⃣ Running the Application

### Option 1: Run Both Servers Separately

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
npm run dev
```

### Option 2: Use Concurrently (Recommended)

Create a script to run both at once. Add to root `package.json`:

```json
{
  "scripts": {
    "dev": "concurrently \"cd backend && npm run dev\" \"npm run dev\"",
    "start:backend": "cd backend && npm start",
    "start:frontend": "npm run dev"
  }
}
```

Then run:
```bash
npm run dev
```

---

## 6️⃣ Seeding Fake Data

This populates MongoDB with fake honeypot data to mislead attackers.

### Step 1: Run Seed Script

```bash
cd backend
npm run seed
```

You should see:
```
🌱 Starting database seed...
✅ Connected to MongoDB Atlas
📡 Inserting honeypots...
✅ Inserted 6 honeypots
🎭 Inserting decoy environments...
✅ Inserted 4 decoy environments
⚔️  Generating fake attack logs...
✅ Inserted 200 attack logs

✨ Database seeding completed!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Total Records: 210
   • Honeypots: 6
   • Decoy Environments: 4
   • Attack Logs: 200
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Fake Data Includes:

**6 Honeypots:**
- SSH Honeypot - Production Server
- HTTP Server - Web Portal
- FTP Server - File Storage
- SMTP Mail Server
- MySQL Database Server
- RDP Windows Server

**4 Decoy Environments with Fake Credentials:**
1. Production Database - Customer Records
   - admin / admin123
   - dbuser / database2024
   
2. Corporate File Server
   - administrator / Password123!
   - fileadmin / files2024
   
3. Development Git Repository
   - git / gitpassword
   - developer / dev@2024
   
4. Email Server - Exchange
   - postmaster / mail123
   - support@company.com / Support2024

**200 Fake Attack Logs:**
- SQL Injection attempts
- SSH Brute Force attacks
- Port Scans
- DDoS attempts
- Malware uploads
- XSS attempts
- RCE attempts

---

## 7️⃣ Testing

### Test 1: Health Check

Open browser or use curl:
```bash
curl http://localhost:5000/api/health
```

Expected response:
```json
{
  "status": "online",
  "timestamp": "2025-01-11T...",
  "database": "connected",
  "version": "2.4.1"
}
```

### Test 2: Get Honeypots

```bash
curl http://localhost:5000/api/honeypots
```

Should return list of 6 honeypots.

### Test 3: Get Decoy Environments

```bash
curl http://localhost:5000/api/decoys
```

Should return 4 decoy environments with fake credentials.

### Test 4: Frontend Registration

1. Open http://localhost:5173
2. Click **Get Started**
3. Register new account
4. Complete 2FA setup
5. Login to dashboard

---

## 8️⃣ Troubleshooting

### Problem: "Unable to connect to server"

**Solution:**
1. Check backend is running: `cd backend && npm start`
2. Check port 5000 is not in use
3. Check CORS settings in `backend/server.js`

### Problem: "MongoDB connection error"

**Solutions:**

1. **Check Password:**
   - Make sure you replaced `YOUR_PASSWORD_HERE` in `.env`
   - Password must be URL-encoded if it contains special characters

2. **Check IP Whitelist:**
   - Go to MongoDB Atlas → Network Access
   - Add your current IP or use 0.0.0.0/0 for development

3. **Check Database User:**
   - Go to MongoDB Atlas → Database Access
   - Verify user `ganeshmunaga` exists
   - Check permissions are "Read and write to any database"

4. **Test Connection String:**
   ```bash
   mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/"
   ```

### Problem: "Cannot find module 'mongoose'"

**Solution:**
```bash
cd backend
rm -rf node_modules package-lock.json
npm install
```

### Problem: Frontend shows "Mock data"

**Solution:**
Check `.env` file has:
```env
VITE_ENABLE_MOCK_DATA=false
```

Then restart frontend:
```bash
npm run dev
```

### Problem: CORS errors

**Solution:**
Update `backend/server.js`:
```javascript
app.use(cors({
  origin: 'http://localhost:5173', // Your frontend URL
  credentials: true
}));
```

---

## 🎯 Quick Start Checklist

Use this checklist to get started quickly:

- [ ] Install Node.js (v18+)
- [ ] Clone/download the project
- [ ] Get MongoDB Atlas password
- [ ] Whitelist your IP in MongoDB Atlas
- [ ] Update `backend/.env` with MongoDB password
- [ ] Generate JWT_SECRET and SESSION_SECRET
- [ ] Install backend dependencies: `cd backend && npm install`
- [ ] Install frontend dependencies: `cd .. && npm install`
- [ ] Start backend: `cd backend && npm run dev`
- [ ] Seed fake data: `npm run seed`
- [ ] Start frontend: `npm run dev` (in root directory)
- [ ] Open http://localhost:5173
- [ ] Test registration and 2FA setup
- [ ] View dashboard with MongoDB data

---

## 📊 Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                   Browser (Frontend)                     │
│              React + TypeScript + Tailwind               │
│                  http://localhost:5173                   │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ HTTP Requests
                       │ (API calls)
                       ▼
┌─────────────────────────────────────────────────────────┐
│              Backend API Server                          │
│            Node.js + Express.js                          │
│            http://localhost:5000                         │
│                                                           │
│  Routes:                                                  │
│  • /api/auth - Authentication + 2FA                      │
│  • /api/honeypots - Honeypot management                 │
│  • /api/decoys - Decoy environments                     │
│  • /api/attacks - Attack logs                           │
│  • /api/threats - Threat intelligence                   │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ Mongoose ODM
                       │ (Database queries)
                       ▼
┌─────────────────────────────────────────────────────────┐
│                  MongoDB Atlas                           │
│           cluster0.15rkrdo.mongodb.net                   │
│                                                           │
│  Database: honeypot-defense                              │
│  Collections:                                             │
│  • users - User accounts + 2FA secrets                   │
│  • honeypots - Honeypot configurations                   │
│  • decoyenvironments - Fake systems with credentials     │
│  • attacklogs - Captured attack attempts                 │
└─────────────────────────────────────────────────────────┘
```

---

## 🔐 Security Notes

### Production Deployment:

1. **Change all secrets** in `.env`:
   - Use strong random strings for JWT_SECRET
   - Use different SESSION_SECRET
   - Never commit `.env` to git

2. **MongoDB Security**:
   - Don't use 0.0.0.0/0 for IP whitelist
   - Use specific IP addresses
   - Rotate passwords regularly
   - Enable MongoDB encryption at rest

3. **Backend Security**:
   - Enable helmet middleware (already included)
   - Use rate limiting (already included)
   - Enable HTTPS in production
   - Set NODE_ENV=production

4. **Frontend Security**:
   - Never expose API keys in client code
   - Use environment variables
   - Enable CSP headers

---

## 🎉 Success!

If everything is working, you should see:

1. ✅ Backend running on port 5000
2. ✅ Frontend running on port 5173
3. ✅ MongoDB connected
4. ✅ Fake honeypot data loaded
5. ✅ Authentication with 2FA working
6. ✅ Dashboard showing real data from MongoDB

**Next Steps:**
- Customize honeypot configurations
- Add more decoy environments
- Configure alerts and notifications
- Set up logging and monitoring
- Deploy to production

---

## 📞 Need Help?

If you encounter issues:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review backend logs in terminal
3. Check browser console for errors
4. Verify MongoDB Atlas dashboard
5. Test API endpoints with curl/Postman

---

**Happy Hacking! 🛡️**

*Remember: This is a honeypot system. The fake data is designed to mislead attackers!*
