# ⚡ QUICK FIX: "Could not find the table" Error

**You're seeing this error because the database tables don't exist yet!**

---

## 🎯 The Fix (2 Minutes)

### Step 1: Go to Supabase

Open: https://supabase.com/dashboard

Click your project → Click "SQL Editor" → Click "+ New Query"

---

### Step 2: Copy This SQL

```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies - Allow both authenticated AND anon users (for seeding from browser)
CREATE POLICY "Users can view own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Enable insert for users" ON users FOR INSERT WITH CHECK (true);

-- Allow all operations for authenticated users OR anon role (needed for seeding)
CREATE POLICY "Enable all for authenticated on honeypots" ON honeypots 
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for authenticated on decoys" ON decoy_environments 
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for authenticated on attacks" ON attack_logs 
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

---

### Step 3: Paste and Run

1. Paste into SQL editor
2. Click green "Run" button (bottom right)
3. Wait for "Success. No rows returned"

---

### Step 4: Verify

Click "Table Editor" → You should see 4 tables:
- ✅ users
- ✅ honeypots
- ✅ decoy_environments
- ✅ attack_logs

---

### Step 5: NOW Click Seed Database

Go back to your app dashboard → Scroll down → Click "Seed Database"

✅ **It should work now!**

---

## 🎓 Why This Happens

```
Your App                     Supabase Database
---------                    ------------------
                             
"Seed Database"    ------>   ❌ Tables don't exist!
  (FAILS)                    
                             
                             
Need to create               First create tables
tables first!    <------     with SQL script
                             
                             
"Seed Database"    ------>   ✅ Tables exist!
  (WORKS!)                      Inserts 210 records
```

---

## 📋 The Correct Order

```
1. Run SQL script      ← You forgot this step!
   (Creates tables)
   
2. Seed database       ← This is what you tried to do
   (Fills tables)
```

---

## ✅ After Running SQL

You'll have these tables ready:

| Table | What It Stores |
|-------|----------------|
| `users` | User accounts + 2FA secrets |
| `honeypots` | 6 honeypots (SSH, HTTP, etc.) |
| `decoy_environments` | 4 decoy systems with fake credentials |
| `attack_logs` | 200 fake attack attempts |

Then the seed button will populate them with fake data!

---

## 🆘 Still Not Working?

See the full guide: [STEP_BY_STEP.md](./STEP_BY_STEP.md)

Or troubleshooting: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

---

**TL;DR: Run the SQL script in Supabase Dashboard first, THEN click Seed Database!** 🚀
