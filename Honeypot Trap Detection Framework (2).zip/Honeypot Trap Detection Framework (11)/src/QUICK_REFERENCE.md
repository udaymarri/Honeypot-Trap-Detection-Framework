# ⚡ Quick Reference Card

**Print this page and keep it next to your computer!**

---

## 🔗 MongoDB Connection String

```
mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority
```

**⚠️ Replace `YOUR_PASSWORD` with your actual password!**

**Special characters?** URL-encode them:
- `@` → `%40`
- `#` → `%23`
- `%` → `%25`

---

## 🚀 Start Commands

### Backend
```bash
cd backend
npm run dev
```
**URL**: http://localhost:5000

### Frontend
```bash
npm run dev
```
**URL**: http://localhost:5173

### Seed Database
```bash
cd backend
npm run seed
```

---

## 🔌 API Endpoints

### Health Check
```
GET http://localhost:5000/api/health
```

### Authentication
```
POST /api/auth/register      # Sign up
POST /api/auth/login         # Login (step 1)
POST /api/auth/setup-2fa     # Get QR code
POST /api/auth/verify-setup  # Verify setup
POST /api/auth/verify-2fa    # Verify login
```

### Data
```
GET /api/honeypots    # List honeypots
GET /api/decoys       # List decoys
GET /api/attacks      # List attacks
GET /api/threats      # Threat feed
```

---

## 🎭 Fake Credentials (Test Data)

### Production Database
```
admin / admin123
dbuser / database2024
backup_user / backup@123
```

### Corporate File Server
```
administrator / Password123!
fileadmin / files2024
```

### Git Repository
```
git / gitpassword
developer / dev@2024
```

### Email Server
```
postmaster / mail123
support@company.com / Support2024
```

**⚠️ These are FAKE honeypot traps!**

---

## 🗄️ MongoDB Collections

```javascript
// Users
db.users.find()

// Honeypots (6 total)
db.honeypots.find()
db.honeypots.countDocuments()

// Decoy Environments (4 total)
db.decoyenvironments.find()

// Attack Logs (200 total)
db.attacklogs.find().limit(10)
db.attacklogs.countDocuments()
```

---

## 🔐 Environment Variables

### Backend (.env)
```env
MONGODB_URI=mongodb+srv://...
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
JWT_SECRET=<64-char-random-string>
SESSION_SECRET=<64-char-random-string>
```

### Frontend (.env)
```env
VITE_API_URL=http://localhost:5000/api
VITE_ENABLE_MOCK_DATA=false
VITE_ENABLE_DEBUG_MODE=true
```

---

## 🧪 Testing Commands

### Test MongoDB Connection
```bash
mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/"
```

### Test Health Endpoint
```bash
curl http://localhost:5000/api/health
```

### Test Honeypots
```bash
curl http://localhost:5000/api/honeypots
```

### Check Port Usage
```bash
# Mac/Linux
lsof -i :5000
lsof -i :5173

# Windows
netstat -ano | findstr :5000
netstat -ano | findstr :5173
```

---

## 🛠️ Troubleshooting

### MongoDB won't connect?
1. Check password in `backend/.env`
2. Whitelist IP in MongoDB Atlas
3. URL-encode special characters

### Port already in use?
```bash
# Kill process on port 5000
kill -9 $(lsof -t -i:5000)
```

### Frontend shows mock data?
```bash
# Check .env
cat .env | grep MOCK
# Should be: VITE_ENABLE_MOCK_DATA=false
```

### 2FA doesn't work?
1. Check phone time is synchronized
2. Use debug panel to see expected code
3. Try manual entry instead of QR scan

---

## 📁 File Locations

```
backend/.env              ← MongoDB password here
.env                      ← Frontend config here
backend/server.js         ← Main backend file
App.tsx                   ← Main frontend file
services/api.ts           ← API service layer
backend/scripts/seed.js   ← Database seeder
```

---

## 🎯 Common Tasks

### Reset Database
```bash
cd backend
npm run seed
```

### View Logs
```bash
# Backend logs are in the terminal
# Frontend logs: Open browser → F12 → Console
```

### Generate JWT Secret
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Export Data
```bash
mongoexport --uri="mongodb+srv://..." --collection=honeypots --out=honeypots.json
```

---

## 🔢 Port Numbers

| Service | Port | URL |
|---------|------|-----|
| Frontend | 5173 | http://localhost:5173 |
| Backend | 5000 | http://localhost:5000 |
| MongoDB | 27017 | MongoDB Atlas (cloud) |

---

## 📊 Data Counts

After seeding, you should have:

```
Honeypots:         6
Decoy Environments: 4
Attack Logs:       200
Total Records:     210
```

---

## 🎨 Theme Colors

```css
Primary (Cyan):    #00ffff
Secondary (Purple): #7b2cbf
Destructive (Pink): #ff0055
Accent (Blue):     #6b46ff
Green:             #00ff88
Background:        #0a0a0f
Card:              #12121a
```

---

## 🔗 Important Links

| Link | Description |
|------|-------------|
| http://localhost:5173 | Frontend dashboard |
| http://localhost:5000 | Backend API |
| http://localhost:5000/api/health | Health check |
| https://cloud.mongodb.com | MongoDB Atlas |
| [START_HERE.md](./START_HERE.md) | Setup guide |
| [SETUP_CHECKLIST.md](./SETUP_CHECKLIST.md) | Checklist |

---

## 📱 2FA Apps

- **Google Authenticator** (iOS/Android)
- **Authy** (iOS/Android/Desktop)
- **Microsoft Authenticator** (iOS/Android)

---

## 🆘 Emergency Commands

### Stop Everything
```bash
# Press Ctrl+C in each terminal
# Or:
pkill -f "npm run dev"
```

### Fresh Install
```bash
rm -rf node_modules backend/node_modules
rm package-lock.json backend/package-lock.json
npm install
cd backend && npm install
```

### Reset MongoDB
```bash
cd backend
npm run seed
```

---

## 📞 Support Checklist

Before asking for help:

- [ ] Checked [START_HERE.md](./START_HERE.md)
- [ ] Verified MongoDB password is correct
- [ ] Confirmed IP is whitelisted
- [ ] Both servers are running
- [ ] Checked browser console (F12)
- [ ] Checked backend terminal for errors
- [ ] Tested health endpoint
- [ ] Reviewed [MONGODB_SETUP.md](./MONGODB_SETUP.md)

---

## 🎉 Success Indicators

You know it's working when:

- ✅ Backend shows: "MongoDB: Connected"
- ✅ Frontend loads without errors
- ✅ Health check returns "connected"
- ✅ Dashboard shows real data (not mock)
- ✅ 2FA verification works
- ✅ Login/logout works
- ✅ Threat map displays attacks
- ✅ Decoy credentials are visible

---

## 🔐 Security Reminders

- ❌ Never commit `.env` files to git
- ❌ Never use `0.0.0.0/0` in production
- ❌ Never share JWT secrets
- ✅ Use strong random secrets
- ✅ Rotate passwords regularly
- ✅ Enable MongoDB backups
- ✅ Use HTTPS in production

---

## 📅 Maintenance

### Daily
- Check logs for errors
- Monitor attack patterns
- Review alerts

### Weekly
- Update dependencies
- Review security settings
- Backup database

### Monthly
- Rotate secrets
- Update passwords
- Review access logs
- Clean old attack logs

---

## 🎯 Quick Commands

```bash
# Backend
cd backend && npm run dev      # Start
npm run seed                    # Seed DB
npm install                     # Install deps

# Frontend
npm run dev                     # Start
npm run build                   # Build
npm install                     # Install deps

# Both
npm run dev                     # Start both (if configured)

# MongoDB
mongosh "mongodb+srv://..."    # Connect
db.honeypots.find()            # Query
```

---

**Save this page! Print it! Keep it handy!** 🎯

**Last Updated**: January 11, 2025
