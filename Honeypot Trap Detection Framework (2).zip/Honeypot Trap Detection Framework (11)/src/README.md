# 🛡️ Honeypot Trap Detection Framework

**An intelligent cyber deception and intrusion analysis system with a futuristic cyberpunk aesthetic.**

Deploy multi-protocol honeypots, capture and analyze attacker behavior in real-time, and provide interactive 3D visualizations with threat intelligence.

---

## 🎯 Features

### 🔒 Security
- **Mandatory 2FA** - TOTP authentication using Google Authenticator
- **JWT Authentication** - Secure token-based sessions
- **Password Hashing** - bcrypt with 12 rounds
- **Rate Limiting** - DDoS protection
- **Security Headers** - Helmet middleware

### 🎭 Deception
- **6 Honeypots** - SSH, HTTP, FTP, SMTP, MySQL, RDP
- **4 Decoy Environments** - Fake systems with credentials
- **Fake Credentials** - admin/admin123, git/gitpassword, etc.
- **Bait Files** - company_secrets.docx, .env files, etc.
- **Attack Logging** - Capture all intrusion attempts

### 📊 Analytics
- **Real-time Threat Feed** - Live attack monitoring
- **Interactive 3D Threat Map** - Geographic attack visualization
- **Attack Charts** - Time-series analytics
- **Severity Tracking** - Critical, High, Medium, Low
- **Attack Type Analysis** - SQL Injection, SSH Brute Force, etc.

### 🎨 UI/UX
- **Cyberpunk Theme** - Dark neon aesthetic
- **Matrix Effects** - Animated backgrounds
- **3D Animations** - Motion/Framer Motion
- **Responsive Design** - Mobile and desktop
- **Real-time Updates** - Live data streaming

---

## 🚀 Quick Start (Supabase - Recommended!)

> ## 🚨 **GETTING "TABLES NOT FOUND" ERROR?**
> ### → [FIX_NOW.md](./FIX_NOW.md) ← **CLICK HERE FOR INSTANT FIX!**
> 
> **📖 FIRST TIME HERE?** Follow [STEP_BY_STEP.md](./STEP_BY_STEP.md) - **Complete visual guide!**
> 
> **📖 Experienced users?** See [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md)

### Prerequisites
- Node.js 18+
- Supabase account (free tier works!)
- Google Authenticator app

### Installation (3 Steps!)

```bash
# 1. Clone & install
git clone <repository-url>
cd honeypot-defense-grid
npm install

# 2. Create database tables
# Go to Supabase Dashboard → SQL Editor
# Copy & paste SQL from SUPABASE_QUICKSTART.md
# Click "Run"

# 3. Start the app
npm run dev

# Open browser: http://localhost:5173
```

**That's it!** No backend server needed! See [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md) for details.

---

### Alternative: Node.js + MongoDB Backend

If you prefer a traditional backend:

```bash
# See MONGODB_SETUP.md for complete instructions
cd backend && npm install
npm run seed
npm run dev  # Terminal 1

cd .. && npm run dev  # Terminal 2
```

**Note**: Supabase is recommended for simplicity!

---

## 📚 Complete Documentation

### Supabase Setup (Recommended)
| Document | Use Case | Time |
|----------|----------|------|
| **[FIX_NOW.md](./FIX_NOW.md)** | 🚨 **"TABLES NOT FOUND" ERROR?** - Run this NOW! | 2 min |
| **[ALL_IN_ONE_FIX.sql](./ALL_IN_ONE_FIX.sql)** | ⚡ Complete SQL script (creates tables + fixes RLS) | 30 sec |
| **[STEP_BY_STEP.md](./STEP_BY_STEP.md)** | 👶 **FIRST TIME?** - Visual step-by-step guide | 5 min |
| **[ERROR_CHEAT_SHEET.md](./ERROR_CHEAT_SHEET.md)** | 🆘 Quick error lookup & fixes | - |
| **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** | 🔧 Comprehensive troubleshooting | - |
| **[SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md)** | ⚡ Quick reference for setup | 3 min |

### Alternative: MongoDB + Node.js Backend
| Document | Use Case | Time |
|----------|----------|------|
| **[START_HERE.md](./START_HERE.md)** | 🚀 MongoDB quick start | 5 min |
| **[SETUP_CHECKLIST.md](./SETUP_CHECKLIST.md)** | ✅ Step-by-step checklist | 10 min |
| **[MONGODB_SETUP.md](./MONGODB_SETUP.md)** | 🗄️ Complete MongoDB integration | 20 min |
| **[backend/README.md](./backend/README.md)** | 🔌 Node.js API documentation | 20 min |

### General Documentation
| Document | Use Case | Time |
|----------|----------|------|
| **[ARCHITECTURE.md](./ARCHITECTURE.md)** | 🏗️ System architecture & design | 30 min |
| **[VISUAL_SETUP_GUIDE.md](./VISUAL_SETUP_GUIDE.md)** | 👀 Detailed setup with examples | 15 min |
| **[QUICK_REFERENCE.md](./QUICK_REFERENCE.md)** | 📋 Quick reference card | 2 min |

**🌟 Recommended**: Start with [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md) for the easiest setup!

---

## 📁 Project Structure

```
honeypot-defense-grid/
├── 📂 backend/                  # Node.js API server
│   ├── models/                  # MongoDB schemas
│   │   ├── User.js             # User + 2FA
│   │   ├── Honeypot.js         # Honeypot configs
│   │   ├── DecoyEnvironment.js # Fake systems
│   │   └── AttackLog.js        # Attack logs
│   ├── routes/                  # API endpoints
│   │   ├── auth.js             # Authentication
│   │   ├── honeypots.js        # Honeypot CRUD
│   │   ├── decoys.js           # Decoy management
│   │   ├── attacks.js          # Attack logs
│   │   └── threats.js          # Threat feed
│   ├── scripts/
│   │   └── seed.js             # Database seeder
│   ├── server.js               # Main server
│   ├── package.json
│   └── .env                    # Config (SECRET!)
│
├── 📂 components/               # React components
│   ├── LandingPage.tsx         # Marketing page
│   ├── AuthPage.tsx            # Login/Register
│   ├── ThreatMap.tsx           # 3D attack map
│   ├── ThreatFeed.tsx          # Live threat stream
│   ├── AttackChart.tsx         # Analytics charts
│   ├── DecoyEnvironments.tsx   # Fake systems UI
│   ├── HoneypotStatus.tsx      # Honeypot monitor
│   └── ...
│
├── 📂 services/                 # Business logic
│   ├── api.ts                  # Backend API client
│   ├── totp.ts                 # 2FA implementation
│   └── mockBackend.ts          # (deprecated)
│
├── 📂 styles/
│   └── globals.css             # Tailwind + theme
│
├── App.tsx                      # Main React app
├── .env                         # Frontend config
├── package.json
│
└── 📂 Documentation/
    ├── START_HERE.md           # Quick start
    ├── MONGODB_SETUP.md        # Detailed setup
    ├── VISUAL_SETUP_GUIDE.md   # Step-by-step guide
    ├── ARCHITECTURE.md         # System design
    └── backend/README.md       # API documentation
```

---

## 🗄️ Database Schema

### Users Collection
```javascript
{
  username: "admin",
  email: "admin@example.com",
  password: "$2a$12$...",        // bcrypt hashed
  totpSecret: "JBSWY3DP...",     // TOTP secret
  is2FAVerified: true,
  role: "admin",
  createdAt: "2025-01-11T..."
}
```

### Honeypots Collection
```javascript
{
  name: "SSH Honeypot - Production Server",
  type: "SSH",
  protocol: "ssh",
  port: 22,
  status: "active",
  location: "US-East-1",
  ipAddress: "192.168.1.100",
  attackCount: 1247,
  lastActivity: "2025-01-11T..."
}
```

### Decoy Environments Collection
```javascript
{
  name: "Production Database - Customer Records",
  type: "database",
  status: "active",
  credentials: [
    { username: "admin", password: "admin123", accessLevel: "root" }
  ],
  files: [
    { name: "customers.sql", size: "2.4 GB", isBait: true }
  ],
  services: ["mysql", "postgresql", "redis"],
  accessCount: 34,
  lastAccessed: "2025-01-11T..."
}
```

### Attack Logs Collection
```javascript
{
  sourceIp: "192.168.1.100",
  targetHoneypot: "SSH Honeypot",
  attackType: "SSH Brute Force",
  severity: "high",
  protocol: "tcp",
  payload: "SSH Brute Force detected...",
  location: {
    country: "China",
    city: "Beijing",
    lat: 39.9042,
    lon: 116.4074
  },
  timestamp: "2025-01-11T...",
  blocked: true
}
```

---

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Login (step 1)
- `POST /api/auth/setup-2fa` - Get QR code
- `POST /api/auth/verify-setup` - Verify 2FA setup
- `POST /api/auth/verify-2fa` - Verify 2FA login

### Honeypots
- `GET /api/honeypots` - List all honeypots
- `POST /api/honeypots` - Create honeypot
- `PUT /api/honeypots/:id` - Update honeypot
- `DELETE /api/honeypots/:id` - Delete honeypot

### Decoy Environments
- `GET /api/decoys` - List all decoys
- `POST /api/decoys` - Create decoy
- `PUT /api/decoys/:id` - Update decoy
- `DELETE /api/decoys/:id` - Delete decoy

### Attack Logs
- `GET /api/attacks` - List attacks
- `GET /api/attacks/stats` - Attack statistics
- `POST /api/attacks` - Log new attack

### Threats
- `GET /api/threats` - Threat feed
- `GET /api/threats/stats` - Threat statistics

### System
- `GET /api/health` - Health check

See [API Documentation](./backend/README.md) for details.

---

## 🔐 Security Features

1. **Authentication**
   - JWT tokens (signed, time-limited)
   - bcrypt password hashing (12 rounds)
   - Mandatory 2FA (TOTP)

2. **Authorization**
   - Role-based access control
   - Protected API routes
   - Session management

3. **Protection**
   - Rate limiting (100 req/15min)
   - Helmet security headers
   - CORS policy
   - Input validation
   - SQL injection prevention

4. **Monitoring**
   - Request logging
   - Attack detection
   - Anomaly alerts
   - Audit trail

---

## 🎭 Fake Data Strategy

The system uses **deception** to mislead attackers:

### Fake Credentials (Honeypot Traps)
```
Production Database:
├─ admin / admin123          ← TRAP!
├─ dbuser / database2024     ← TRAP!
└─ backup_user / backup@123  ← TRAP!

Corporate File Server:
├─ administrator / Password123!  ← TRAP!
└─ fileadmin / files2024        ← TRAP!

Git Repository:
├─ git / gitpassword        ← TRAP!
└─ developer / dev@2024     ← TRAP!
```

### Bait Files
```
📄 customers.sql (2.4 GB)           ← FAKE!
📄 company_secrets.docx             ← FAKE!
📄 api_keys.json                    ← FAKE!
📄 .env                             ← FAKE!
📄 aws_credentials.txt              ← FAKE!
```

**When accessed:**
- ✅ Logged to MongoDB
- ✅ IP captured
- ✅ Attack type identified
- ✅ Alert triggered
- ✅ Real system protected

---

## 📊 Technology Stack

### Frontend
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS v4
- shadcn/ui components
- Motion (Framer Motion)
- Recharts (charts)
- Lucide React (icons)

### Backend
- Node.js 18+
- Express.js
- MongoDB + Mongoose
- JWT + bcrypt
- Speakeasy (TOTP)
- Helmet (security)

### Database
- MongoDB Atlas (cloud)
- 4 collections
- Automatic backups
- Global distribution

---

## 📈 Performance

- Frontend load: < 2s
- API response: < 100ms
- Database query: < 50ms
- 2FA verification: < 1s

---

## 🚀 Deployment

### Frontend (Vercel/Netlify)
```bash
# Build
npm run build

# Deploy to Vercel
vercel --prod
```

### Backend (Render/Railway)
```bash
# Set environment variables
MONGODB_URI=mongodb+srv://...
JWT_SECRET=...
SESSION_SECRET=...
NODE_ENV=production

# Deploy
git push render main
```

### Database
Already on MongoDB Atlas! ✅

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [START_HERE.md](./START_HERE.md) | Quick start guide |
| [MONGODB_SETUP.md](./MONGODB_SETUP.md) | Detailed MongoDB setup |
| [VISUAL_SETUP_GUIDE.md](./VISUAL_SETUP_GUIDE.md) | Step-by-step with examples |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | System architecture |
| [backend/README.md](./backend/README.md) | API documentation |
| [BACKEND_IMPLEMENTATION.md](./BACKEND_IMPLEMENTATION.md) | Backend details |

---

## 🧪 Testing

### Test Health Check
```bash
curl http://localhost:5000/api/health
```

### Test Authentication
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"test","email":"test@example.com","password":"Test123!"}'
```

### Test Honeypots
```bash
curl http://localhost:5000/api/honeypots \
  -H "Authorization: Bearer <your-jwt-token>"
```

---

## 🤝 Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

---

## 📝 License

MIT License - See LICENSE file for details

---

## 🙏 Acknowledgments

- **shadcn/ui** - Beautiful UI components
- **Tailwind CSS** - Utility-first CSS
- **MongoDB Atlas** - Cloud database
- **Speakeasy** - TOTP 2FA
- **Motion** - Animation library

---

## 📞 Support

- 📖 Read the [documentation](./START_HERE.md)
- 🐛 Report bugs via issues
- 💡 Request features via issues
- 📧 Contact: support@example.com

---

## 🎯 Roadmap

- [x] MongoDB integration
- [x] Mandatory 2FA authentication
- [x] Fake honeypot data
- [x] Real-time threat feed
- [x] Interactive 3D map
- [ ] WebSocket real-time updates
- [ ] Email notifications
- [ ] Slack integration
- [ ] PDF report generation
- [ ] Machine learning detection
- [ ] Kubernetes deployment

---

## ⚠️ Disclaimer

This system is designed for **cybersecurity professionals** to detect and analyze intrusion attempts. The fake credentials and data are **honeypot traps** designed to mislead attackers. 

**Do not use this system to:**
- Store real sensitive data
- Collect personally identifiable information (PII)
- Violate privacy laws or regulations

**Use responsibly and ethically.**

---

## 📸 Screenshots

### Landing Page
![Landing Page](./docs/screenshots/landing.png)

### Authentication with 2FA
![Auth Page](./docs/screenshots/auth.png)

### Dashboard
![Dashboard](./docs/screenshots/dashboard.png)

### Threat Map
![Threat Map](./docs/screenshots/threat-map.png)

### Decoy Environments
![Decoys](./docs/screenshots/decoys.png)

---

**Built with ❤️ for cybersecurity professionals**

**🛡️ Deception is the new defense. Catch the hacker before the hack.**

---

## 🎉 Get Started Now!

```bash
# Clone and setup
git clone <repository-url>
cd honeypot-defense-grid

# Quick start
cd backend && npm install && cd .. && npm install
cd backend && npm run seed && npm run dev &
npm run dev

# Open browser
http://localhost:5173
```

**Welcome to the Honeypot Defense Grid!** 🚀
