# 🎯 READ ME FIRST - Quick Start

**You're getting a "Tables not found" error. Here's the instant fix!**

---

## 🔥 INSTANT FIX (30 Seconds)

### You just saw this error:
```
Error
⚠️ Tables not found! Please create database tables first.
```

### But you DID create the tables! (You saw "Success. No rows returned")

**The problem:** RLS (Row Level Security) is blocking access!

---

## ⚡ THE FIX

### Step 1: Open Supabase
1. Go to https://supabase.com/dashboard
2. Click your project
3. Click "SQL Editor" (left side)
4. Click "+ New Query" (green button)

### Step 2: Copy This SQL

**Copy the ENTIRE code:**

```sql
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;

CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

### Step 3: Run It
1. Paste into SQL Editor
2. Click green "Run" button
3. Wait for "Success"

### Step 4: Try Seeding Again
Go back to your app → Click "Seed Database"

✅ **IT WILL WORK NOW!**

---

## 🎓 What This Does

**Your original RLS policies:**
```sql
-- Only authenticated users can access tables
USING (auth.role() = 'authenticated')
```

**The problem:**
- When you click "Seed Database", the browser uses an **anon** (anonymous) key
- RLS blocks anon users
- So it can't see the tables!

**The fix:**
```sql
-- Allow BOTH authenticated AND anon users
USING (auth.role() = 'authenticated' OR auth.role() = 'anon')
                                       ^^^^^^^^^^^^^^^^^^^^
                                       This fixes it!
```

---

## 📊 What You'll Get After Seeding

```
✅ Honeypots: 6
   - SSH Honeypot (Port 22)
   - HTTP Server (Port 80)
   - FTP Server (Port 21)
   - SMTP Server (Port 25)
   - MySQL Database (Port 3306)
   - RDP Server (Port 3389)

✅ Decoy Environments: 4
   - Production Database with fake credentials
   - Corporate File Server
   - Git Repository
   - Email Server

✅ Attack Logs: 200
   - From 8 countries
   - 7 attack types
   - Various severity levels
```

---

## 📁 Files You Need

| File | What It Does |
|------|--------------|
| **This file** | Quick fix instructions |
| [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql) | SQL script to run |
| [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md) | Detailed explanation |
| [RLS_EXPLAINED.md](./RLS_EXPLAINED.md) | Why RLS blocks access |
| [ERROR_CHEAT_SHEET.md](./ERROR_CHEAT_SHEET.md) | Quick error reference |

---

## 🎯 Complete Setup Flow

If you're starting from scratch:

1. **Create Tables** ([QUICK_FIX.md](./QUICK_FIX.md))
   - Creates: users, honeypots, decoy_environments, attack_logs
   - Time: 2 minutes

2. **Fix RLS Policies** (This file!)
   - Allows: anon access for seeding
   - Time: 30 seconds

3. **Seed Database** (Click button in app)
   - Inserts: 210 fake records
   - Time: 5 seconds

4. **Done!** Your honeypot is ready! 🎉

---

## ✅ Verification

After running the fix:

1. Click "Seed Database" in your app
2. You should see:
   ```
   Success!
   ✅ Honeypots: 6
   ✅ Decoy Environments: 4
   ✅ Attack Logs: 200
   ```
3. Dashboard should show:
   - Threat statistics (Critical, High, Medium counts)
   - 3D threat map with location pins
   - Attack charts with data
   - Honeypot statuses
   - Decoy environments with credentials
   - Real-time attack feed

---

## ❌ Still Not Working?

**Check these:**

1. **Did you run the SQL?**
   - Supabase SQL Editor should show "Success"

2. **Browser console errors?**
   - Press F12 → Console tab
   - Look for red errors

3. **Tables exist?**
   - Supabase Dashboard → Table Editor
   - Should see 4 tables

4. **Policies updated?**
   - Table Editor → Click table → Policies tab
   - Should see policies allowing "anon"

**Full troubleshooting:** [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

---

## 🎯 Why This Happens

```
┌─────────────┐
│  Your App   │ Uses anon key
└──────┬──────┘
       │
       ↓
┌──────────────────┐
│  RLS Policies    │ "Only authenticated!"
│                  │ ❌ BLOCKS anon
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│  Tables          │ "Not found" error
│  (Hidden by RLS) │
└──────────────────┘
```

**After fix:**

```
┌─────────────┐
│  Your App   │ Uses anon key
└──────┬──────┘
       │
       ↓
┌──────────────────┐
│  RLS Policies    │ "authenticated OR anon!"
│                  │ ✅ ALLOWS anon
└──────┬───────────┘
       │
       ↓
┌──────────────────┐
│  Tables          │ ✅ Success!
│  (Accessible)    │
└──────────────────┘
```

---

## 📚 More Resources

**For first-time setup:**
- [STEP_BY_STEP.md](./STEP_BY_STEP.md) - Complete visual guide

**For this specific error:**
- [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md) - Detailed explanation
- [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql) - SQL to run

**Understanding the issue:**
- [RLS_EXPLAINED.md](./RLS_EXPLAINED.md) - What is RLS?

**Quick reference:**
- [ERROR_CHEAT_SHEET.md](./ERROR_CHEAT_SHEET.md) - All errors & fixes

---

## 🚀 TL;DR

1. **Problem:** RLS blocks anon users
2. **Fix:** Add `OR auth.role() = 'anon'` to policies
3. **How:** Run SQL from [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)
4. **Time:** 30 seconds
5. **Result:** Seeding works! ✅

---

**Go run that SQL now! It will fix your issue instantly.** 🎯

↓ [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql) ↓
