# 🔐 RLS (Row Level Security) Explained

## What is RLS?

**Row Level Security (RLS)** is Supabase's way of controlling who can access your database tables.

Think of it like a bouncer at a club:

```
You (anon key) → 🚫 Bouncer (RLS) → 🎉 Club (Database Tables)
                  "You're not on the list!"
```

---

## The Problem

When you created the tables, you also created RLS policies like this:

```sql
CREATE POLICY "Enable all for authenticated on honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated');
```

This says: **"Only let in authenticated users!"**

But when you click "Seed Database" in your browser, the code uses the **anon key**:

```typescript
// This uses the ANON key (public key)
const supabase = createClient(supabaseUrl, publicAnonKey);
```

So the flow looks like this:

```
Browser
  ↓
Click "Seed Database"
  ↓
Supabase Client (anon key)
  ↓
RLS Policy: "Is user authenticated?"
  ↓
❌ NO! (anon key is not authenticated)
  ↓
🚫 BLOCKED!
  ↓
Error: "Could not find the table"
```

---

## Why "Could not find the table"?

The table EXISTS, but RLS makes it **invisible** to anon users!

It's like the table is behind a locked door. The error message is misleading - it should say "Permission denied" but instead says "table not found".

---

## The Solution

Update the RLS policies to **allow BOTH authenticated AND anon users**:

```sql
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
                                                ^^^^^^^^^^^^^^^^^^^
                                                This allows anon users!
```

Now the flow works:

```
Browser
  ↓
Click "Seed Database"
  ↓
Supabase Client (anon key)
  ↓
RLS Policy: "Is user authenticated OR anon?"
  ↓
✅ YES! (anon is allowed)
  ↓
🎉 ACCESS GRANTED!
  ↓
Data inserted successfully!
```

---

## Visual Comparison

### ❌ BEFORE (Blocked)

```
┌──────────────────────────────────────────────┐
│  Browser Application                         │
│                                              │
│  [Seed Database Button]                     │
│         ↓                                    │
│  Supabase Client (anon key)                 │
└──────────────┬───────────────────────────────┘
               │
               ↓
┌──────────────────────────────────────────────┐
│  Supabase RLS Policies                       │
│                                              │
│  IF auth.role() = 'authenticated'           │
│     THEN allow                               │
│  ELSE                                        │
│     DENY  ← ❌ Anon user blocked!           │
└──────────────┬───────────────────────────────┘
               │
               ↓
┌──────────────────────────────────────────────┐
│  Database Tables                             │
│                                              │
│  🚫 ACCESS DENIED                            │
│  Error: "Could not find the table"          │
└──────────────────────────────────────────────┘
```

### ✅ AFTER (Works)

```
┌──────────────────────────────────────────────┐
│  Browser Application                         │
│                                              │
│  [Seed Database Button]                     │
│         ↓                                    │
│  Supabase Client (anon key)                 │
└──────────────┬───────────────────────────────┘
               │
               ↓
┌──────────────────────────────────────────────┐
│  Supabase RLS Policies                       │
│                                              │
│  IF auth.role() = 'authenticated'           │
│     OR auth.role() = 'anon'  ← ✅ Added!    │
│     THEN allow                               │
└──────────────┬───────────────────────────────┘
               │
               ↓
┌──────────────────────────────────────────────┐
│  Database Tables                             │
│                                              │
│  ✅ ACCESS GRANTED                           │
│  Success: 6 honeypots, 4 decoys, 200 attacks│
└──────────────────────────────────────────────┘
```

---

## User Roles in Supabase

Supabase has different user roles:

| Role | Description | When Used |
|------|-------------|-----------|
| **authenticated** | Logged-in user | After successful login |
| **anon** | Anonymous/public access | Using public anon key |
| **service_role** | Admin/backend access | Server-side only (dangerous!) |

Your browser app uses **anon** when not logged in, even if you're seeding data from the dashboard.

---

## Is This Safe?

**For a honeypot trap? YES!**

The whole point of a honeypot is to be **accessible** to attract attackers. The fake data (honeypots, decoys, attack logs) is MEANT to be public.

In fact, you WANT attackers to see this data - it's part of the trap!

**For sensitive production data? NO!**

If this was real customer data or passwords, you'd want strict RLS policies. But for a honeypot defense system with fake data, allowing anon access is fine.

---

## Alternative Solutions

### Option 1: Login First, Then Seed

Instead of allowing anon access, you could:

1. Login to the dashboard
2. Then click "Seed Database"

This would use your authenticated session. But this requires the seed function to use the authenticated client, which is more complex.

### Option 2: Disable RLS (NOT RECOMMENDED)

```sql
ALTER TABLE honeypots DISABLE ROW LEVEL SECURITY;
```

This removes ALL access controls. Very dangerous!

### Option 3: Use Service Role Key (DANGEROUS)

You could use the service role key (which bypasses RLS), but:
- ⚠️ Service role key has FULL admin access
- ⚠️ If exposed in browser, anyone can delete your entire database
- ⚠️ Should NEVER be used in client-side code

---

## How to Fix

**Run this SQL in Supabase SQL Editor:**

```sql
-- Drop old restrictive policies
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;

-- Create new policies allowing anon access
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

**Or use the file:** [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)

---

## Summary

| Issue | Cause | Solution |
|-------|-------|----------|
| "Tables not found" | RLS blocks anon access | Allow anon in policies |
| Tables exist but invisible | RLS makes them hidden | Update `auth.role()` check |
| Seed button fails | Using anon key | Add `OR auth.role() = 'anon'` |

**Bottom line:** Add `OR auth.role() = 'anon'` to your RLS policies!

---

## Learn More

- **Supabase RLS Docs**: https://supabase.com/docs/guides/auth/row-level-security
- **Auth Roles**: https://supabase.com/docs/guides/auth/managing-user-data

---

**After fixing RLS, the Seed Database button will work!** ✅
