# 🔧 FIX: "Tables Not Found" Error When Seeding

## Problem

You see this error after clicking "Seed Database":

```
Error
⚠️ Tables not found! Please create database tables first.
```

But you **already created the tables** (you saw "Success. No rows returned" in Supabase).

---

## Why This Happens

The tables exist, BUT the **Row Level Security (RLS) policies** are blocking access!

The RLS policies you created only allow **authenticated users** to access the tables. But when you click "Seed Database", the Supabase client uses the **anon key**, which is blocked by RLS.

```
Supabase Client (anon key)  ──X──> RLS Policies ──X──> Tables
                               ❌ BLOCKED!
```

---

## The Fix (30 seconds)

### Step 1: Go to Supabase

1. Open https://supabase.com/dashboard
2. Click your project
3. Click "SQL Editor" (left sidebar)
4. Click "+ New Query"

### Step 2: Copy & Run This SQL

Copy this ENTIRE code:

```sql
-- Drop old restrictive policies
DROP POLICY IF EXISTS "Enable read for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON honeypots;
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;

DROP POLICY IF EXISTS "Enable read for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;

DROP POLICY IF EXISTS "Enable read for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable insert for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable update for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable delete for authenticated users" ON attack_logs;
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;

-- Create new policies that allow BOTH authenticated AND anon
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

### Step 3: Paste & Click Run

1. Paste into SQL Editor
2. Click green "Run" button
3. Wait for "Success"

### Step 4: Try Seeding Again

Go back to your app → Click "Seed Database"

✅ **It should work now!**

---

## What Changed?

**Before (BLOCKED):**
```sql
-- Only authenticated users allowed
CREATE POLICY "Enable all" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated');
```

**After (WORKS):**
```sql
-- Both authenticated AND anon users allowed
CREATE POLICY "Enable all" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

---

## How It Works Now

```
Browser → Supabase Client (anon key) → RLS Policies → ✅ Tables
                                       (anon allowed!)
```

The `OR auth.role() = 'anon'` part allows the browser to seed data using the anonymous/public key.

---

## Is This Safe?

**For a production honeypot system? NO.**

**For prototyping/development? YES.**

This is a **honeypot trap** - the fake data is MEANT to be accessible to attract attackers. In a real deployment, you'd want tighter security, but for this demo/prototype, allowing anon access is fine.

If you want to restrict it later, just remove the `OR auth.role() = 'anon'` part from the policies.

---

## Alternative: Use Service Role Key

Instead of allowing anon access, you could use the **service role key** (which bypasses RLS):

1. Go to Supabase Dashboard → Settings → API
2. Copy "service_role" key (⚠️ keep this secret!)
3. Update `/utils/supabase/client.ts`:

```typescript
// For seeding only - use service role
const supabaseUrl = `https://${projectId}.supabase.co`;
const serviceKey = 'YOUR_SERVICE_ROLE_KEY_HERE'; // ⚠️ Don't commit this!

export const supabaseAdmin = createClient(supabaseUrl, serviceKey);
```

But this is MORE DANGEROUS because the service key has full access to everything!

---

## Summary

**Problem**: RLS policies blocked anon access
**Solution**: Update policies to allow `auth.role() = 'anon'`
**Time**: 30 seconds
**File**: Run SQL from `FIX_RLS_POLICIES.sql`

---

✅ **After running the fix, seeding will work!**

You'll see:
```
Success!
✅ Honeypots: 6
✅ Decoy Environments: 4
✅ Attack Logs: 200
```

---

## Still Not Working?

1. **Check browser console** (F12) for errors
2. **Verify tables exist**: Supabase Dashboard → Table Editor
3. **Check policies applied**: 
   - Go to Table Editor → Click on table → Policies tab
   - You should see policies allowing `anon` role
4. **Clear cache**: Hard refresh with Ctrl+Shift+R

See [TROUBLESHOOTING.md](./TROUBLESHOOTING.md) for more help.
