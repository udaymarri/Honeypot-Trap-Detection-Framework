# ✅ Setup Checklist

Print this page or keep it open while you set up the system.

---

## 📋 Pre-Installation

- [ ] Node.js 18+ installed
  ```bash
  node --version  # Should be v18 or higher
  ```

- [ ] npm installed
  ```bash
  npm --version   # Should be 9 or higher
  ```

- [ ] MongoDB Atlas account created
  - [ ] Username: `ganeshmunaga`
  - [ ] Password saved somewhere safe
  - [ ] Cluster created: `cluster0.15rkrdo.mongodb.net`

- [ ] Google Authenticator app installed on phone
  - iOS: App Store
  - Android: Google Play

---

## 🔧 MongoDB Atlas Configuration

- [ ] Logged into MongoDB Atlas: https://cloud.mongodb.com/
- [ ] Network Access configured:
  - [ ] Current IP whitelisted OR
  - [ ] 0.0.0.0/0 added (development only)
- [ ] Database user verified:
  - [ ] Username: `ganeshmunaga` exists
  - [ ] Password is known/reset
  - [ ] Permissions: "Read and write to any database"

---

## 📦 Backend Setup

- [ ] Navigated to backend folder
  ```bash
  cd backend
  ```

- [ ] Environment file configured:
  - [ ] `.env` file exists
  - [ ] `MONGODB_URI` has correct password
  - [ ] Special characters in password are URL-encoded
  - [ ] `JWT_SECRET` is a random 64-character string
  - [ ] `SESSION_SECRET` is a different random 64-character string
  - [ ] `PORT` is set to 5000
  - [ ] `FRONTEND_URL` is http://localhost:5173

- [ ] Dependencies installed
  ```bash
  npm install
  ```
  - [ ] No errors during installation
  - [ ] `node_modules` folder created

- [ ] Database seeded
  ```bash
  npm run seed
  ```
  - [ ] "Connected to MongoDB Atlas" message appears
  - [ ] "Inserted 6 honeypots" message appears
  - [ ] "Inserted 4 decoy environments" message appears
  - [ ] "Inserted 200 attack logs" message appears
  - [ ] No error messages

- [ ] Backend starts successfully
  ```bash
  npm run dev
  ```
  - [ ] "Server running on port 5000" message appears
  - [ ] "MongoDB: Connected" message appears
  - [ ] No error messages
  - [ ] Terminal stays open (server is running)

---

## 🎨 Frontend Setup

- [ ] Navigated to root folder
  ```bash
  cd ..
  ```

- [ ] Dependencies installed
  ```bash
  npm install
  ```
  - [ ] No errors during installation
  - [ ] `node_modules` folder created

- [ ] Environment file configured:
  - [ ] `.env` file exists
  - [ ] `VITE_API_URL=http://localhost:5000/api`
  - [ ] `VITE_ENABLE_MOCK_DATA=false`

- [ ] Frontend starts successfully
  ```bash
  npm run dev
  ```
  - [ ] "Local: http://localhost:5173/" message appears
  - [ ] No error messages
  - [ ] Terminal stays open (server is running)

---

## 🧪 Testing

### Backend Health Check

- [ ] Open: http://localhost:5000/api/health
- [ ] Response shows:
  ```json
  {
    "status": "online",
    "database": "connected",
    "version": "2.4.1"
  }
  ```

### Honeypots Endpoint

- [ ] Open: http://localhost:5000/api/honeypots
- [ ] Response shows list of 6 honeypots
- [ ] SSH, HTTP, FTP, SMTP, MySQL, RDP honeypots visible

### Decoys Endpoint

- [ ] Open: http://localhost:5000/api/decoys
- [ ] Response shows list of 4 decoy environments
- [ ] Fake credentials visible (admin/admin123, etc.)

### Frontend

- [ ] Open: http://localhost:5173
- [ ] Landing page loads
- [ ] "Honeypot Defense Grid" title visible
- [ ] "Get Started" button visible
- [ ] Matrix background animating
- [ ] No console errors (F12 to check)

---

## 🔐 Account Creation

- [ ] Clicked "Get Started" on landing page
- [ ] Auth modal appeared
- [ ] Clicked "Sign Up" tab
- [ ] Filled in registration form:
  - [ ] Username entered
  - [ ] Email entered
  - [ ] Password entered (8+ characters)
  - [ ] Confirm password matches
- [ ] Clicked "Create Account"
- [ ] 2FA setup page appeared

---

## 📱 2FA Setup

- [ ] QR code is visible on screen
- [ ] Manual entry key is displayed
- [ ] Google Authenticator app is open on phone
- [ ] Tapped "+" in Google Authenticator
- [ ] Chose "Scan a QR code"
- [ ] Scanned QR code successfully
- [ ] Entry added as "Honeypot Defense Grid"
- [ ] 6-digit code is visible in app
- [ ] Code entered in web interface
- [ ] Clicked "Verify & Complete Setup"
- [ ] Success! Dashboard appeared

---

## 🎯 Dashboard Verification

- [ ] Dashboard loaded successfully
- [ ] Header shows "Honeypot Defense Grid"
- [ ] Threat statistics cards visible:
  - [ ] Total attacks shown
  - [ ] Active threats shown
  - [ ] Blocked intrusions shown
  - [ ] Critical alerts shown
- [ ] Threat map is visible
- [ ] Attack chart is visible
- [ ] Decoy environments section visible
- [ ] Fake credentials displayed (admin/admin123, etc.)
- [ ] Command logs visible
- [ ] Honeypot status visible
- [ ] No loading spinners (data loaded from MongoDB)
- [ ] No error messages

---

## 🔍 Data Verification

### Check MongoDB Compass (Optional)

- [ ] Downloaded MongoDB Compass
- [ ] Connected using connection string
- [ ] Database "honeypot-defense" exists
- [ ] Collections visible:
  - [ ] `users` (at least 1 document - your account)
  - [ ] `honeypots` (6 documents)
  - [ ] `decoyenvironments` (4 documents)
  - [ ] `attacklogs` (200 documents)

### Check Using mongosh (Optional)

```bash
mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/honeypot-defense"
```

- [ ] Connection successful
- [ ] Tested commands:
  ```javascript
  db.honeypots.countDocuments()        // Should return 6
  db.decoyenvironments.countDocuments() // Should return 4
  db.attacklogs.countDocuments()        // Should return 200
  ```

---

## 🚀 Final Checks

### Both Servers Running

- [ ] Backend terminal shows: "Server running on port 5000"
- [ ] Frontend terminal shows: "Local: http://localhost:5173/"
- [ ] Both terminals are still open

### Browser

- [ ] Tab 1: Dashboard at http://localhost:5173
- [ ] No console errors (press F12)
- [ ] All components loaded
- [ ] Data is from MongoDB (not mock data)

### Authentication

- [ ] Can log out
- [ ] Can log back in
- [ ] 2FA code from Google Authenticator works
- [ ] JWT token is stored (check sessionStorage)

---

## 📝 Notes Section

Write down any issues or observations:

```
_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________

_________________________________________________________________
```

---

## ✅ All Done!

If all checkboxes are checked, you're ready to go! 🎉

### What to Do Next:

1. **Explore the Dashboard**
   - Check the threat map
   - View attack charts
   - Examine decoy environments
   - Monitor honeypot status

2. **Test Features**
   - Add a new honeypot
   - Create a decoy environment
   - View attack logs
   - Configure alerts

3. **Read Documentation**
   - [START_HERE.md](./START_HERE.md)
   - [MONGODB_SETUP.md](./MONGODB_SETUP.md)
   - [ARCHITECTURE.md](./ARCHITECTURE.md)

4. **Customize**
   - Add more honeypots
   - Create custom decoys
   - Adjust alert thresholds
   - Configure notifications

---

## 🆘 Troubleshooting

If any checkbox is not checked, see:

- **MongoDB Issues**: [MONGODB_SETUP.md](./MONGODB_SETUP.md) - Section 8
- **Backend Issues**: [backend/README.md](./backend/README.md)
- **Frontend Issues**: [START_HERE.md](./START_HERE.md)
- **2FA Issues**: Check debug panel on setup page

---

## 📊 System Status Summary

```
┌─────────────────────────────────────────┐
│  Component         Status    Port       │
├─────────────────────────────────────────┤
│  MongoDB Atlas     [    ]    27017      │
│  Backend API       [    ]    5000       │
│  Frontend          [    ]    5173       │
│  Authentication    [    ]    N/A        │
│  2FA               [    ]    N/A        │
│  Database Seed     [    ]    N/A        │
└─────────────────────────────────────────┘

Legend: [✅] Working  [❌] Not Working  [⚠️] Issues
```

Fill in the boxes above with your actual status!

---

## 🎉 Completion

**Date Completed**: ___________________

**Time Taken**: ___________________

**Issues Encountered**: ___________________

**Notes**: 
```
_________________________________________________________________

_________________________________________________________________

_________________________________________________________________
```

---

**Congratulations! Your Honeypot Defense Grid is operational!** 🛡️

**Keep this checklist for future reference or troubleshooting.**
