# ✅ Setup Checklist - Simple Version

**Follow this exact order to avoid errors!**

---

## Step 1: Create Tables in Supabase

- [ ] Go to https://supabase.com/dashboard
- [ ] Click "SQL Editor" → "+ New Query"
- [ ] Copy SQL from [QUICK_FIX.md](./QUICK_FIX.md)
- [ ] Paste and click "Run"
- [ ] See "Success. No rows returned"
- [ ] **Verify:** Table Editor shows 4 tables

**Time:** 2 minutes

---

## Step 2: Fix RLS Policies

- [ ] Still in SQL Editor → "+ New Query"
- [ ] Copy SQL from [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)
- [ ] Paste and click "Run"
- [ ] See "Success"

**Time:** 30 seconds

**Why:** Allows browser to seed data (see [RLS_EXPLAINED.md](./RLS_EXPLAINED.md))

---

## Step 3: Start Your App

- [ ] Open VS Code terminal
- [ ] Run: `npm install`
- [ ] Run: `npm run dev`
- [ ] Open: http://localhost:5173

**Time:** 1 minute

---

## Step 4: Register & Login

- [ ] Click "Get Started"
- [ ] Click "Sign Up" tab
- [ ] Fill in:
  - Username: `admin`
  - Email: `admin@example.com`
  - Password: `Admin123!`
- [ ] Click "Register"
- [ ] Scan QR code with Google Authenticator
- [ ] Enter 6-digit code
- [ ] Click "Verify"
- [ ] See dashboard!

**Time:** 2 minutes

---

## Step 5: Seed Database

- [ ] Scroll down in dashboard
- [ ] Find "Database Seeder" card (cyan icon)
- [ ] Click "Seed Database" button
- [ ] Wait 5-10 seconds
- [ ] See success message:
  ```
  ✅ Honeypots: 6
  ✅ Decoy Environments: 4
  ✅ Attack Logs: 200
  ```

**Time:** 10 seconds

---

## Step 6: Verify Everything Works

- [ ] Dashboard shows threat statistics (not all zeros)
- [ ] 3D threat map has location pins
- [ ] Attack charts have data
- [ ] Honeypot Status shows 6 honeypots
- [ ] Decoy Environments shows 4 environments
- [ ] Attack feed shows log entries
- [ ] Command Log shows activity

---

## ✅ Done!

Your Honeypot Defense Grid is now fully operational! 🎉

---

## ❌ Having Issues?

**Common errors and fixes:**

| Error | Fix |
|-------|-----|
| "Tables not found" | [READ_ME_FIRST.md](./READ_ME_FIRST.md) |
| "Permission denied" | [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql) |
| "Invalid 2FA code" | Wait for new code, type quickly |
| "Port already in use" | Run: `pkill -f vite` |
| No data in dashboard | Click "Seed Database" button |

**Full troubleshooting:** [TROUBLESHOOTING.md](./TROUBLESHOOTING.md)

---

## 📊 What You Should See

### After Step 5 (Seeding):

**Honeypots (6 total):**
- SSH Honeypot - Production Server (Port 22)
- HTTP Server - Web Portal (Port 80)
- FTP Server - File Storage (Port 21)
- SMTP Mail Server (Port 25)
- MySQL Database Server (Port 3306)
- RDP Windows Server (Port 3389)

**Decoy Environments (4 total):**
- Production Database - Customer Records
- Corporate File Server
- Development Git Repository
- Email Server - Exchange

**Attack Logs (200 total):**
- From China, Russia, USA, Brazil, India, Germany, UK, Japan
- Attack types: SQL Injection, SSH Brute Force, Port Scan, DDoS, etc.
- Various severity levels: Critical, High, Medium, Low

---

## 🎯 Total Time

**If everything goes smoothly:** 5-6 minutes

**Common path:**
1. Create tables (2 min)
2. Fix RLS (30 sec)
3. Install & start (1 min)
4. Register & login (2 min)
5. Seed database (10 sec)

---

## 🆘 Need Help?

**Read these in order:**

1. **[READ_ME_FIRST.md](./READ_ME_FIRST.md)** - Most common error fix
2. **[ERROR_CHEAT_SHEET.md](./ERROR_CHEAT_SHEET.md)** - Quick error lookup
3. **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** - Comprehensive solutions
4. **[STEP_BY_STEP.md](./STEP_BY_STEP.md)** - Detailed walkthrough

---

## 💡 Pro Tips

1. **Keep browser console open (F12)** - Catch errors immediately
2. **Check Supabase Table Editor** - Verify data exists
3. **Read error messages carefully** - They usually tell you what's wrong
4. **One step at a time** - Don't skip ahead
5. **The fix is almost always RLS** - Run [FIX_RLS_POLICIES.sql](./FIX_RLS_POLICIES.sql)

---

**Ready? Start with Step 1!** 🚀
