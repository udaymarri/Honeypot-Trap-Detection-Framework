# 🚀 Quick Start Guide

Get your Honeypot Defense Grid up and running in 5 minutes!

---

## ⚡ Lightning Fast Setup

### Step 1: Get Your MongoDB Password

You have this connection string:
```
mongodb+srv://ganeshmunaga@cluster0.15rkrdo.mongodb.net/
```

1. Go to [MongoDB Atlas](https://cloud.mongodb.com/)
2. Log in with username: `ganeshmunaga`
3. Click **Database Access** → Find your user → Click **Edit**
4. Copy your password (or reset it if you forgot)

---

### Step 2: Configure Backend

```bash
# Navigate to backend folder
cd backend

# Edit the .env file
nano .env   # or use any text editor
```

**Replace this line:**
```env
MONGODB_URI=mongodb+srv://ganeshmunaga:YOUR_PASSWORD_HERE@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority
```

**With your actual password:**
```env
MONGODB_URI=mongodb+srv://ganeshmunaga:MyActualPassword123@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority
```

⚠️ **Important**: If your password contains special characters like `@`, `#`, `%`, etc., you need to URL encode them:
- `@` becomes `%40`
- `#` becomes `%23`
- `%` becomes `%25`
- etc.

---

### Step 3: Whitelist Your IP in MongoDB Atlas

1. Go to [MongoDB Atlas](https://cloud.mongodb.com/)
2. Click **Network Access** (left sidebar)
3. Click **Add IP Address**
4. Choose **Add Current IP Address**
5. Click **Confirm**

**For Development Only**: You can also click **Allow Access from Anywhere** (0.0.0.0/0), but **NEVER** use this in production!

---

### Step 4: Install & Start

```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ..
npm install

# Seed the database with fake honeypot data
cd backend
npm run seed

# Start backend (Terminal 1)
npm run dev

# In a new terminal, start frontend (Terminal 2)
cd ..
npm run dev
```

---

## ✅ Verify It's Working

### Check 1: Backend Health

Open: http://localhost:5000/api/health

Should see:
```json
{
  "status": "online",
  "database": "connected",
  "version": "2.4.1"
}
```

### Check 2: Frontend

Open: http://localhost:5173

Should see the Honeypot Defense Grid landing page.

---

## 🎯 First Login

1. Click **Get Started**
2. Click **Sign Up** tab
3. Create account:
   - Username: `testadmin`
   - Email: `test@example.com`
   - Password: `Test123!`
4. Scan QR code with Google Authenticator app
5. Enter 6-digit code
6. You're in! 🎉

---

## 🐛 Something Not Working?

### Backend won't start?

**Error: MongoDB connection error**

✅ **Fix:**
1. Double-check your password in `backend/.env`
2. Make sure your IP is whitelisted in MongoDB Atlas
3. Try this test:
   ```bash
   mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/"
   ```

**Error: Port 5000 already in use**

✅ **Fix:**
```bash
# Find what's using port 5000
lsof -i :5000   # Mac/Linux
netstat -ano | findstr :5000   # Windows

# Kill the process or change PORT in backend/.env
```

---

### Frontend won't connect?

**Error: Unable to connect to server**

✅ **Fix:**
1. Make sure backend is running: `cd backend && npm run dev`
2. Check `.env` file has: `VITE_API_URL=http://localhost:5000/api`
3. Restart frontend: `npm run dev`

---

### CORS errors in browser console?

✅ **Fix:**

Edit `backend/server.js`:
```javascript
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}));
```

---

## 📊 View Your Fake Data

After seeding, you can view the fake honeypot data:

### In MongoDB Compass (GUI):
1. Download [MongoDB Compass](https://www.mongodb.com/products/compass)
2. Connect with your connection string
3. Browse `honeypot-defense` database
4. View collections:
   - `honeypots` - 6 fake honeypots
   - `decoyenvironments` - 4 decoy systems with fake credentials
   - `attacklogs` - 200 fake attack logs

### Using mongosh (CLI):
```bash
mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/honeypot-defense"

# View honeypots
db.honeypots.find().pretty()

# View decoy environments
db.decoyenvironments.find().pretty()

# View attack logs
db.attacklogs.find().limit(10).pretty()

# Count records
db.honeypots.countDocuments()
db.decoyenvironments.countDocuments()
db.attacklogs.countDocuments()
```

---

## 🎨 What You'll See

After logging in, the dashboard shows:

1. **Threat Statistics**
   - Total attacks detected
   - Active threats
   - Blocked intrusions
   - Critical alerts

2. **Interactive 3D Threat Map**
   - Real-time attack origins
   - Geographic visualization
   - Attack type indicators

3. **Attack Charts**
   - Time-series attack data
   - Attack type distribution
   - Severity breakdown

4. **Decoy Environments**
   - Fake systems to mislead attackers
   - Compromised credentials (fake!)
   - Bait files and services

5. **Command Logs**
   - Captured attacker commands
   - SSH/FTP/HTTP interactions
   - Payload analysis

6. **Honeypot Status**
   - Active honeypots
   - Port configurations
   - Attack counts per honeypot

---

## 🔐 Test the Fake Data

The seed script created fake credentials in MongoDB:

### Decoy Database Server:
```
admin / admin123
dbuser / database2024
```

### Decoy File Server:
```
administrator / Password123!
fileadmin / files2024
```

### Decoy Git Repository:
```
git / gitpassword
developer / dev@2024
```

These are **NOT REAL** - they're honeypot traps! If an attacker tries to use them, they'll be logged in the attack logs.

---

## 📁 Project Structure

```
honeypot-defense/
├── backend/                 # Node.js API server
│   ├── models/             # MongoDB models
│   ├── routes/             # API endpoints
│   ├── scripts/            # Database seed script
│   ├── server.js           # Main server file
│   └── .env                # Backend config (SECRET!)
│
├── components/             # React components
├── services/               # API services
│   ├── api.ts             # Backend API calls
│   ├── mockBackend.ts     # Mock data (deprecated)
│   └── totp.ts            # 2FA authentication
│
├── App.tsx                # Main React app
├── .env                   # Frontend config
└── START_HERE.md          # This file!
```

---

## 🎯 Next Steps

1. ✅ Explore the dashboard
2. ✅ View fake honeypot data
3. ✅ Check attack logs from different countries
4. ✅ Test 2FA authentication
5. ✅ Add custom honeypots
6. ✅ Configure alert settings
7. ✅ Export threat intelligence

---

## 📚 More Documentation

- **Detailed Setup**: See [MONGODB_SETUP.md](./MONGODB_SETUP.md)
- **API Documentation**: See [backend/README.md](./backend/README.md)
- **Backend Implementation**: See [BACKEND_IMPLEMENTATION.md](./BACKEND_IMPLEMENTATION.md)

---

## 🆘 Still Need Help?

1. Check the backend terminal for errors
2. Check the frontend browser console (F12)
3. Review MongoDB Atlas logs
4. Test API endpoints with curl:
   ```bash
   curl http://localhost:5000/api/health
   curl http://localhost:5000/api/honeypots
   ```

---

**Ready? Let's go! 🚀**

```bash
# Terminal 1 - Backend
cd backend
npm run dev

# Terminal 2 - Frontend  
npm run dev

# Open browser
http://localhost:5173
```

**Welcome to the Honeypot Defense Grid!** 🛡️
