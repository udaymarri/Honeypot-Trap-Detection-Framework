# 🎯 Step-by-Step Supabase Setup

**Follow these exact steps to get your Honeypot Defense Grid working.**

---

## ⚠️ IMPORTANT: Do These Steps IN ORDER

---

## Step 1: Open Supabase Dashboard

1. **Open your browser**
2. **Go to**: https://supabase.com/dashboard
3. **Login** to your account
4. **Click** on your project (you should already have one connected)

✅ You should see your project dashboard

---

## Step 2: Open SQL Editor

1. **Look at the left sidebar**
2. **Click** on "SQL Editor" (it has a database icon)
3. **Click** the green "+ New Query" button (top right)

✅ You should see an empty SQL editor window

---

## Step 3: Copy the SQL Code

**Copy this ENTIRE code block** (click the copy button):

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Honeypots table
CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Decoy Environments table
CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Attack Logs table
CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_attack_logs_blocked ON attack_logs(blocked);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);
CREATE INDEX IF NOT EXISTS idx_decoy_environments_status ON decoy_environments(status);

-- Enable Row Level Security (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow authenticated AND anon users for browser-based seeding)
-- Users table
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Enable insert for authenticated users" ON users
  FOR INSERT WITH CHECK (true);

-- Honeypots table - Allow anon access for seeding
CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

-- Decoy Environments table - Allow anon access for seeding
CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

-- Attack Logs table - Allow anon access for seeding
CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

---

## Step 4: Paste and Run

1. **Click** inside the SQL editor (the big text box)
2. **Paste** the SQL code (Ctrl+V or Cmd+V)
3. **Click** the green "Run" button (bottom right corner)
4. **Wait** 2-3 seconds

✅ You should see: **"Success. No rows returned"** at the bottom

❌ If you see an error, make sure you copied the ENTIRE SQL code above

---

## Step 5: Verify Tables Were Created

1. **Click** "Table Editor" in the left sidebar
2. **You should see 4 tables**:
   - `users`
   - `honeypots`
   - `decoy_environments`
   - `attack_logs`

✅ If you see these 4 tables, you're done with database setup!

---

## Step 6: Start Your App

**Open VS Code Terminal** and run:

```bash
npm run dev
```

✅ You should see:
```
➜  Local:   http://localhost:5173/
```

---

## Step 7: Open in Browser

1. **Click** the link in terminal: http://localhost:5173
2. **Click** "Get Started"
3. **Click** "Sign Up" tab
4. **Register** with:
   - Username: `admin`
   - Email: `admin@example.com`
   - Password: `Admin123!`

✅ You should see a QR code for Google Authenticator

---

## Step 8: Setup 2FA

1. **Open Google Authenticator** on your phone
2. **Tap** the + button
3. **Scan** the QR code on screen
4. **Enter** the 6-digit code from your phone
5. **Click** "Verify"

✅ You should now see the dashboard!

---

## Step 9: Seed the Database

1. **Scroll down** in the dashboard
2. **Look for** "Database Seeder" card (cyan database icon)
3. **Click** "Seed Database" button
4. **Wait** 5-10 seconds

✅ You should see:
```
Success!
✅ Honeypots: 6
✅ Decoy Environments: 4
✅ Attack Logs: 200
```

---

## 🎉 Done!

Your dashboard should now show:
- ✅ Threat stats (Critical, High, Medium threats)
- ✅ 3D threat map with locations
- ✅ Attack charts
- ✅ 6 honeypots monitoring different protocols
- ✅ Decoy environments with fake credentials
- ✅ Real-time attack logs

---

## ❌ Troubleshooting

### "Could not find the table"
**Solution**: You skipped Step 3-4. Go back and run the SQL script.

### "permission denied for table"
**Solution**: You didn't run the RLS policies. Run the ENTIRE SQL script again.

### "No data showing in dashboard"
**Solution**: Click the "Seed Database" button (Step 9).

### "Port 5173 already in use"
**Solution**: Kill the process:
```bash
pkill -f vite
npm run dev
```

### "2FA code invalid"
**Solution**: Make sure you're entering the code from Google Authenticator quickly (codes expire every 30 seconds).

---

## 📊 What You Should See After Seeding

### Honeypots Created:
1. **SSH Honeypot** - Port 22 (Production Server)
2. **HTTP Server** - Port 80 (Web Portal)
3. **FTP Server** - Port 21 (File Storage)
4. **SMTP Mail Server** - Port 25
5. **MySQL Database** - Port 3306
6. **RDP Windows Server** - Port 3389

### Decoy Environments with Fake Credentials:

**1. Production Database - Customer Records**
- `admin` / `admin123` (root access)
- `dbuser` / `database2024` (read-write)
- `backup_user` / `backup@123` (read-only)

**2. Corporate File Server**
- `administrator` / `Password123!` (admin)
- `fileadmin` / `files2024` (read-write)

**3. Development Git Repository**
- `git` / `gitpassword` (read-write)
- `developer` / `dev@2024` (contributor)

**4. Email Server - Exchange**
- `postmaster` / `mail123` (admin)
- `support@company.com` / `Support2024` (user)

### Attack Logs:
200 fake attacks from:
- 🇨🇳 China (Beijing)
- 🇷🇺 Russia (Moscow)
- 🇺🇸 USA (New York)
- 🇧🇷 Brazil (São Paulo)
- 🇮🇳 India (Mumbai)
- 🇩🇪 Germany (Berlin)
- 🇬🇧 UK (London)
- 🇯🇵 Japan (Tokyo)

Attack types:
- SQL Injection
- SSH Brute Force
- Port Scan
- DDoS
- Malware Upload
- XSS
- RCE Attempt

---

## 🎯 Quick Reference

| Action | Command |
|--------|---------|
| **Start app** | `npm run dev` |
| **Stop app** | `Ctrl+C` |
| **View logs** | Check browser console (F12) |
| **View data** | Supabase Dashboard → Table Editor |
| **Reset data** | Click "Seed Database" again |

---

## 📞 Need More Help?

- **Detailed guide**: [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md)
- **VS Code setup**: [VS_CODE_SETUP.md](./VS_CODE_SETUP.md)
- **Full documentation**: [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)

---

**You're all set! Welcome to the Honeypot Defense Grid!** 🛡️
