# ⚡ Supabase Quick Start Guide

**Get your Honeypot Defense Grid running with Supabase in 3 steps!**

---

## 🎯 Overview

Your app is now using **Supabase** instead of MongoDB + Node.js backend!

### ✅ Benefits:
- **No separate backend server needed**
- **Everything runs in the browser** (VS Code terminal only needs `npm run dev`)
- **Automatic authentication** with Supabase Auth
- **Real-time data sync**
- **Secure by default** with Row Level Security

---

## 🚀 3-Step Setup

### Step 1: Create Database Tables

1. **Open Supabase Dashboard**
   - Go to: https://supabase.com/dashboard
   - Select your project
   - Click **SQL Editor** (left sidebar)
   - Click **+ New Query**

2. **Copy & Paste This SQL:**

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Honeypots table
CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Decoy Environments table
CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Attack Logs table
CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);

-- Enable Row Level Security (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow authenticated users to read/write)
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Enable insert for authenticated users" ON users
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable all for authenticated users on honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Enable all for authenticated users on decoys" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Enable all for authenticated users on attacks" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated');
```

3. **Click "Run"** (or press Ctrl/Cmd + Enter)
4. **Verify Success** - You should see "Success. No rows returned"

---

### Step 2: Start the App

```bash
# In VS Code terminal
npm run dev
```

**That's it!** Open http://localhost:5173

---

### Step 3: Seed the Database (One-Time)

After registering and logging in, you'll see a **"Database Seeder"** section in your dashboard.

Click **"Seed Database"** to populate with fake data:
- 6 Honeypots
- 4 Decoy Environments with fake credentials
- 200 Attack Logs from various countries

---

## ✅ Verification

### Check Tables Were Created

1. Go to Supabase Dashboard → **Table Editor**
2. You should see 4 tables:
   - `users`
   - `honeypots`
   - `decoy_environments`
   - `attack_logs`

### Test the App

1. **Open**: http://localhost:5173
2. **Click**: "Get Started"
3. **Register**: Create a new account
4. **Setup 2FA**: Scan QR code with Google Authenticator
5. **Verify**: Enter 6-digit code
6. **Dashboard**: You're in!
7. **Seed Data**: Click the "Seed Database" button

---

## 🎭 Fake Data Created

After seeding, you'll have:

### Honeypots (6):
```
SSH Honeypot - Production Server (port 22)
HTTP Server - Web Portal (port 80)
FTP Server - File Storage (port 21)
SMTP Mail Server (port 25)
MySQL Database Server (port 3306)
RDP Windows Server (port 3389)
```

### Decoy Environments (4) with Fake Credentials:

**1. Production Database - Customer Records**
- `admin` / `admin123` (root)
- `dbuser` / `database2024` (read-write)
- `backup_user` / `backup@123` (read-only)
- Files: customers.sql (2.4 GB), financial_records.csv

**2. Corporate File Server**
- `administrator` / `Password123!` (admin)
- `fileadmin` / `files2024` (read-write)
- Files: company_secrets.docx, salary_data_2024.xlsx, api_keys.json

**3. Development Git Repository**
- `git` / `gitpassword` (read-write)
- `developer` / `dev@2024` (contributor)
- Files: .env, config.production.js, aws_credentials.txt

**4. Email Server - Exchange**
- `postmaster` / `mail123` (admin)
- `support@company.com` / `Support2024` (user)
- Files: inbox_backup.pst (1.2 GB), contacts.csv

### Attack Logs (200):
- Attack types: SQL Injection, SSH Brute Force, Port Scan, DDoS, XSS, RCE
- Severities: Critical, High, Medium, Low
- Countries: China, Russia, USA, Brazil, India, Germany, UK, Japan

---

## 🔧 How It Works

### Architecture

```
┌─────────────────────────────────────────┐
│           Your Browser                   │
│      http://localhost:5173               │
│                                          │
│  React App + Supabase Client            │
└───────────────┬─────────────────────────┘
                │
                │ Direct Connection
                │ (No backend server!)
                ▼
┌─────────────────────────────────────────┐
│         Supabase Cloud                   │
│                                          │
│  ✅ PostgreSQL Database                 │
│  ✅ Authentication (2FA)                 │
│  ✅ Row Level Security                   │
│  ✅ Real-time Subscriptions              │
│  ✅ Automatic Backups                    │
└─────────────────────────────────────────┘
```

### API Service

Your app uses `/services/supabaseApi.ts` which provides:

```typescript
// Authentication
AuthAPI.register(username, email, password)
AuthAPI.login(email, password)
AuthAPI.setup2FA(userId)
AuthAPI.verify2FA(userId, code)
AuthAPI.logout()

// Honeypots
HoneypotsAPI.getAll()
HoneypotsAPI.create(honeypot)
HoneypotsAPI.update(id, updates)
HoneypotsAPI.delete(id)

// Decoy Environments
DecoysAPI.getAll()
DecoysAPI.create(decoy)
DecoysAPI.update(id, updates)
DecoysAPI.delete(id)

// Attack Logs
AttacksAPI.getAll(limit)
AttacksAPI.getStats()
AttacksAPI.log(attack)

// Threats
ThreatsAPI.getFeed(limit)
ThreatsAPI.getStats()
```

---

## 🆚 Comparison: Supabase vs Node.js Backend

| Aspect | Supabase (Current) | Node.js + MongoDB |
|--------|-------------------|-------------------|
| **Setup** | ✅ Run SQL once | ⚠️ Configure MongoDB, install deps, start server |
| **Running** | ✅ Just `npm run dev` | ⚠️ Need 2 terminals (backend + frontend) |
| **Security** | ✅ Built-in RLS | ⚠️ Custom code required |
| **Auth** | ✅ Built-in | ⚠️ JWT implementation needed |
| **Real-time** | ✅ Built-in subscriptions | ⚠️ WebSocket setup needed |
| **Deployment** | ✅ One-click (frontend only) | ⚠️ Deploy 2 services |
| **Database** | ✅ PostgreSQL (cloud) | ⚠️ MongoDB Atlas (separate) |
| **Maintenance** | ✅ Managed by Supabase | ⚠️ Manage yourself |

---

## 🎯 VS Code Workflow

### Single Terminal!

```bash
# Start the app
npm run dev

# That's it! No backend server needed.
```

### File Structure

```
your-project/
├── components/          # React components
│   └── DatabaseSeeder.tsx   # Seed database from UI
├── services/
│   └── supabaseApi.ts      # API service (replaces Node.js backend)
├── utils/supabase/
│   ├── client.ts           # Supabase connection
│   ├── info.tsx            # Project credentials (auto-generated)
│   └── seedData.ts         # Seed function
├── App.tsx                 # Main app
└── SUPABASE_QUICKSTART.md  # This file
```

---

## 🔐 Security

### Row Level Security (RLS)

All tables have RLS policies that:
- ✅ Only allow authenticated users to access data
- ✅ Users can only see their own user data
- ✅ All honeypot/decoy/attack data is protected
- ✅ No exposed API keys or secrets

### Authentication Flow

1. User registers → Supabase Auth creates account
2. User profile created in `users` table
3. 2FA setup → TOTP secret stored (encrypted)
4. User logs in → Session token issued
5. All API calls include session token
6. Supabase verifies token automatically

---

## 🆘 Troubleshooting

### "relation does not exist"
**Solution**: Run the SQL script in Step 1 again.

### "permission denied for table"
**Solution**: Make sure you ran the RLS policies at the end of the SQL script.

### "No data showing"
**Solution**: Click "Seed Database" button in the dashboard.

### "Failed to fetch"
**Solution**: 
1. Check Supabase project is running (Dashboard → Home)
2. Check `/utils/supabase/info.tsx` exists
3. Try refreshing the page

---

## 📊 Viewing Data

### Option 1: Supabase Dashboard
1. Go to Supabase Dashboard → **Table Editor**
2. Click on any table to view data
3. You can manually edit/add rows here

### Option 2: SQL Editor
```sql
-- View all honeypots
SELECT * FROM honeypots;

-- View decoy credentials
SELECT name, credentials FROM decoy_environments;

-- View recent attacks
SELECT * FROM attack_logs 
ORDER BY timestamp DESC 
LIMIT 10;

-- Count total attacks
SELECT COUNT(*) FROM attack_logs;
```

---

## 🎉 Success!

You should now have:

- ✅ Supabase database with 4 tables
- ✅ App running on http://localhost:5173
- ✅ Authentication with 2FA working
- ✅ Database seeded with fake data
- ✅ Dashboard showing real data from Supabase
- ✅ No backend server needed!

---

## 📚 Additional Resources

- **Supabase Docs**: https://supabase.com/docs
- **SQL Tutorial**: https://supabase.com/docs/guides/database
- **RLS Guide**: https://supabase.com/docs/guides/auth/row-level-security
- **Full Setup Guide**: See [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)

---

**Your Honeypot Defense Grid is now powered by Supabase!** 🚀

**Questions?** Check the [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) for more details.
