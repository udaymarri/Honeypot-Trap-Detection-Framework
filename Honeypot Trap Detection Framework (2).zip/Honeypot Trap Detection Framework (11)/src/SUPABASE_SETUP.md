# 🚀 Supabase Setup Guide

Complete guide to set up your Honeypot Defense Grid with Supabase.

---

## ✅ Why Supabase?

- **✨ No Backend Needed** - Everything runs in the browser
- **🔒 Secure** - No exposed credentials in client code
- **⚡ Real-time** - Live data updates
- **🔐 Built-in Auth** - Already configured for your 2FA
- **☁️ Cloud Database** - PostgreSQL with automatic backups
- **🆓 Free Tier** - Perfect for development and prototyping

---

## 📋 Quick Start (5 Minutes)

### Step 1: Database is Already Set Up! ✅

Your Supabase project is already configured and connected. The connection details are in `/utils/supabase/info.tsx`.

### Step 2: Create Database Tables

Copy and paste this SQL into your Supabase SQL Editor:

**Go to**: Supabase Dashboard → SQL Editor → New Query

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Honeypots table
CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Decoy Environments table
CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Attack Logs table
CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_attack_logs_blocked ON attack_logs(blocked);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);
CREATE INDEX IF NOT EXISTS idx_decoy_environments_status ON decoy_environments(status);

-- Enable Row Level Security (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies (allow authenticated users to read/write)
-- Users table
CREATE POLICY "Users can view own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own data" ON users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Enable insert for authenticated users" ON users
  FOR INSERT WITH CHECK (true);

-- Honeypots table
CREATE POLICY "Enable read for authenticated users" ON honeypots
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Enable insert for authenticated users" ON honeypots
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users" ON honeypots
  FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users" ON honeypots
  FOR DELETE USING (auth.role() = 'authenticated');

-- Decoy Environments table
CREATE POLICY "Enable read for authenticated users" ON decoy_environments
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Enable insert for authenticated users" ON decoy_environments
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users" ON decoy_environments
  FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users" ON decoy_environments
  FOR DELETE USING (auth.role() = 'authenticated');

-- Attack Logs table
CREATE POLICY "Enable read for authenticated users" ON attack_logs
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Enable insert for authenticated users" ON attack_logs
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Enable update for authenticated users" ON attack_logs
  FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Enable delete for authenticated users" ON attack_logs
  FOR DELETE USING (auth.role() = 'authenticated');
```

**Click "Run"** to execute the SQL.

### Step 3: Seed the Database

Open your browser console (F12) and run:

```javascript
// Import the seed function
import { seedDatabase } from './utils/supabase/seedData';

// Run the seeder
await seedDatabase();
```

Or add a seed button to your app temporarily.

---

## 🎯 Alternative: Use Provided Seed Component

I'll create a component you can use to seed the database from the UI.

---

## 📊 What Gets Created

After running the SQL, you'll have 4 tables:

### 1. `users`
- Extends Supabase auth
- Stores TOTP secrets
- Tracks 2FA verification status

### 2. `honeypots`
- 6 fake honeypots (SSH, HTTP, FTP, SMTP, MySQL, RDP)
- Port configurations
- Attack counts

### 3. `decoy_environments`
- 4 fake systems with credentials
- Bait files (customers.sql, company_secrets.docx, etc.)
- Access tracking

### 4. `attack_logs`
- 200 fake attack attempts
- Geographic data (China, Russia, USA, etc.)
- Attack types (SQL Injection, SSH Brute Force, etc.)

---

## 🔐 Security Features

- ✅ **Row Level Security (RLS)** enabled on all tables
- ✅ **Policies** restrict access to authenticated users only
- ✅ **No API keys exposed** in client code
- ✅ **Supabase Auth** handles authentication
- ✅ **Automatic backups** by Supabase

---

## 🎨 Using in Your App

The API is already integrated! Just use:

```typescript
import { 
  AuthAPI, 
  HoneypotsAPI, 
  DecoysAPI, 
  AttacksAPI, 
  ThreatsAPI 
} from './services/supabaseApi';

// Example: Get all honeypots
const { honeypots } = await HoneypotsAPI.getAll();

// Example: Create new attack log
await AttacksAPI.log({
  source_ip: '192.168.1.100',
  target_honeypot: 'SSH Honeypot',
  attack_type: 'SSH Brute Force',
  severity: 'high',
  // ...
});
```

---

## 🆚 Supabase vs MongoDB

| Feature | Supabase | MongoDB |
|---------|----------|---------|
| **Browser Connection** | ✅ Yes | ❌ No |
| **Security** | ✅ Built-in RLS | ⚠️ Requires backend |
| **Real-time** | ✅ Built-in | ⚠️ Requires setup |
| **Authentication** | ✅ Built-in | ⚠️ Custom code |
| **Setup Complexity** | ✅ Simple | ⚠️ Complex |
| **Backend Required** | ❌ No | ✅ Yes |
| **Deployment** | ✅ One-click | ⚠️ Separate servers |

---

## 🚀 Next Steps

1. ✅ Run the SQL to create tables
2. ✅ Seed the database with fake data
3. ✅ Start your app: `npm run dev`
4. ✅ Register an account
5. ✅ Setup 2FA
6. ✅ View the dashboard with real Supabase data!

---

## 🆘 Troubleshooting

### "Permission denied for table"
**Solution**: Make sure you ran all the RLS policies in the SQL script.

### "relation does not exist"
**Solution**: Run the CREATE TABLE statements again.

### "No data showing in dashboard"
**Solution**: Run the seed function to populate data.

---

## 📞 Need Help?

1. Check Supabase Dashboard → Table Editor to verify tables exist
2. Check Supabase Dashboard → Authentication to verify auth is enabled
3. Check browser console (F12) for errors
4. Review SQL Editor logs for any errors

---

**That's it! Your Honeypot Defense Grid is now powered by Supabase!** 🎉
