# 🆚 VS Code Setup Guide: Supabase vs MongoDB

**Complete comparison and setup instructions for both options.**

---

## 🎯 Quick Decision Guide

### Choose **Supabase** if you want:
- ✅ **Simplest setup** (3 steps, 3 minutes)
- ✅ **Single terminal** in VS Code
- ✅ **No backend server** to manage
- ✅ **Automatic security** (RLS policies)
- ✅ **Real-time updates** built-in
- ✅ **One-click deployment** (frontend only)

### Choose **MongoDB + Node.js** if you want:
- ✅ **Full backend control**
- ✅ **Custom API logic**
- ✅ **MongoDB experience**
- ✅ **Traditional REST API**
- ✅ **Separate backend deployment**

---

## 🟢 Option 1: Supabase (Recommended for VS Code)

### Setup Time: **3 minutes**

### Step 1: Create Database Tables (One-Time)

1. **Open Supabase Dashboard**
   ```
   https://supabase.com/dashboard
   ```

2. **Go to SQL Editor**
   - Click "SQL Editor" in left sidebar
   - Click "+ New Query"

3. **Copy & Paste This SQL:**

```sql
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Honeypots table
CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Decoy Environments table
CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Attack Logs table
CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Enable insert for users" ON users FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable all for authenticated on honeypots" ON honeypots FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Enable all for authenticated on decoys" ON decoy_environments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Enable all for authenticated on attacks" ON attack_logs FOR ALL USING (auth.role() = 'authenticated');
```

4. **Click "Run"**

✅ Done! Tables created.

---

### Step 2: VS Code Terminal

```bash
# Install dependencies
npm install

# Start the app
npm run dev
```

**That's it!** Open http://localhost:5173

---

### Step 3: Seed Database (From UI)

1. Register a new account
2. Setup 2FA (scan QR code)
3. Login to dashboard
4. Click **"Seed Database"** button
5. Wait for confirmation

✅ Database populated with:
- 6 Honeypots
- 4 Decoy Environments
- 200 Attack Logs

---

### VS Code Workflow (Supabase)

```
📂 Your VS Code Workspace
├── Terminal 1: npm run dev  ← Only one terminal needed!
└── Browser: http://localhost:5173

✅ No backend server
✅ No MongoDB connection
✅ No environment variables to configure
✅ Everything just works!
```

---

## 🔵 Option 2: MongoDB + Node.js Backend

### Setup Time: **15-20 minutes**

### Step 1: MongoDB Atlas Configuration

1. **Get MongoDB Password**
   ```
   https://cloud.mongodb.com/
   ```
   - Login with: `ganeshmunaga`
   - Go to "Database Access" → Get/reset password

2. **Whitelist Your IP**
   - Go to "Network Access"
   - Click "Add IP Address"
   - Add current IP or 0.0.0.0/0 (development only)

---

### Step 2: Configure Backend

```bash
cd backend
nano .env
```

Update:
```env
MONGODB_URI=mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority

JWT_SECRET=<generate-random-64-char-string>
SESSION_SECRET=<generate-different-random-string>
```

**Generate secrets:**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

---

### Step 3: Install Dependencies

```bash
# Backend
cd backend
npm install

# Frontend
cd ..
npm install
```

---

### Step 4: Seed Database

```bash
cd backend
npm run seed
```

You should see:
```
✅ Inserted 6 honeypots
✅ Inserted 4 decoy environments
✅ Inserted 200 attack logs
```

---

### Step 5: Start Both Servers

**Terminal 1 - Backend:**
```bash
cd backend
npm run dev
```

**Terminal 2 - Frontend:**
```bash
npm run dev
```

Open http://localhost:5173

---

### VS Code Workflow (MongoDB)

```
📂 Your VS Code Workspace
├── Terminal 1: cd backend && npm run dev  ← Backend server
├── Terminal 2: npm run dev                 ← Frontend server
└── Browser: http://localhost:5173

⚠️ Need to run 2 terminals
⚠️ MongoDB must be configured
⚠️ Backend must be running
⚠️ More complex deployment
```

---

## 📊 Detailed Comparison

| Feature | Supabase | MongoDB + Node.js |
|---------|----------|-------------------|
| **Setup Time** | ⚡ 3 minutes | ⏳ 15-20 minutes |
| **Terminals in VS Code** | ✅ 1 | ⚠️ 2 |
| **Configuration Files** | ✅ None | ⚠️ 2 (.env files) |
| **Dependencies** | ✅ Frontend only | ⚠️ Backend + Frontend |
| **Database Connection** | ✅ Automatic | ⚠️ Manual setup |
| **Authentication** | ✅ Built-in | ⚠️ Custom code |
| **Security (RLS)** | ✅ Built-in | ⚠️ Manual implementation |
| **Real-time Updates** | ✅ Built-in | ⚠️ Requires WebSocket |
| **Deployment** | ✅ 1 service | ⚠️ 2 services |
| **Backend API** | ✅ Auto-generated | ✅ Full control |
| **Database Type** | PostgreSQL | MongoDB (NoSQL) |
| **Backup** | ✅ Automatic | ⚠️ Manual |
| **Monitoring** | ✅ Built-in dashboard | ⚠️ Custom setup |
| **Learning Curve** | ✅ Easy | ⚠️ Moderate |
| **Production Ready** | ✅ Yes | ✅ Yes |

---

## 🎯 Recommended Setup for VS Code

### For Beginners:
**Choose Supabase** → Simpler, fewer moving parts

### For Learning:
**Choose MongoDB** → Learn backend development

### For Production:
**Choose Supabase** → Less maintenance, better security

### For Custom Backend Logic:
**Choose MongoDB** → Full backend control

---

## 🔄 Switching Between Them

### Already Using MongoDB? Want to Switch to Supabase?

1. Run the Supabase SQL script
2. Use the seed button in UI to populate data
3. Your app already has both `/services/api.ts` (MongoDB) and `/services/supabaseApi.ts` (Supabase)
4. No changes needed! Just use Supabase going forward.

### Already Using Supabase? Want to Switch to MongoDB?

1. Follow MongoDB setup steps
2. Configure backend environment variables
3. Start both backend and frontend servers
4. The app supports both backends simultaneously

---

## 🚀 Final Recommendation

### Use **Supabase** if running in VS Code because:

1. **Single Terminal** - Just `npm run dev`
2. **No Backend Server** - One less thing to manage
3. **Faster Development** - Immediate feedback
4. **Easier Debugging** - Frontend only
5. **Simpler Deployment** - One service

### MongoDB is great if you:

1. Need custom backend logic
2. Want to learn backend development
3. Require specific MongoDB features
4. Have existing MongoDB infrastructure

---

## 📁 Project Structure Comparison

### Supabase:
```
honeypot-defense/
├── components/              # React components
├── services/
│   └── supabaseApi.ts      # ← Only file needed
├── utils/supabase/
│   ├── client.ts           # ← Supabase connection
│   └── seedData.ts         # ← Seed function
└── App.tsx

# No backend folder needed!
# No MongoDB configuration!
# No environment variables!
```

### MongoDB:
```
honeypot-defense/
├── backend/                 # Node.js server
│   ├── models/             # MongoDB models
│   ├── routes/             # API routes
│   ├── scripts/seed.js     # Database seeder
│   ├── server.js           # Main server
│   ├── .env                # Backend config
│   └── package.json        # Backend deps
├── components/              # React components
├── services/
│   └── api.ts              # Backend API client
└── App.tsx

# Requires backend server
# Requires MongoDB Atlas
# Requires environment setup
```

---

## ✅ Quick Decision Matrix

**I want to:**

| Goal | Choose |
|------|--------|
| Get started quickly | → **Supabase** |
| Learn backend development | → **MongoDB** |
| Deploy easily | → **Supabase** |
| Have full API control | → **MongoDB** |
| Work in single terminal | → **Supabase** |
| Use MongoDB experience | → **MongoDB** |
| Simplest VS Code setup | → **Supabase** |
| Build custom backend | → **MongoDB** |

---

## 🎓 Learning Path

### Beginner Path:
1. Start with **Supabase** (easier)
2. Get app working
3. Learn React and frontend
4. Later: Try MongoDB for backend learning

### Advanced Path:
1. Start with **MongoDB** (more complex)
2. Learn backend + frontend simultaneously
3. Understand full-stack architecture
4. Deploy both services

---

## 📞 Support

### Supabase Issues:
- Check: [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md)
- Check: [SUPABASE_SETUP.md](./SUPABASE_SETUP.md)
- Supabase Docs: https://supabase.com/docs

### MongoDB Issues:
- Check: [START_HERE.md](./START_HERE.md)
- Check: [MONGODB_SETUP.md](./MONGODB_SETUP.md)
- Check: [QUICK_REFERENCE.md](./QUICK_REFERENCE.md)

---

**🌟 Recommended for VS Code: Start with Supabase!**

It's the fastest way to get your Honeypot Defense Grid running in VS Code with minimal setup.

---

**Questions?** Check the specific guides linked above!
