# 🔧 Troubleshooting Guide

**Common issues and solutions for Honeypot Defense Grid**

---

## ❌ Error: "Could not find the table 'public.honeypots'" OR "Tables not found!"

### Problem 1: Tables Don't Exist Yet
You clicked "Seed Database" but the database tables haven't been created yet.

**Solution:**
**You must create the tables BEFORE seeding!**

1. Go to https://supabase.com/dashboard
2. Click "SQL Editor" (left sidebar)
3. Click "+ New Query"
4. Copy the ENTIRE SQL script from [STEP_BY_STEP.md](./STEP_BY_STEP.md) (Step 3)
5. Paste into SQL editor
6. Click "Run"
7. Wait for "Success. No rows returned"
8. **NOW** click "Seed Database" in your app

✅ **Verify**: Go to Supabase Dashboard → Table Editor → You should see 4 tables:
- `users`
- `honeypots`
- `decoy_environments`
- `attack_logs`

---

### Problem 2: Tables Exist BUT RLS Policies Block Access

**Symptoms:**
- You see "Success. No rows returned" when creating tables
- Tables show up in Table Editor
- BUT "Seed Database" button still says "Tables not found!"

**Why:** Row Level Security (RLS) policies block anon users!

**Solution:** Update RLS policies to allow anon access

1. Go to Supabase Dashboard → SQL Editor
2. Copy SQL from `FIX_RLS_POLICIES.sql` file (in project root)
3. Paste and click "Run"
4. Try seeding again

**Quick Fix SQL:**
```sql
DROP POLICY IF EXISTS "Enable all for authenticated on honeypots" ON honeypots;
DROP POLICY IF EXISTS "Enable all for authenticated on decoys" ON decoy_environments;
DROP POLICY IF EXISTS "Enable all for authenticated on attacks" ON attack_logs;

CREATE POLICY "Enable all for honeypots" ON honeypots
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for decoy_environments" ON decoy_environments
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');

CREATE POLICY "Enable all for attack_logs" ON attack_logs
  FOR ALL USING (auth.role() = 'authenticated' OR auth.role() = 'anon');
```

✅ **Full guide**: See [SEEDING_ERROR_FIX.md](./SEEDING_ERROR_FIX.md)

---

## ❌ Error: "permission denied for table"

### Problem:
Row Level Security (RLS) policies weren't created.

### Solution:
Run the **COMPLETE** SQL script again (don't skip the RLS policies at the end).

1. Supabase Dashboard → SQL Editor
2. Copy the **FULL** SQL from [STEP_BY_STEP.md](./STEP_BY_STEP.md)
3. Make sure you include the RLS policies (the part that starts with `CREATE POLICY`)
4. Click "Run"

---

## ❌ Error: "relation does not exist"

### Problem:
Same as "Could not find the table" - tables don't exist.

### Solution:
Create the tables first! See [STEP_BY_STEP.md](./STEP_BY_STEP.md) Step 3-4.

---

## ❌ Dashboard shows "No data" or empty charts

### Problem:
Database is empty - you haven't seeded it yet.

### Solution:

**Option 1: Use Seed Button (Recommended)**
1. Login to dashboard
2. Scroll down to bottom
3. Find "Database Seeder" card
4. Click "Seed Database"
5. Wait 5-10 seconds
6. Refresh page

**Option 2: Check Tables Exist**
1. Supabase Dashboard → Table Editor
2. Click on `honeypots` table
3. If it shows "Table does not exist" → Run SQL script first!
4. If table exists but is empty → Use seed button

---

## ❌ Error: "Invalid 2FA code"

### Problem:
The 6-digit code from Google Authenticator expired or was typed incorrectly.

### Solution:

1. **Wait for new code**: Codes change every 30 seconds
2. **Type quickly**: Enter the code as soon as it appears
3. **Check time sync**: 
   - Google Authenticator settings → Time correction
   - Make sure your phone's time is correct
4. **Try again**: Get a fresh code from the app

---

## ❌ Error: "Port 5173 already in use"

### Problem:
Another Vite dev server is already running.

### Solution:

**Option 1: Kill the process**
```bash
pkill -f vite
npm run dev
```

**Option 2: Use different port**
```bash
npm run dev -- --port 3000
```

Then open: http://localhost:3000

---

## ❌ Error: "Cannot find module '@supabase/supabase-js'"

### Problem:
Dependencies not installed.

### Solution:

```bash
# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
npm run dev
```

---

## ❌ App loads but shows "System Offline" or errors

### Problem:
Supabase connection issue.

### Solution:

1. **Check Supabase project is running**:
   - Go to https://supabase.com/dashboard
   - Make sure your project status is "Active" (green)

2. **Check `/utils/supabase/info.tsx` exists**:
   - This file should be auto-generated
   - Contains your project ID and API key
   - If missing, the system will create it

3. **Try refreshing**:
   - Hard refresh: Ctrl+Shift+R (or Cmd+Shift+R)
   - Clear cache and refresh

---

## ❌ Can't see "Database Seeder" button

### Problem:
You're not logged in or you're on the wrong page.

### Solution:

1. Make sure you're **logged in** to the dashboard (not on landing page)
2. **Scroll down** - the button is at the bottom
3. Look for a card with a cyan database icon titled "Database Seeder"
4. It's in the right column, above "Honeypot Database Stats"

---

## ❌ Seed button says "Success" but no data appears

### Problem:
Page needs refresh or data didn't insert correctly.

### Solution:

1. **Refresh the page**: F5 or Ctrl+R
2. **Check browser console**: 
   - Press F12
   - Click "Console" tab
   - Look for any red errors
3. **Check Supabase directly**:
   - Supabase Dashboard → Table Editor
   - Click `honeypots` table
   - You should see 6 rows
   - If empty, check console for errors
4. **Try seeding again**: Click "Seed Database" once more

---

## ❌ TypeScript errors in VS Code

### Problem:
VS Code TypeScript server is confused.

### Solution:

1. **Restart TS server**:
   - Press Ctrl+Shift+P (or Cmd+Shift+P)
   - Type "TypeScript: Restart TS Server"
   - Press Enter

2. **Reload VS Code window**:
   - Ctrl+Shift+P → "Developer: Reload Window"

3. **Clear TypeScript cache**:
```bash
rm -rf node_modules/.vite
npm run dev
```

---

## ❌ "Failed to fetch" errors in browser console

### Problem:
Network issue or Supabase connection problem.

### Solution:

1. **Check internet connection**
2. **Check Supabase status**: https://status.supabase.com/
3. **Check browser console** (F12) for specific error
4. **Try incognito mode**: To rule out extension issues
5. **Check firewall**: Make sure Supabase isn't blocked

---

## ❌ Login/Register not working

### Problem:
Supabase Auth not configured or user table missing.

### Solution:

1. **Make sure tables are created** (especially `users` table)
2. **Check Supabase Auth is enabled**:
   - Supabase Dashboard → Authentication
   - Should be enabled by default
3. **Check email format**: Use valid email like `test@example.com`
4. **Check password**: Must be at least 6 characters
5. **Check browser console** (F12) for specific errors

---

## ❌ Charts/Maps not displaying

### Problem:
Missing data or component render issue.

### Solution:

1. **Seed the database first**: Click "Seed Database" button
2. **Refresh page**: F5
3. **Check browser console** (F12) for errors
4. **Wait a moment**: Some components load asynchronously

---

## ❌ VS Code terminal shows errors when running `npm run dev`

### Problem:
Dependency or configuration issue.

### Solution:

1. **Read the error message**: It usually tells you what's wrong
2. **Common fixes**:

```bash
# Fix 1: Reinstall dependencies
rm -rf node_modules package-lock.json
npm install

# Fix 2: Clear cache
rm -rf node_modules/.vite
npm run dev

# Fix 3: Update npm
npm install -g npm@latest

# Fix 4: Node version (need 18+)
node --version  # Should be 18.x or higher
```

---

## 🔍 Debugging Tips

### Check Browser Console
1. Press **F12**
2. Click **Console** tab
3. Look for red errors
4. Read the error messages carefully

### Check Network Tab
1. Press **F12**
2. Click **Network** tab
3. Reload page
4. Look for failed requests (red)
5. Click on failed request to see details

### Check Supabase Logs
1. Supabase Dashboard → Logs
2. Click on "Postgres Logs"
3. Look for errors around the time you clicked "Seed Database"

### Enable Debug Mode
In browser console (F12), run:
```javascript
localStorage.setItem('debug', 'true');
location.reload();
```

This will show more detailed logs.

---

## 📊 How to Verify Everything is Working

### ✅ Checklist:

1. **Tables exist**:
   - Supabase Dashboard → Table Editor
   - See: users, honeypots, decoy_environments, attack_logs

2. **App runs**:
   - `npm run dev` works
   - No errors in terminal
   - http://localhost:5173 loads

3. **Can register**:
   - Register form works
   - Get QR code for 2FA
   - Can scan with Google Authenticator

4. **Can login**:
   - Login form works
   - 2FA code accepted
   - Dashboard appears

5. **Data exists**:
   - Dashboard shows numbers (not all zeros)
   - Threat map has pins
   - Charts have data
   - Attack logs show entries

6. **Seed button works**:
   - "Seed Database" button visible
   - Clicking it shows success message
   - Numbers appear: 6 honeypots, 4 decoys, 200 attacks

---

## 🆘 Still Having Issues?

### Collected Information:

Before asking for help, collect this info:

1. **Browser**: Chrome, Firefox, Safari?
2. **Browser console errors**: F12 → Console tab → screenshot
3. **Terminal output**: Any errors from `npm run dev`?
4. **What you were doing**: Step-by-step what you clicked
5. **Supabase tables**: Do they exist? (Table Editor)
6. **Node version**: Run `node --version`

### Check These Documents:

| Issue Type | Document |
|------------|----------|
| First time setup | [STEP_BY_STEP.md](./STEP_BY_STEP.md) |
| Supabase specific | [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md) |
| VS Code issues | [VS_CODE_SETUP.md](./VS_CODE_SETUP.md) |
| General setup | [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) |

---

## 💡 Pro Tips

### Prevent Issues:

1. **Always create tables BEFORE seeding**
2. **Run the COMPLETE SQL script** (don't skip parts)
3. **Check Supabase Dashboard** to verify tables exist
4. **Use browser console** (F12) to see errors immediately
5. **Read error messages** - they usually tell you what's wrong
6. **One step at a time** - don't rush through setup

### Speed Up Development:

1. **Use hot reload** - just save files, browser updates automatically
2. **Keep browser console open** (F12) - catch errors fast
3. **Use VS Code terminal** - see backend logs immediately
4. **Bookmark Supabase Dashboard** - quick access to tables

---

**Most common solution: Just create the database tables first!** 🎯

See [STEP_BY_STEP.md](./STEP_BY_STEP.md) for the exact SQL to run.
