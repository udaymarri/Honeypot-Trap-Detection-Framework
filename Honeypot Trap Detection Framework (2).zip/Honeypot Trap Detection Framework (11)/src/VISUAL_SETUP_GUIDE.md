# 👀 Visual Setup Guide

Step-by-step with screenshots and examples.

---

## 📋 What You'll Need

- ✅ 5 minutes of your time
- ✅ MongoDB Atlas account (free tier is fine!)
- ✅ Node.js installed (v18 or higher)
- ✅ A code editor (VS Code recommended)
- ✅ Google Authenticator app on your phone

---

## Step 1: Get MongoDB Password

### 1.1 - Go to MongoDB Atlas

🌐 Open: https://cloud.mongodb.com/

Login with username: **ganeshmunaga**

---

### 1.2 - Check Network Access

Click **"Network Access"** in the left sidebar

You should see something like:

```
┌─────────────────────────────────────────────┐
│  Network Access                              │
├─────────────────────────────────────────────┤
│                                              │
│  IP Address Whitelist:                       │
│                                              │
│  ✅ 123.456.789.0        [Edit] [Delete]    │
│  ✅ 0.0.0.0/0            [Edit] [Delete]    │
│                                              │
│  [+ ADD IP ADDRESS]                          │
└─────────────────────────────────────────────┘
```

**If your current IP is NOT listed:**

1. Click **"+ ADD IP ADDRESS"**
2. Click **"ADD CURRENT IP ADDRESS"**
3. Click **"Confirm"**

**For development only**, you can also:
- Click **"ALLOW ACCESS FROM ANYWHERE"**
- This adds `0.0.0.0/0` (all IPs)
- ⚠️ **Never use this in production!**

---

### 1.3 - Get Your Password

Click **"Database Access"** in the left sidebar

You should see:

```
┌─────────────────────────────────────────────┐
│  Database Access                             │
├─────────────────────────────────────────────┤
│                                              │
│  User: ganeshmunaga                          │
│  Database: admin                             │
│  Auth Method: SCRAM                          │
│  Role: Read and write to any database        │
│                                              │
│  [Edit]  [Delete]                            │
└─────────────────────────────────────────────┘
```

**If you forgot your password:**

1. Click **"Edit"**
2. Click **"Edit Password"**
3. Choose **"Autogenerate Secure Password"** OR enter your own
4. Click **"Copy"** to copy the password
5. **Save it somewhere safe!**
6. Click **"Update User"**

---

## Step 2: Configure Backend

### 2.1 - Open Terminal

```bash
# Navigate to the project
cd /path/to/honeypot-defense-grid

# Go to backend folder
cd backend
```

---

### 2.2 - Edit .env File

**Using nano (Linux/Mac):**
```bash
nano .env
```

**Using VS Code:**
```bash
code .env
```

**Using Notepad (Windows):**
```bash
notepad .env
```

---

### 2.3 - Update MongoDB URI

Find this line:
```env
MONGODB_URI=mongodb+srv://ganeshmunaga:YOUR_PASSWORD_HERE@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority
```

**Replace `YOUR_PASSWORD_HERE` with your actual password:**

Example:
```env
# Before:
MONGODB_URI=mongodb+srv://ganeshmunaga:YOUR_PASSWORD_HERE@cluster0...

# After (example password: MySecret123):
MONGODB_URI=mongodb+srv://ganeshmunaga:MySecret123@cluster0...
```

⚠️ **Special Characters in Password?**

If your password contains these characters, you need to URL-encode them:

| Character | Encode As | Example          |
|-----------|-----------|------------------|
| @         | %40       | p@ss → p%40ss    |
| #         | %23       | p#ss → p%23ss    |
| %         | %25       | p%ss → p%25ss    |
| &         | %26       | p&ss → p%26ss    |
| =         | %3D       | p=ss → p%3Dss    |
| +         | %2B       | p+ss → p%2Bss    |
| space     | %20       | p ss → p%20ss    |

**Example:**
```env
# Password is: Pass@123#
# Encoded as: Pass%40123%23
MONGODB_URI=mongodb+srv://ganeshmunaga:Pass%40123%23@cluster0...
```

---

### 2.4 - Generate Secrets (Important!)

**For JWT_SECRET and SESSION_SECRET**, generate random strings:

**Option 1: Using Node.js**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

This outputs something like:
```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
```

**Option 2: Using OpenSSL**
```bash
openssl rand -hex 32
```

**Option 3: Online Generator**
- Go to: https://www.uuidgenerator.net/
- Copy a UUID

**Update your .env:**
```env
JWT_SECRET=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6
SESSION_SECRET=z6y5x4w3v2u1t0s9r8q7p6o5n4m3l2k1j0i9h8g7f6e5d4c3b2a1
```

**Save the file!**
- nano: `Ctrl+O`, `Enter`, `Ctrl+X`
- VS Code: `Ctrl+S` (or `Cmd+S` on Mac)
- Notepad: `File → Save`

---

## Step 3: Install Dependencies

### 3.1 - Backend Dependencies

```bash
# Still in the backend folder
npm install
```

You should see:
```
added 234 packages, and audited 235 packages in 15s

52 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities
```

---

### 3.2 - Frontend Dependencies

```bash
# Go back to root folder
cd ..

# Install frontend dependencies
npm install
```

---

## Step 4: Seed the Database

### 4.1 - Run Seed Script

```bash
# Go to backend
cd backend

# Run the seed script
npm run seed
```

---

### 4.2 - Expected Output

You should see:

```
🌱 Starting database seed...

✅ Connected to MongoDB Atlas

🗑️  Clearing existing data...
✅ Cleared old data

📡 Inserting honeypots...
✅ Inserted 6 honeypots

🎭 Inserting decoy environments...
✅ Inserted 4 decoy environments

⚔️  Generating fake attack logs...
✅ Inserted 200 attack logs

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ Database seeding completed!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Total Records: 210
   • Honeypots: 6
   • Decoy Environments: 4
   • Attack Logs: 200
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📋 Sample Decoy Credentials (for testing):

   1. Production Database - Customer Records:
      - admin / admin123 (root)
      - dbuser / database2024 (read-write)
      - backup_user / backup@123 (read-only)

   2. Corporate File Server:
      - administrator / Password123! (admin)
      - fileadmin / files2024 (read-write)

👋 Database connection closed
```

✅ **Success!** Your MongoDB now has fake honeypot data!

---

## Step 5: Start the Servers

### 5.1 - Start Backend (Terminal 1)

```bash
# In the backend folder
npm run dev
```

Expected output:

```
🚀 ===================================
   HONEYPOT DEFENSE GRID API
   ===================================
   🌐 Server running on port 5000
   🔗 http://localhost:5000
   📡 MongoDB: Connected
   ===================================

✅ Connected to MongoDB Atlas
📊 Database: honeypot-defense
```

**Leave this terminal running!**

---

### 5.2 - Start Frontend (Terminal 2)

Open a **NEW** terminal window/tab

```bash
# Go to root folder
cd /path/to/honeypot-defense-grid

# Start frontend
npm run dev
```

Expected output:

```
  VITE v5.0.0  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
```

**Leave this terminal running too!**

---

## Step 6: Test the Application

### 6.1 - Open Browser

Go to: **http://localhost:5173**

You should see the landing page:

```
╔═══════════════════════════════════════════════════╗
║                                                   ║
║        🛡️  HONEYPOT DEFENSE GRID                 ║
║                                                   ║
║    Cyber Deception & Intrusion Analysis System   ║
║                                                   ║
║            [GET STARTED →]                        ║
║                                                   ║
╚═══════════════════════════════════════════════════╝
```

---

### 6.2 - Test Health Check

Open: **http://localhost:5000/api/health**

You should see:

```json
{
  "status": "online",
  "timestamp": "2025-01-11T12:34:56.789Z",
  "database": "connected",
  "version": "2.4.1"
}
```

✅ **Backend is working!**

---

### 6.3 - Test Honeypots Endpoint

Open: **http://localhost:5000/api/honeypots**

You should see:

```json
{
  "success": true,
  "honeypots": [
    {
      "_id": "65a1b2c3...",
      "name": "SSH Honeypot - Production Server",
      "type": "SSH",
      "protocol": "ssh",
      "port": 22,
      "status": "active",
      "location": "US-East-1",
      "attackCount": 1247,
      ...
    },
    ...
  ]
}
```

✅ **Database is connected!**

---

## Step 7: Create Your Account

### 7.1 - Click Get Started

On the landing page, click **"GET STARTED"**

---

### 7.2 - Sign Up

Click the **"Sign Up"** tab

Fill in:
- **Username**: `testadmin`
- **Email**: `test@example.com`
- **Password**: `Test123!`
- **Confirm Password**: `Test123!`

Click **"Create Account"**

---

### 7.3 - Setup 2FA

You'll see a QR code and setup instructions:

```
╔═══════════════════════════════════════╗
║        Setup 2FA Authentication        ║
║                                        ║
║    [QR CODE IMAGE]                     ║
║                                        ║
║    Manual Entry Key:                   ║
║    JBSWY3DPEHPK3PXP                   ║
║                                        ║
║    1. Download Google Authenticator    ║
║    2. Scan the QR code above          ║
║    3. Enter 6-digit code below        ║
║                                        ║
║    [_ _ _ _ _ _]                      ║
║                                        ║
║    [Verify & Complete Setup]          ║
╚═══════════════════════════════════════╝
```

---

### 7.4 - Scan QR Code

1. Open **Google Authenticator** app on your phone
2. Tap **+** (plus button)
3. Choose **"Scan a QR code"**
4. Point camera at the QR code on screen
5. Entry should be added as **"Honeypot Defense Grid"**

---

### 7.5 - Enter Code

1. Look at Google Authenticator
2. You'll see a 6-digit code (e.g., `123456`)
3. Enter it in the boxes
4. Click **"Verify & Complete Setup"**

✅ **You're in!**

---

## Step 8: Explore the Dashboard

After successful 2FA verification, you'll see:

```
╔══════════════════════════════════════════════════════════╗
║  🛡️  HONEYPOT DEFENSE GRID                              ║
╠══════════════════════════════════════════════════════════╣
║                                                           ║
║  📊 THREAT STATISTICS                                     ║
║  ┌──────────┬──────────┬──────────┬──────────┐          ║
║  │  1,247   │   342    │   905    │    45    │          ║
║  │ Attacks  │  Active  │ Blocked  │ Critical │          ║
║  └──────────┴──────────┴──────────┴──────────┘          ║
║                                                           ║
║  🌍 INTERACTIVE THREAT MAP                                ║
║  [3D globe showing attack origins from China, Russia]    ║
║                                                           ║
║  📈 ATTACK ANALYTICS                                      ║
║  [Line graph showing attack trends over time]            ║
║                                                           ║
║  🎭 DECOY ENVIRONMENTS                                    ║
║  Production Database - Customer Records                  ║
║  ├─ admin / admin123                                     ║
║  ├─ dbuser / database2024                                ║
║  └─ 📄 customers.sql (2.4 GB)                            ║
║                                                           ║
║  Corporate File Server                                   ║
║  ├─ administrator / Password123!                         ║
║  └─ 📄 company_secrets.docx                              ║
║                                                           ║
╚══════════════════════════════════════════════════════════╝
```

---

## ✅ Success Checklist

- [x] MongoDB Atlas password configured
- [x] IP address whitelisted
- [x] Backend dependencies installed
- [x] Frontend dependencies installed
- [x] Database seeded with fake data
- [x] Backend running on port 5000
- [x] Frontend running on port 5173
- [x] Health check returns "connected"
- [x] Account created with 2FA
- [x] Successfully logged in
- [x] Dashboard shows real MongoDB data

---

## 🎉 You're All Set!

Your Honeypot Defense Grid is now:

✅ **Connected to MongoDB Atlas**
- Real cloud database
- Automatic backups
- Global distribution

✅ **Populated with Fake Data**
- 6 honeypots monitoring different protocols
- 4 decoy environments with fake credentials
- 200 attack logs from various countries

✅ **Secured with 2FA**
- Mandatory TOTP authentication
- Google Authenticator integration
- JWT token-based sessions

✅ **Fully Functional**
- Real-time threat monitoring
- Interactive 3D threat maps
- Attack analytics and charts
- Decoy credential tracking

---

## 🔮 What's Next?

### Explore Features:
1. 🗺️ **Threat Map** - See attacks from around the world
2. 📊 **Analytics** - View attack trends and statistics
3. 🎭 **Decoys** - Manage fake environments
4. 📡 **Honeypots** - Add/configure honeypots
5. 🔔 **Alerts** - Set up notifications
6. ⚙️ **Settings** - Configure system parameters

### Add More Data:
```bash
cd backend
npm run seed
```

### View Database:
- Install [MongoDB Compass](https://www.mongodb.com/products/compass)
- Connect with your connection string
- Browse collections visually

### Deploy to Production:
- Frontend: Vercel or Netlify
- Backend: Render or Railway
- Database: Already on MongoDB Atlas!

---

## 🆘 Common Issues

### "Cannot connect to MongoDB"

**Check:**
1. Password in `.env` is correct
2. No spaces or typos in connection string
3. Special characters are URL-encoded
4. IP is whitelisted in MongoDB Atlas

**Test:**
```bash
mongosh "mongodb+srv://ganeshmunaga:YOUR_PASSWORD@cluster0.15rkrdo.mongodb.net/"
```

---

### "Port 5000 already in use"

**Solution:**
```bash
# Find process using port 5000
lsof -i :5000

# Kill it
kill -9 <PID>

# Or change port in backend/.env
PORT=5001
```

---

### "2FA code doesn't work"

**Check:**
1. Phone time is synchronized
2. Code hasn't expired (changes every 30s)
3. QR code was scanned correctly
4. Using Google Authenticator or Authy

**Try:**
- Use manual entry instead of QR scan
- Re-scan QR code
- Check debug panel for expected code

---

### "Frontend shows mock data"

**Check `.env` in root:**
```env
VITE_ENABLE_MOCK_DATA=false
```

Then restart:
```bash
npm run dev
```

---

## 📞 Still Stuck?

1. Check backend terminal for errors
2. Check browser console (F12) for errors
3. Review MongoDB Atlas logs
4. Test API endpoints individually
5. Check all passwords and secrets

---

**Happy Hacking! 🛡️**

*Remember: The decoy data is FAKE - designed to catch attackers!*
