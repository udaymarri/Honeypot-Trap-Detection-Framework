# 💻 VS Code Setup Guide

**Complete guide to running Honeypot Defense Grid in Visual Studio Code**

---

## 🎯 Recommended Setup for VS Code

### ✅ Use Supabase (Easiest)

**Why?**
- Single terminal window
- No backend server to manage
- Faster development cycle
- Simpler debugging
- One-click deployment

**Time**: 3 minutes

---

## 🚀 Quick Start in VS Code

### Step 1: Open Project

```bash
# Open in VS Code
code /path/to/honeypot-defense-grid
```

Or use VS Code UI:
1. File → Open Folder
2. Select project folder
3. Click "Open"

---

### Step 2: Install Dependencies

**Open VS Code Terminal** (Ctrl+` or View → Terminal)

```bash
npm install
```

Wait for installation to complete (30-60 seconds)

---

### Step 3: Setup Supabase Database

**Browser Tab 1: Supabase Dashboard**
1. Go to https://supabase.com/dashboard
2. Click your project
3. Click "SQL Editor" (left sidebar)
4. Click "+ New Query"

**Copy this SQL:**

```sql
-- Enable UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create tables
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL,
  role TEXT DEFAULT 'admin',
  totp_secret TEXT,
  is_2fa_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS honeypots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS decoy_environments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]',
  files JSONB DEFAULT '[]',
  services TEXT[] DEFAULT '{}',
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS attack_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT NOT NULL,
  attack_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_attack_logs_timestamp ON attack_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_attack_logs_severity ON attack_logs(severity);
CREATE INDEX IF NOT EXISTS idx_honeypots_status ON honeypots(status);

-- RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE attack_logs ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Enable insert for users" ON users FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable all for authenticated on honeypots" ON honeypots FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Enable all for authenticated on decoys" ON decoy_environments FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Enable all for authenticated on attacks" ON attack_logs FOR ALL USING (auth.role() = 'authenticated');
```

**Click "Run"** (bottom right)

✅ **Success!** You should see "Success. No rows returned"

---

### Step 4: Start the App

**In VS Code Terminal:**

```bash
npm run dev
```

You should see:

```
  VITE v5.0.0  ready in 500 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

✅ **Done!** Your app is running.

---

### Step 5: Open in Browser

**Click the link in terminal** or open: http://localhost:5173

You should see the landing page!

---

### Step 6: Register & Seed Data

1. **Click "Get Started"**
2. **Click "Sign Up"** tab
3. **Register:**
   - Username: `admin`
   - Email: `admin@example.com`
   - Password: `Admin123!`
4. **Scan QR Code** with Google Authenticator
5. **Enter 6-digit code**
6. **You're in!** Dashboard appears
7. **Scroll down** to "Database Seeder" section
8. **Click "Seed Database"**
9. **Wait** for confirmation (5-10 seconds)

✅ **Complete!** Database now has:
- 6 Honeypots
- 4 Decoy Environments
- 200 Attack Logs

---

## 🎨 VS Code Layout

### Recommended Window Layout

```
┌─────────────────────────────────────────────────────┐
│  VS Code Window                                     │
├─────────────────────────────────────────────────────┤
│                                                     │
│  📁 Explorer                  📝 Editor            │
│  ├── components/             (Your code files)     │
│  ├── services/                                     │
│  ├── utils/                                        │
│  └── App.tsx                                       │
│                                                     │
├─────────────────────────────────────────────────────┤
│  🖥️ Terminal                                        │
│  $ npm run dev                                     │
│  ➜ Local: http://localhost:5173/                  │
│                                                     │
└─────────────────────────────────────────────────────┘

Browser Tab: http://localhost:5173
```

---

## 🔧 VS Code Extensions (Recommended)

### Essential:
- **ES7+ React/Redux/React-Native snippets** - Faster coding
- **Tailwind CSS IntelliSense** - Autocomplete for Tailwind
- **TypeScript Error Translator** - Better error messages
- **Auto Rename Tag** - Rename HTML tags automatically

### Nice to Have:
- **Prettier** - Code formatting
- **ESLint** - Code linting
- **GitLens** - Git integration
- **Error Lens** - Inline errors
- **Thunder Client** - Test APIs

---

## ⌨️ VS Code Shortcuts

### Navigation:
- `Ctrl+P` - Quick file open
- `Ctrl+Shift+F` - Search in project
- `Ctrl+Shift+E` - Toggle Explorer
- `Ctrl+` ` - Toggle Terminal
- `Ctrl+B` - Toggle Sidebar

### Editing:
- `Alt+Up/Down` - Move line up/down
- `Ctrl+D` - Select next occurrence
- `Ctrl+/` - Toggle comment
- `Ctrl+Space` - Trigger IntelliSense
- `F2` - Rename symbol

### Development:
- `Ctrl+Shift+B` - Run build task
- `F5` - Start debugging
- `Ctrl+Shift+D` - Debug panel

---

## 🐛 Debugging in VS Code

### View Browser Console:

In your browser (Chrome/Firefox):
1. Press `F12`
2. Click "Console" tab
3. View any errors or logs

### View VS Code Terminal Errors:

- Terminal shows Vite dev server logs
- Any compile errors appear here
- Hot reload messages appear here

### Common Issues:

**"Module not found"**
```bash
# Restart dev server
Ctrl+C
npm run dev
```

**"Port 5173 in use"**
```bash
# Kill existing process
pkill -f vite

# Or change port
npm run dev -- --port 3000
```

---

## 📂 File Structure in VS Code

### Most Important Files:

```
your-project/
├── App.tsx                    ← Main app entry
├── components/
│   ├── LandingPage.tsx       ← Landing page
│   ├── AuthPage.tsx          ← Login/Register
│   ├── ThreatMap.tsx         ← 3D threat map
│   ├── DatabaseSeeder.tsx    ← Seed database UI
│   └── ...
├── services/
│   ├── supabaseApi.ts        ← API layer ⭐
│   └── totp.ts               ← 2FA logic
├── utils/supabase/
│   ├── client.ts             ← Supabase connection
│   ├── info.tsx              ← Auto-generated
│   └── seedData.ts           ← Seed function
└── styles/
    └── globals.css           ← Global styles
```

---

## 🎯 Development Workflow

### Typical Development Cycle:

1. **Edit code** in VS Code
2. **Save file** (Ctrl+S)
3. **Vite auto-reloads** browser
4. **Check browser** for changes
5. **Check terminal** for errors
6. **Repeat!**

### Making Changes:

**Frontend Changes:**
1. Edit React component in `components/`
2. Save file
3. Browser auto-updates
4. No restart needed!

**Styling Changes:**
1. Edit Tailwind classes in component
2. Save file
3. Styles update immediately

**API Changes:**
1. Edit `services/supabaseApi.ts`
2. Save file
3. Restart dev server (Ctrl+C, `npm run dev`)

---

## 📊 Viewing Data in VS Code

### Method 1: Use Supabase Dashboard

1. Open https://supabase.com/dashboard
2. Click "Table Editor"
3. Select table (honeypots, decoys, etc.)
4. View and edit data

### Method 2: Use SQL Editor

1. Supabase Dashboard → SQL Editor
2. Run queries:

```sql
-- View all honeypots
SELECT * FROM honeypots;

-- View decoy credentials
SELECT name, credentials FROM decoy_environments;

-- Count attacks
SELECT COUNT(*) FROM attack_logs;

-- Recent attacks
SELECT * FROM attack_logs ORDER BY timestamp DESC LIMIT 10;
```

### Method 3: Browser Console

In browser (F12 → Console):

```javascript
// Import service
import { HoneypotsAPI } from './services/supabaseApi';

// Get data
const { honeypots } = await HoneypotsAPI.getAll();
console.log(honeypots);
```

---

## 🚀 Deployment from VS Code

### Deploy to Vercel (Recommended):

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

Done! Your app is live.

### Or Use GitHub + Vercel:

1. Push code to GitHub
2. Go to https://vercel.com
3. Import GitHub repo
4. Click "Deploy"

---

## ⚙️ VS Code Settings

### Recommended settings.json:

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": true
  },
  "typescript.suggest.autoImports": true,
  "javascript.suggest.autoImports": true,
  "tailwindCSS.experimental.classRegex": [
    ["cva\\(([^)]*)\\)", "[\"'`]([^\"'`]*).*?[\"'`]"]
  ]
}
```

---

## 🔥 Hot Reload

Vite provides instant hot reload:

- ✅ Edit React component → Updates in ~100ms
- ✅ Edit CSS/Tailwind → Updates instantly
- ✅ Edit TypeScript → Compiles and updates
- ✅ No manual refresh needed!

---

## 📝 Git Workflow in VS Code

### Initialize Git:

```bash
git init
git add .
git commit -m "Initial commit"
```

### Push to GitHub:

```bash
git remote add origin https://github.com/yourusername/honeypot-defense.git
git push -u origin main
```

### Using VS Code Git UI:

1. Click Source Control icon (Ctrl+Shift+G)
2. Stage changes (+)
3. Enter commit message
4. Click ✓ to commit
5. Click ⋯ → Push

---

## 🆘 Common VS Code Issues

### Issue: "Cannot find module"

**Solution:**
```bash
# Delete node_modules and reinstall
rm -rf node_modules
npm install
```

### Issue: "TypeScript errors"

**Solution:**
- Restart TypeScript server: Ctrl+Shift+P → "TypeScript: Restart TS Server"

### Issue: "Terminal not working"

**Solution:**
- Close and reopen terminal: Ctrl+` twice

### Issue: "IntelliSense not working"

**Solution:**
```bash
# Reload VS Code window
Ctrl+Shift+P → "Developer: Reload Window"
```

---

## 🎉 Success!

You should now have:

✅ VS Code open with project
✅ Dependencies installed
✅ Supabase database created
✅ Dev server running (`npm run dev`)
✅ App working at http://localhost:5173
✅ Database seeded with fake data
✅ Dashboard showing real data

---

## 📚 Next Steps

1. **Explore components** in `components/` folder
2. **Read code** to understand structure
3. **Make changes** and see hot reload
4. **Add features** - honeypots, decoys, etc.
5. **Customize UI** - change colors, layout
6. **Deploy** - put it online!

---

## 🎯 VS Code Tips for This Project

### Useful Commands:

```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type check
npm run type-check

# Lint code
npm run lint
```

### Keyboard Shortcuts:

- `Ctrl+Shift+F` - Search "TODO" or "FIXME"
- `Ctrl+P` - Quick open `AuthPage.tsx`
- `Ctrl+Shift+E` - Browse files
- `F12` - Go to definition
- `Shift+F12` - Find all references

---

**Happy coding in VS Code!** 💻🚀

**Questions?** See [SUPABASE_QUICKSTART.md](./SUPABASE_QUICKSTART.md)
