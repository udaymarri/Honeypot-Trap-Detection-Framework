# 🛡️ Honeypot Defense Grid - Backend API

Node.js + Express + MongoDB backend for the Honeypot Trap Detection Framework.

---

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with your MongoDB credentials

# Start server
npm start

# Development mode (with auto-reload)
npm run dev

# Seed database with fake data
npm run seed
```

---

## 📡 API Endpoints

### Authentication

#### Register New User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "admin",
  "email": "admin@example.com",
  "password": "SecurePassword123!"
}

Response:
{
  "success": true,
  "userId": "65a1b2c3d4e5f6g7h8i9j0k1",
  "message": "User registered successfully"
}
```

#### Login (Step 1)
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "SecurePassword123!"
}

Response:
{
  "success": true,
  "requires2FA": true,
  "userId": "65a1b2c3d4e5f6g7h8i9j0k1",
  "message": "2FA verification required"
}
```

#### Setup 2FA
```http
POST /api/auth/setup-2fa
Content-Type: application/json

{
  "userId": "65a1b2c3d4e5f6g7h8i9j0k1"
}

Response:
{
  "success": true,
  "secret": "JBSWY3DPEHPK3PXP",
  "qrCode": "data:image/png;base64,..."
}
```

#### Verify 2FA Setup
```http
POST /api/auth/verify-setup
Content-Type: application/json

{
  "userId": "65a1b2c3d4e5f6g7h8i9j0k1",
  "code": "123456"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "65a1b2c3d4e5f6g7h8i9j0k1",
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin"
  }
}
```

#### Verify 2FA Login
```http
POST /api/auth/verify-2fa
Content-Type: application/json

{
  "userId": "65a1b2c3d4e5f6g7h8i9j0k1",
  "code": "123456"
}

Response:
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "65a1b2c3d4e5f6g7h8i9j0k1",
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin"
  }
}
```

---

### Honeypots

#### Get All Honeypots
```http
GET /api/honeypots
Authorization: Bearer <token>

Response:
{
  "success": true,
  "honeypots": [
    {
      "_id": "65a1b2c3d4e5f6g7h8i9j0k1",
      "name": "SSH Honeypot - Production Server",
      "type": "SSH",
      "protocol": "ssh",
      "port": 22,
      "status": "active",
      "location": "US-East-1",
      "attackCount": 1247,
      "lastActivity": "2025-01-11T10:30:00.000Z",
      "createdAt": "2025-01-01T00:00:00.000Z"
    }
  ]
}
```

#### Create Honeypot
```http
POST /api/honeypots
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "New SSH Honeypot",
  "type": "SSH",
  "protocol": "ssh",
  "port": 2222,
  "location": "US-West-1"
}

Response:
{
  "success": true,
  "honeypot": { ... },
  "message": "Honeypot created successfully"
}
```

#### Update Honeypot
```http
PUT /api/honeypots/:id
Authorization: Bearer <token>
Content-Type: application/json

{
  "status": "inactive",
  "port": 2223
}

Response:
{
  "success": true,
  "honeypot": { ... },
  "message": "Honeypot updated successfully"
}
```

#### Delete Honeypot
```http
DELETE /api/honeypots/:id
Authorization: Bearer <token>

Response:
{
  "success": true,
  "message": "Honeypot deleted successfully"
}
```

---

### Decoy Environments

#### Get All Decoys
```http
GET /api/decoys
Authorization: Bearer <token>

Response:
{
  "success": true,
  "decoys": [
    {
      "_id": "65a1b2c3d4e5f6g7h8i9j0k1",
      "name": "Production Database - Customer Records",
      "type": "database",
      "status": "active",
      "credentials": [
        {
          "username": "admin",
          "password": "admin123",
          "accessLevel": "root"
        }
      ],
      "files": [
        {
          "name": "customers.sql",
          "type": "database",
          "size": "2.4 GB",
          "path": "/var/db/backups/",
          "isBait": true
        }
      ],
      "services": ["mysql", "postgresql", "redis"],
      "accessCount": 34,
      "lastAccessed": "2025-01-11T10:30:00.000Z"
    }
  ]
}
```

#### Create Decoy Environment
```http
POST /api/decoys
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Test Server",
  "type": "server",
  "credentials": [
    {
      "username": "test",
      "password": "test123",
      "accessLevel": "user"
    }
  ],
  "files": [
    {
      "name": "config.json",
      "type": "json",
      "size": "5 KB",
      "path": "/etc/",
      "isBait": true
    }
  ],
  "services": ["ssh", "http"]
}
```

---

### Attack Logs

#### Get All Attacks
```http
GET /api/attacks?limit=50
Authorization: Bearer <token>

Response:
{
  "success": true,
  "attacks": [
    {
      "_id": "65a1b2c3d4e5f6g7h8i9j0k1",
      "sourceIp": "192.168.1.100",
      "targetHoneypot": "SSH Honeypot - Production Server",
      "attackType": "SSH Brute Force",
      "severity": "high",
      "protocol": "tcp",
      "payload": "SSH Brute Force detected at 2025-01-11T10:30:00.000Z",
      "location": {
        "country": "China",
        "city": "Beijing",
        "lat": 39.9042,
        "lon": 116.4074
      },
      "timestamp": "2025-01-11T10:30:00.000Z",
      "blocked": true
    }
  ],
  "total": 200
}
```

#### Get Attack Statistics
```http
GET /api/attacks/stats
Authorization: Bearer <token>

Response:
{
  "success": true,
  "stats": {
    "total": 200,
    "today": 45,
    "byType": {
      "SQL Injection": 50,
      "SSH Brute Force": 80,
      "Port Scan": 40,
      "DDoS": 30
    },
    "bySeverity": {
      "critical": 20,
      "high": 60,
      "medium": 80,
      "low": 40
    },
    "byCountry": {
      "China": 50,
      "Russia": 40,
      "USA": 30
    }
  }
}
```

#### Log New Attack
```http
POST /api/attacks
Authorization: Bearer <token>
Content-Type: application/json

{
  "sourceIp": "192.168.1.200",
  "targetHoneypot": "SSH Honeypot",
  "attackType": "SQL Injection",
  "severity": "critical",
  "protocol": "tcp",
  "payload": "' OR '1'='1",
  "location": {
    "country": "Unknown",
    "city": "Unknown",
    "lat": 0,
    "lon": 0
  }
}
```

---

### Threats

#### Get Threat Feed
```http
GET /api/threats?limit=20
Authorization: Bearer <token>

Response:
{
  "success": true,
  "threats": [
    {
      "id": "threat_001",
      "type": "malware",
      "severity": "critical",
      "source": "192.168.1.100",
      "target": "SSH Honeypot",
      "timestamp": "2025-01-11T10:30:00.000Z",
      "status": "blocked"
    }
  ]
}
```

#### Get Threat Statistics
```http
GET /api/threats/stats
Authorization: Bearer <token>

Response:
{
  "success": true,
  "stats": {
    "total": 500,
    "active": 120,
    "blocked": 380,
    "critical": 45
  }
}
```

---

### Health Check

```http
GET /api/health

Response:
{
  "status": "online",
  "timestamp": "2025-01-11T10:30:00.000Z",
  "database": "connected",
  "version": "2.4.1"
}
```

---

## 🗄️ Database Models

### User Model
```javascript
{
  username: String (unique, required),
  email: String (unique, required),
  password: String (hashed, required),
  role: String (default: 'admin'),
  totpSecret: String,
  is2FAVerified: Boolean (default: false),
  createdAt: Date,
  updatedAt: Date
}
```

### Honeypot Model
```javascript
{
  name: String (required),
  type: String (required),
  protocol: String (required),
  port: Number (required),
  status: String (default: 'active'),
  location: String,
  ipAddress: String,
  attackCount: Number (default: 0),
  lastActivity: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Decoy Environment Model
```javascript
{
  name: String (required),
  type: String (required),
  status: String (default: 'active'),
  credentials: [{
    username: String,
    password: String,
    accessLevel: String
  }],
  files: [{
    name: String,
    type: String,
    size: String,
    path: String,
    isBait: Boolean
  }],
  services: [String],
  accessCount: Number (default: 0),
  lastAccessed: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Attack Log Model
```javascript
{
  sourceIp: String (required),
  targetHoneypot: String (required),
  attackType: String (required),
  severity: String (required),
  protocol: String,
  payload: String,
  location: {
    country: String,
    city: String,
    lat: Number,
    lon: Number
  },
  timestamp: Date (default: Date.now),
  blocked: Boolean (default: false),
  tags: [String],
  createdAt: Date,
  updatedAt: Date
}
```

---

## 🔒 Authentication

All protected routes require a JWT token in the Authorization header:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

The token is returned after successful 2FA verification.

---

## 🛠️ Development

### Environment Variables

Create a `.env` file:

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/database
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
JWT_SECRET=your_jwt_secret
SESSION_SECRET=your_session_secret
BCRYPT_ROUNDS=12
```

### Running in Development

```bash
npm run dev
```

This uses `nodemon` to auto-reload on file changes.

### Seeding the Database

```bash
npm run seed
```

This will:
- Clear existing data
- Insert 6 honeypots
- Insert 4 decoy environments with fake credentials
- Generate 200 fake attack logs

---

## 📦 Dependencies

- **express** - Web framework
- **mongoose** - MongoDB ODM
- **cors** - CORS middleware
- **dotenv** - Environment variables
- **bcryptjs** - Password hashing
- **jsonwebtoken** - JWT authentication
- **speakeasy** - TOTP 2FA
- **qrcode** - QR code generation
- **helmet** - Security headers
- **express-rate-limit** - Rate limiting
- **compression** - Response compression
- **morgan** - HTTP request logger

---

## 🔐 Security Features

1. **Password Hashing** - bcrypt with 12 rounds
2. **JWT Authentication** - Secure token-based auth
3. **Mandatory 2FA** - TOTP using Google Authenticator
4. **Rate Limiting** - Prevent brute force attacks
5. **Helmet** - Security headers
6. **CORS** - Controlled cross-origin requests
7. **Input Validation** - Request validation
8. **Error Handling** - Secure error messages

---

## 📝 License

MIT

---

## 🤝 Contributing

Contributions welcome! Please follow the existing code style and add tests for new features.

---

**Built with ❤️ for cybersecurity professionals**
