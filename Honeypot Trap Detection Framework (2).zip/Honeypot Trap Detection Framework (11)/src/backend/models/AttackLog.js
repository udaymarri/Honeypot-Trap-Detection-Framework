const mongoose = require('mongoose');

/**
 * Attack Log Model
 * 
 * Records all attack attempts and suspicious activities
 * detected by the honeypot system
 */

const attackLogSchema = new mongoose.Schema({
  // Attack identification
  attackId: {
    type: String,
    required: true,
    unique: true,
    default: () => `ATK-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  },
  // Attacker information
  sourceIp: {
    type: String,
    required: true,
    index: true
  },
  sourcePort: Number,
  sourceCountry: String,
  sourceCity: String,
  sourceCoordinates: {
    lat: Number,
    lng: Number
  },
  // Attack details
  attackType: {
    type: String,
    required: true,
    enum: [
      'brute_force',
      'sql_injection',
      'xss',
      'csrf',
      'directory_traversal',
      'command_injection',
      'port_scan',
      'malware_upload',
      'credential_stuffing',
      'dos',
      'ddos',
      'reconnaissance',
      'privilege_escalation',
      'data_exfiltration',
      'other'
    ],
    index: true
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    required: true,
    index: true
  },
  status: {
    type: String,
    enum: ['detected', 'analyzing', 'blocked', 'mitigated', 'resolved'],
    default: 'detected'
  },
  // Target information
  targetHoneypot: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Honeypot'
  },
  targetDecoy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DecoyEnvironment'
  },
  targetPort: Number,
  targetService: String,
  // Attack payload
  payload: {
    type: String,
    default: ''
  },
  requestHeaders: {
    type: Map,
    of: String
  },
  requestBody: String,
  userAgent: String,
  // Commands executed (if applicable)
  commands: [{
    timestamp: Date,
    command: String,
    response: String
  }],
  // Files accessed/modified
  filesAccessed: [{
    path: String,
    action: String,
    timestamp: Date
  }],
  // Network activity
  networkActivity: [{
    timestamp: Date,
    protocol: String,
    destination: String,
    port: Number,
    bytes: Number
  }],
  // Threat intelligence
  threatScore: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  isMalicious: {
    type: Boolean,
    default: true
  },
  isKnownAttacker: {
    type: Boolean,
    default: false
  },
  attackerFingerprint: String,
  // Countermeasures
  blocked: {
    type: Boolean,
    default: false
  },
  blockedAt: Date,
  blockReason: String,
  // Timestamps
  detectedAt: {
    type: Date,
    default: Date.now,
    index: true
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  duration: {
    type: Number, // in seconds
    default: 0
  },
  // Metadata
  tags: [String],
  notes: String
}, {
  timestamps: true
});

// Indexes for performance
attackLogSchema.index({ sourceIp: 1, attackType: 1 });
attackLogSchema.index({ severity: 1, status: 1 });
attackLogSchema.index({ detectedAt: -1 });
attackLogSchema.index({ 'sourceCoordinates.lat': 1, 'sourceCoordinates.lng': 1 });

// Method to calculate threat score
attackLogSchema.methods.calculateThreatScore = function() {
  let score = 0;
  
  // Base score by attack type
  const typeScores = {
    'reconnaissance': 20,
    'port_scan': 25,
    'brute_force': 50,
    'sql_injection': 70,
    'xss': 60,
    'command_injection': 80,
    'data_exfiltration': 90,
    'privilege_escalation': 85,
    'malware_upload': 95,
    'ddos': 75
  };
  
  score += typeScores[this.attackType] || 30;
  
  // Add score for known attacker
  if (this.isKnownAttacker) score += 20;
  
  // Add score for number of commands
  score += Math.min(this.commands.length * 2, 20);
  
  // Add score for files accessed
  score += Math.min(this.filesAccessed.length * 3, 15);
  
  // Normalize to 0-100
  this.threatScore = Math.min(Math.max(score, 0), 100);
  
  return this.threatScore;
};

// Method to add command
attackLogSchema.methods.addCommand = function(command, response) {
  this.commands.push({
    timestamp: new Date(),
    command,
    response
  });
  this.lastActivity = new Date();
};

// Method to add file access
attackLogSchema.methods.addFileAccess = function(path, action) {
  this.filesAccessed.push({
    path,
    action,
    timestamp: new Date()
  });
  this.lastActivity = new Date();
};

// Method to block attack
attackLogSchema.methods.blockAttack = function(reason) {
  this.blocked = true;
  this.blockedAt = new Date();
  this.blockReason = reason;
  this.status = 'blocked';
};

module.exports = mongoose.model('AttackLog', attackLogSchema);
