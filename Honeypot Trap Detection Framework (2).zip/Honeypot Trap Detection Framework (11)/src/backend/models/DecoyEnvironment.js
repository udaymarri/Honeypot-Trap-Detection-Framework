const mongoose = require('mongoose');

/**
 * Decoy Environment Model
 * 
 * Stores fake database/server environments to mislead attackers
 * Each environment contains convincing fake data
 */

const decoyEnvironmentSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    required: true,
    enum: ['database', 'server', 'api', 'storage', 'network'],
    index: true
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'compromised', 'suspicious'],
    default: 'active',
    index: true
  },
  // Environment details
  host: {
    type: String,
    required: true
  },
  port: {
    type: Number,
    required: true
  },
  protocol: {
    type: String,
    default: 'tcp'
  },
  // Fake credentials to lure attackers
  credentials: {
    username: String,
    password: String,
    apiKey: String,
    accessToken: String
  },
  // Fake data statistics
  stats: {
    records: { type: Number, default: 0 },
    tables: { type: Number, default: 0 },
    size: { type: String, default: '0 MB' },
    lastBackup: Date,
    uptime: { type: Number, default: 0 }
  },
  // Fake sensitive data indicators (to attract attackers)
  containsSensitiveData: {
    type: Boolean,
    default: true
  },
  dataTypes: [{
    type: String,
    enum: ['user_data', 'financial', 'credentials', 'api_keys', 'pii', 'medical', 'legal']
  }],
  // Monitoring
  accessCount: {
    type: Number,
    default: 0
  },
  lastAccessed: Date,
  accessLog: [{
    timestamp: Date,
    ip: String,
    username: String,
    action: String,
    suspicious: Boolean
  }],
  // Alerts
  alertsTriggered: [{
    timestamp: Date,
    type: String,
    severity: String,
    description: String
  }],
  // Tags for categorization
  tags: [{
    type: String
  }],
  // Location
  location: {
    type: String,
    default: 'Unknown'
  },
  region: {
    type: String,
    default: 'us-east-1'
  },
  // Metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Indexes for performance
decoyEnvironmentSchema.index({ type: 1, status: 1 });
decoyEnvironmentSchema.index({ containsSensitiveData: 1 });
decoyEnvironmentSchema.index({ 'credentials.username': 1 });

// Method to log access
decoyEnvironmentSchema.methods.logAccess = function(ip, username, action, suspicious = false) {
  this.accessLog.push({
    timestamp: new Date(),
    ip,
    username,
    action,
    suspicious
  });
  
  // Keep only last 100 access logs
  if (this.accessLog.length > 100) {
    this.accessLog = this.accessLog.slice(-100);
  }
  
  this.accessCount += 1;
  this.lastAccessed = new Date();
  
  // Trigger alert if suspicious
  if (suspicious) {
    this.status = 'suspicious';
    this.triggerAlert('unauthorized_access', 'high', `Suspicious access from ${ip}`);
  }
};

// Method to trigger alert
decoyEnvironmentSchema.methods.triggerAlert = function(type, severity, description) {
  this.alertsTriggered.push({
    timestamp: new Date(),
    type,
    severity,
    description
  });
  
  // Keep only last 50 alerts
  if (this.alertsTriggered.length > 50) {
    this.alertsTriggered = this.alertsTriggered.slice(-50);
  }
};

module.exports = mongoose.model('DecoyEnvironment', decoyEnvironmentSchema);
