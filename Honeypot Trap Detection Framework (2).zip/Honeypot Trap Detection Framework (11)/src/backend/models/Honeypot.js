const mongoose = require('mongoose');

/**
 * Honeypot Model
 * 
 * Defines honeypot instances running different protocols/services
 * to attract and monitor attackers
 */

const honeypotSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    required: true,
    enum: ['ssh', 'http', 'ftp', 'mysql', 'mongodb', 'smtp', 'telnet', 'rdp', 'custom'],
    index: true
  },
  protocol: {
    type: String,
    required: true
  },
  port: {
    type: Number,
    required: true
  },
  host: {
    type: String,
    default: '0.0.0.0'
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'maintenance', 'compromised'],
    default: 'active',
    index: true
  },
  // Service configuration
  service: {
    version: String,
    banner: String,
    emulatedOS: String,
    emulatedService: String
  },
  // Statistics
  stats: {
    totalConnections: { type: Number, default: 0 },
    totalAttacks: { type: Number, default: 0 },
    successfulBreaches: { type: Number, default: 0 },
    blockedAttempts: { type: Number, default: 0 },
    uniqueAttackers: { type: Number, default: 0 },
    uptime: { type: Number, default: 0 } // in seconds
  },
  // Connected decoy environments
  decoyEnvironments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'DecoyEnvironment'
  }],
  // Recent activity
  recentConnections: [{
    ip: String,
    timestamp: Date,
    duration: Number,
    malicious: Boolean
  }],
  // Alerts configuration
  alertsEnabled: {
    type: Boolean,
    default: true
  },
  alertThreshold: {
    type: Number,
    default: 10 // alerts per hour
  },
  // Logging
  loggingEnabled: {
    type: Boolean,
    default: true
  },
  logLevel: {
    type: String,
    enum: ['debug', 'info', 'warn', 'error'],
    default: 'info'
  },
  // Location
  location: {
    type: String,
    default: 'Cloud'
  },
  region: {
    type: String,
    default: 'us-east-1'
  },
  // Metadata
  description: String,
  tags: [String],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  lastActivityAt: Date
}, {
  timestamps: true
});

// Indexes
honeypotSchema.index({ type: 1, status: 1 });
honeypotSchema.index({ port: 1 });

// Method to log connection
honeypotSchema.methods.logConnection = function(ip, duration, malicious) {
  this.recentConnections.push({
    ip,
    timestamp: new Date(),
    duration,
    malicious
  });
  
  // Keep only last 100 connections
  if (this.recentConnections.length > 100) {
    this.recentConnections = this.recentConnections.slice(-100);
  }
  
  this.stats.totalConnections += 1;
  if (malicious) {
    this.stats.totalAttacks += 1;
  }
  this.lastActivityAt = new Date();
};

// Method to increment stats
honeypotSchema.methods.incrementStat = function(statName) {
  if (this.stats[statName] !== undefined) {
    this.stats[statName] += 1;
  }
};

module.exports = mongoose.model('Honeypot', honeypotSchema);
