const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

/**
 * User Model - Stores user accounts with mandatory 2FA
 * 
 * IMPORTANT: This stores FAKE user data for honeypot purposes
 * These accounts are intentionally vulnerable to attract attackers
 */

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    minlength: 3,
    maxlength: 50
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  role: {
    type: String,
    enum: ['admin', 'user', 'honeypot', 'decoy'],
    default: 'user'
  },
  // 2FA Configuration
  twoFactorEnabled: {
    type: Boolean,
    default: false
  },
  twoFactorSecret: {
    type: String,
    default: null
  },
  backupCodes: [{
    code: String,
    used: { type: Boolean, default: false }
  }],
  // Honeypot-specific fields
  isDecoy: {
    type: Boolean,
    default: false,
    index: true
  },
  decoyType: {
    type: String,
    enum: ['admin', 'developer', 'analyst', 'manager', 'normal'],
    default: 'normal'
  },
  // Access tracking
  lastLogin: {
    type: Date,
    default: null
  },
  loginAttempts: [{
    timestamp: Date,
    success: Boolean,
    ip: String,
    userAgent: String,
    location: String
  }],
  // Account metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  // Permissions (fake, to lure attackers)
  permissions: [{
    type: String
  }],
  // Access level (fake)
  accessLevel: {
    type: Number,
    default: 1,
    min: 1,
    max: 10
  }
}, {
  timestamps: true
});

// Index for performance
userSchema.index({ username: 1, email: 1 });
userSchema.index({ isDecoy: 1, decoyType: 1 });

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to generate backup codes
userSchema.methods.generateBackupCodes = function() {
  const codes = [];
  for (let i = 0; i < 10; i++) {
    codes.push({
      code: Math.random().toString(36).substring(2, 10).toUpperCase(),
      used: false
    });
  }
  this.backupCodes = codes;
  return codes.map(c => c.code);
};

// Method to verify backup code
userSchema.methods.verifyBackupCode = function(code) {
  const backupCode = this.backupCodes.find(bc => bc.code === code && !bc.used);
  if (backupCode) {
    backupCode.used = true;
    return true;
  }
  return false;
};

// Method to log login attempt
userSchema.methods.logLoginAttempt = function(success, ip, userAgent, location) {
  this.loginAttempts.push({
    timestamp: new Date(),
    success,
    ip,
    userAgent,
    location
  });
  
  // Keep only last 50 attempts
  if (this.loginAttempts.length > 50) {
    this.loginAttempts = this.loginAttempts.slice(-50);
  }
  
  if (success) {
    this.lastLogin = new Date();
  }
};

// Remove password from JSON output
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.twoFactorSecret;
  delete obj.backupCodes;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
