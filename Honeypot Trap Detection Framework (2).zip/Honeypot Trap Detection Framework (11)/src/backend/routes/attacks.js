const express = require('express');
const router = express.Router();
const AttackLog = require('../models/AttackLog');

/**
 * @route   GET /api/attacks
 * @desc    Get all attack logs
 * @access  Public
 */
router.get('/', async (req, res) => {
  try {
    const { 
      attackType, 
      severity, 
      status, 
      limit = 100,
      page = 1,
      sortBy = 'detectedAt',
      order = 'desc'
    } = req.query;
    
    const query = {};
    if (attackType) query.attackType = attackType;
    if (severity) query.severity = severity;
    if (status) query.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sortOrder = order === 'desc' ? -1 : 1;

    const attacks = await AttackLog.find(query)
      .populate('targetHoneypot')
      .populate('targetDecoy')
      .limit(parseInt(limit))
      .skip(skip)
      .sort({ [sortBy]: sortOrder });

    const total = await AttackLog.countDocuments(query);

    res.json({
      count: attacks.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit)),
      attacks
    });

  } catch (error) {
    console.error('Get attacks error:', error);
    res.status(500).json({ error: 'Failed to fetch attacks' });
  }
});

/**
 * @route   GET /api/attacks/:id
 * @desc    Get specific attack log
 * @access  Public
 */
router.get('/:id', async (req, res) => {
  try {
    const attack = await AttackLog.findById(req.params.id)
      .populate('targetHoneypot')
      .populate('targetDecoy');
    
    if (!attack) {
      return res.status(404).json({ error: 'Attack log not found' });
    }

    res.json(attack);

  } catch (error) {
    console.error('Get attack error:', error);
    res.status(500).json({ error: 'Failed to fetch attack' });
  }
});

/**
 * @route   POST /api/attacks
 * @desc    Create new attack log
 * @access  System
 */
router.post('/', async (req, res) => {
  try {
    const attack = new AttackLog(req.body);
    
    // Calculate threat score
    attack.calculateThreatScore();
    
    await attack.save();

    res.status(201).json({
      message: 'Attack logged',
      attack
    });

  } catch (error) {
    console.error('Create attack log error:', error);
    res.status(500).json({ error: 'Failed to log attack' });
  }
});

/**
 * @route   PUT /api/attacks/:id
 * @desc    Update attack log
 * @access  Admin
 */
router.put('/:id', async (req, res) => {
  try {
    const attack = await AttackLog.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!attack) {
      return res.status(404).json({ error: 'Attack not found' });
    }

    res.json({
      message: 'Attack updated',
      attack
    });

  } catch (error) {
    console.error('Update attack error:', error);
    res.status(500).json({ error: 'Failed to update attack' });
  }
});

/**
 * @route   POST /api/attacks/:id/command
 * @desc    Add command to attack log
 * @access  System
 */
router.post('/:id/command', async (req, res) => {
  try {
    const { command, response } = req.body;
    
    const attack = await AttackLog.findById(req.params.id);
    if (!attack) {
      return res.status(404).json({ error: 'Attack not found' });
    }

    attack.addCommand(command, response);
    attack.calculateThreatScore();
    await attack.save();

    res.json({
      message: 'Command logged',
      attack
    });

  } catch (error) {
    console.error('Add command error:', error);
    res.status(500).json({ error: 'Failed to add command' });
  }
});

/**
 * @route   POST /api/attacks/:id/block
 * @desc    Block an attack
 * @access  Admin
 */
router.post('/:id/block', async (req, res) => {
  try {
    const { reason } = req.body;
    
    const attack = await AttackLog.findById(req.params.id);
    if (!attack) {
      return res.status(404).json({ error: 'Attack not found' });
    }

    attack.blockAttack(reason || 'Manually blocked');
    await attack.save();

    res.json({
      message: 'Attack blocked',
      attack
    });

  } catch (error) {
    console.error('Block attack error:', error);
    res.status(500).json({ error: 'Failed to block attack' });
  }
});

/**
 * @route   GET /api/attacks/stats/summary
 * @desc    Get attack statistics summary
 * @access  Public
 */
router.get('/stats/summary', async (req, res) => {
  try {
    const { timeRange = '24h' } = req.query;
    
    // Calculate time filter
    const now = new Date();
    let startDate = new Date();
    
    switch(timeRange) {
      case '1h':
        startDate.setHours(now.getHours() - 1);
        break;
      case '24h':
        startDate.setDate(now.getDate() - 1);
        break;
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      default:
        startDate.setDate(now.getDate() - 1);
    }

    const totalAttacks = await AttackLog.countDocuments({ detectedAt: { $gte: startDate } });
    const blockedAttacks = await AttackLog.countDocuments({ 
      detectedAt: { $gte: startDate },
      blocked: true 
    });
    
    const attacksByType = await AttackLog.aggregate([
      { $match: { detectedAt: { $gte: startDate } } },
      { $group: { _id: '$attackType', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    const attacksBySeverity = await AttackLog.aggregate([
      { $match: { detectedAt: { $gte: startDate } } },
      { $group: { _id: '$severity', count: { $sum: 1 } } }
    ]);

    const uniqueAttackers = await AttackLog.distinct('sourceIp', { 
      detectedAt: { $gte: startDate } 
    });

    res.json({
      timeRange,
      total: totalAttacks,
      blocked: blockedAttacks,
      uniqueAttackers: uniqueAttackers.length,
      byType: attacksByType,
      bySeverity: attacksBySeverity
    });

  } catch (error) {
    console.error('Get attack stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

/**
 * @route   GET /api/attacks/stats/timeline
 * @desc    Get attack timeline data
 * @access  Public
 */
router.get('/stats/timeline', async (req, res) => {
  try {
    const { timeRange = '24h', interval = '1h' } = req.query;
    
    // This would require more complex aggregation
    // For now, return mock data structure
    res.json({
      message: 'Timeline data',
      timeRange,
      interval,
      data: [] // Implement aggregation pipeline here
    });

  } catch (error) {
    console.error('Get timeline error:', error);
    res.status(500).json({ error: 'Failed to fetch timeline' });
  }
});

module.exports = router;
