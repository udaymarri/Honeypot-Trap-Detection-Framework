const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'your-super-secret-jwt-key';
const TOTP_ISSUER = process.env.TOTP_ISSUER || 'Honeypot Defense Grid';

/**
 * @route   POST /api/auth/register
 * @desc    Register new user with mandatory 2FA
 * @access  Public
 */
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Validation
    if (!username || !email || !password) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if user exists
    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      return res.status(400).json({ error: 'Username or email already exists' });
    }

    // Create user
    const user = new User({
      username,
      email,
      password, // Will be hashed by pre-save hook
      role: 'user'
    });

    await user.save();

    // Generate 2FA secret
    const secret = speakeasy.generateSecret({
      name: `${TOTP_ISSUER} (${email})`,
      issuer: TOTP_ISSUER
    });

    // Update user with 2FA secret
    user.twoFactorSecret = secret.base32;
    await user.save();

    // Generate QR code
    const qrCodeUrl = await QRCode.toDataURL(secret.otpauth_url);

    res.status(201).json({
      message: 'User created successfully',
      userId: user._id,
      qrCode: qrCodeUrl,
      secret: secret.base32,
      requiresSetup: true
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

/**
 * @route   POST /api/auth/verify-setup
 * @desc    Verify 2FA setup during registration
 * @access  Public
 */
router.post('/verify-setup', async (req, res) => {
  try {
    const { userId, token } = req.body;

    if (!userId || !token) {
      return res.status(400).json({ error: 'User ID and token required' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify token
    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token: token,
      window: 1
    });

    if (!verified) {
      return res.status(400).json({ error: 'Invalid verification code' });
    }

    // Enable 2FA
    user.twoFactorEnabled = true;
    
    // Generate backup codes
    const backupCodes = user.generateBackupCodes();
    await user.save();

    // Generate JWT token
    const jwtToken = jwt.sign(
      { userId: user._id, username: user.username },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: '2FA setup completed',
      token: jwtToken,
      backupCodes,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('Setup verification error:', error);
    res.status(500).json({ error: 'Verification failed' });
  }
});

/**
 * @route   POST /api/auth/login
 * @desc    Login user (step 1)
 * @access  Public
 */
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    // Find user
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      // Log failed attempt
      user.logLoginAttempt(false, req.ip, req.get('user-agent'), 'Unknown');
      await user.save();
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check if 2FA is enabled
    if (!user.twoFactorEnabled) {
      return res.status(400).json({ error: '2FA not set up for this account' });
    }

    res.json({
      message: '2FA required',
      userId: user._id,
      requires2FA: true
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

/**
 * @route   POST /api/auth/verify-2fa
 * @desc    Verify 2FA code during login
 * @access  Public
 */
router.post('/verify-2fa', async (req, res) => {
  try {
    const { userId, token } = req.body;

    if (!userId || !token) {
      return res.status(400).json({ error: 'User ID and token required' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Verify TOTP token
    const verified = speakeasy.totp.verify({
      secret: user.twoFactorSecret,
      encoding: 'base32',
      token: token,
      window: 1
    });

    if (!verified) {
      // Check if it's a backup code
      const backupVerified = user.verifyBackupCode(token);
      
      if (!backupVerified) {
        user.logLoginAttempt(false, req.ip, req.get('user-agent'), 'Unknown');
        await user.save();
        return res.status(400).json({ error: 'Invalid 2FA code' });
      }
    }

    // Log successful login
    user.logLoginAttempt(true, req.ip, req.get('user-agent'), 'Unknown');
    await user.save();

    // Generate JWT token
    const jwtToken = jwt.sign(
      { userId: user._id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token: jwtToken,
      user: user.toJSON()
    });

  } catch (error) {
    console.error('2FA verification error:', error);
    res.status(500).json({ error: 'Verification failed' });
  }
});

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user
 * @access  Private
 */
router.post('/logout', async (req, res) => {
  // In a real app, you'd invalidate the JWT token
  // For now, just send success
  res.json({ message: 'Logged out successfully' });
});

module.exports = router;
