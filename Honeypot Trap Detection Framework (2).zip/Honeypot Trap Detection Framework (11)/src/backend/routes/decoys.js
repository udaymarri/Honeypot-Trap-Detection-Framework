const express = require('express');
const router = express.Router();
const DecoyEnvironment = require('../models/DecoyEnvironment');

/**
 * @route   GET /api/decoys
 * @desc    Get all decoy environments
 * @access  Public (but will log access for monitoring)
 */
router.get('/', async (req, res) => {
  try {
    const { type, status, limit = 50 } = req.query;
    
    const query = {};
    if (type) query.type = type;
    if (status) query.status = status;

    const decoys = await DecoyEnvironment.find(query)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    res.json({
      count: decoys.length,
      decoys
    });

  } catch (error) {
    console.error('Get decoys error:', error);
    res.status(500).json({ error: 'Failed to fetch decoys' });
  }
});

/**
 * @route   GET /api/decoys/:id
 * @desc    Get specific decoy environment
 * @access  Public
 */
router.get('/:id', async (req, res) => {
  try {
    const decoy = await DecoyEnvironment.findById(req.params.id);
    
    if (!decoy) {
      return res.status(404).json({ error: 'Decoy not found' });
    }

    // Log this access as potentially suspicious
    decoy.logAccess(
      req.ip,
      'anonymous',
      'view_details',
      true // Mark as suspicious
    );
    await decoy.save();

    res.json(decoy);

  } catch (error) {
    console.error('Get decoy error:', error);
    res.status(500).json({ error: 'Failed to fetch decoy' });
  }
});

/**
 * @route   POST /api/decoys
 * @desc    Create new decoy environment
 * @access  Admin
 */
router.post('/', async (req, res) => {
  try {
    const decoy = new DecoyEnvironment(req.body);
    await decoy.save();

    res.status(201).json({
      message: 'Decoy environment created',
      decoy
    });

  } catch (error) {
    console.error('Create decoy error:', error);
    res.status(500).json({ error: 'Failed to create decoy' });
  }
});

/**
 * @route   PUT /api/decoys/:id
 * @desc    Update decoy environment
 * @access  Admin
 */
router.put('/:id', async (req, res) => {
  try {
    const decoy = await DecoyEnvironment.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!decoy) {
      return res.status(404).json({ error: 'Decoy not found' });
    }

    res.json({
      message: 'Decoy updated',
      decoy
    });

  } catch (error) {
    console.error('Update decoy error:', error);
    res.status(500).json({ error: 'Failed to update decoy' });
  }
});

/**
 * @route   DELETE /api/decoys/:id
 * @desc    Delete decoy environment
 * @access  Admin
 */
router.delete('/:id', async (req, res) => {
  try {
    const decoy = await DecoyEnvironment.findByIdAndDelete(req.params.id);

    if (!decoy) {
      return res.status(404).json({ error: 'Decoy not found' });
    }

    res.json({ message: 'Decoy deleted' });

  } catch (error) {
    console.error('Delete decoy error:', error);
    res.status(500).json({ error: 'Failed to delete decoy' });
  }
});

/**
 * @route   POST /api/decoys/:id/access
 * @desc    Log access to decoy (called when attacker accesses)
 * @access  Public
 */
router.post('/:id/access', async (req, res) => {
  try {
    const { username, action } = req.body;
    
    const decoy = await DecoyEnvironment.findById(req.params.id);
    if (!decoy) {
      return res.status(404).json({ error: 'Decoy not found' });
    }

    // Log the access
    decoy.logAccess(
      req.ip,
      username || 'anonymous',
      action || 'unknown',
      true // Always suspicious
    );
    await decoy.save();

    res.json({
      message: 'Access logged',
      alertTriggered: true
    });

  } catch (error) {
    console.error('Log access error:', error);
    res.status(500).json({ error: 'Failed to log access' });
  }
});

/**
 * @route   GET /api/decoys/stats/summary
 * @desc    Get summary statistics of all decoys
 * @access  Public
 */
router.get('/stats/summary', async (req, res) => {
  try {
    const totalDecoys = await DecoyEnvironment.countDocuments();
    const activeDecoys = await DecoyEnvironment.countDocuments({ status: 'active' });
    const compromisedDecoys = await DecoyEnvironment.countDocuments({ status: 'compromised' });
    
    const totalAccesses = await DecoyEnvironment.aggregate([
      { $group: { _id: null, total: { $sum: '$accessCount' } } }
    ]);

    res.json({
      total: totalDecoys,
      active: activeDecoys,
      compromised: compromisedDecoys,
      totalAccesses: totalAccesses[0]?.total || 0
    });

  } catch (error) {
    console.error('Get decoy stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;
