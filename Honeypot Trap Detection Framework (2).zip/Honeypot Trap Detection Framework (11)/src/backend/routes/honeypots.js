const express = require('express');
const router = express.Router();
const Honeypot = require('../models/Honeypot');

/**
 * @route   GET /api/honeypots
 * @desc    Get all honeypots
 * @access  Public
 */
router.get('/', async (req, res) => {
  try {
    const { type, status } = req.query;
    
    const query = {};
    if (type) query.type = type;
    if (status) query.status = status;

    const honeypots = await Honeypot.find(query)
      .populate('decoyEnvironments')
      .sort({ createdAt: -1 });

    res.json({
      count: honeypots.length,
      honeypots
    });

  } catch (error) {
    console.error('Get honeypots error:', error);
    res.status(500).json({ error: 'Failed to fetch honeypots' });
  }
});

/**
 * @route   GET /api/honeypots/:id
 * @desc    Get specific honeypot
 * @access  Public
 */
router.get('/:id', async (req, res) => {
  try {
    const honeypot = await Honeypot.findById(req.params.id)
      .populate('decoyEnvironments');
    
    if (!honeypot) {
      return res.status(404).json({ error: 'Honeypot not found' });
    }

    res.json(honeypot);

  } catch (error) {
    console.error('Get honeypot error:', error);
    res.status(500).json({ error: 'Failed to fetch honeypot' });
  }
});

/**
 * @route   POST /api/honeypots
 * @desc    Create new honeypot
 * @access  Admin
 */
router.post('/', async (req, res) => {
  try {
    const honeypot = new Honeypot(req.body);
    await honeypot.save();

    res.status(201).json({
      message: 'Honeypot created',
      honeypot
    });

  } catch (error) {
    console.error('Create honeypot error:', error);
    res.status(500).json({ error: 'Failed to create honeypot' });
  }
});

/**
 * @route   PUT /api/honeypots/:id
 * @desc    Update honeypot
 * @access  Admin
 */
router.put('/:id', async (req, res) => {
  try {
    const honeypot = await Honeypot.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!honeypot) {
      return res.status(404).json({ error: 'Honeypot not found' });
    }

    res.json({
      message: 'Honeypot updated',
      honeypot
    });

  } catch (error) {
    console.error('Update honeypot error:', error);
    res.status(500).json({ error: 'Failed to update honeypot' });
  }
});

/**
 * @route   DELETE /api/honeypots/:id
 * @desc    Delete honeypot
 * @access  Admin
 */
router.delete('/:id', async (req, res) => {
  try {
    const honeypot = await Honeypot.findByIdAndDelete(req.params.id);

    if (!honeypot) {
      return res.status(404).json({ error: 'Honeypot not found' });
    }

    res.json({ message: 'Honeypot deleted' });

  } catch (error) {
    console.error('Delete honeypot error:', error);
    res.status(500).json({ error: 'Failed to delete honeypot' });
  }
});

/**
 * @route   POST /api/honeypots/:id/connection
 * @desc    Log connection to honeypot
 * @access  Public
 */
router.post('/:id/connection', async (req, res) => {
  try {
    const { ip, duration, malicious } = req.body;
    
    const honeypot = await Honeypot.findById(req.params.id);
    if (!honeypot) {
      return res.status(404).json({ error: 'Honeypot not found' });
    }

    honeypot.logConnection(ip, duration, malicious);
    await honeypot.save();

    res.json({
      message: 'Connection logged',
      stats: honeypot.stats
    });

  } catch (error) {
    console.error('Log connection error:', error);
    res.status(500).json({ error: 'Failed to log connection' });
  }
});

/**
 * @route   GET /api/honeypots/stats/summary
 * @desc    Get summary statistics
 * @access  Public
 */
router.get('/stats/summary', async (req, res) => {
  try {
    const totalHoneypots = await Honeypot.countDocuments();
    const activeHoneypots = await Honeypot.countDocuments({ status: 'active' });
    
    const stats = await Honeypot.aggregate([
      {
        $group: {
          _id: null,
          totalConnections: { $sum: '$stats.totalConnections' },
          totalAttacks: { $sum: '$stats.totalAttacks' },
          blockedAttempts: { $sum: '$stats.blockedAttempts' },
          uniqueAttackers: { $sum: '$stats.uniqueAttackers' }
        }
      }
    ]);

    res.json({
      total: totalHoneypots,
      active: activeHoneypots,
      stats: stats[0] || {
        totalConnections: 0,
        totalAttacks: 0,
        blockedAttempts: 0,
        uniqueAttackers: 0
      }
    });

  } catch (error) {
    console.error('Get honeypot stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;
