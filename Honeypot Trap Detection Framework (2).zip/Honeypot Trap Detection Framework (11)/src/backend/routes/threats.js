const express = require('express');
const router = express.Router();
const AttackLog = require('../models/AttackLog');

/**
 * @route   GET /api/threats/feed
 * @desc    Get real-time threat feed
 * @access  Public
 */
router.get('/feed', async (req, res) => {
  try {
    const { limit = 20, severity } = req.query;
    
    const query = {};
    if (severity) query.severity = severity;

    const threats = await AttackLog.find(query)
      .populate('targetHoneypot', 'name type')
      .populate('targetDecoy', 'name type')
      .limit(parseInt(limit))
      .sort({ detectedAt: -1 })
      .select('attackId sourceIp sourceCountry attackType severity status detectedAt threatScore');

    res.json({
      count: threats.length,
      threats
    });

  } catch (error) {
    console.error('Get threat feed error:', error);
    res.status(500).json({ error: 'Failed to fetch threat feed' });
  }
});

/**
 * @route   GET /api/threats/map
 * @desc    Get threat map data (coordinates for visualization)
 * @access  Public
 */
router.get('/map', async (req, res) => {
  try {
    const { limit = 100 } = req.query;

    const threats = await AttackLog.find({
      'sourceCoordinates.lat': { $exists: true },
      'sourceCoordinates.lng': { $exists: true }
    })
      .limit(parseInt(limit))
      .sort({ detectedAt: -1 })
      .select('sourceIp sourceCountry sourceCity sourceCoordinates attackType severity detectedAt');

    res.json({
      count: threats.length,
      threats
    });

  } catch (error) {
    console.error('Get threat map error:', error);
    res.status(500).json({ error: 'Failed to fetch threat map data' });
  }
});

/**
 * @route   GET /api/threats/countries
 * @desc    Get attacks by country
 * @access  Public
 */
router.get('/countries', async (req, res) => {
  try {
    const attacksByCountry = await AttackLog.aggregate([
      {
        $group: {
          _id: '$sourceCountry',
          count: { $sum: 1 },
          highSeverity: {
            $sum: { $cond: [{ $eq: ['$severity', 'high'] }, 1, 0] }
          },
          critical: {
            $sum: { $cond: [{ $eq: ['$severity', 'critical'] }, 1, 0] }
          }
        }
      },
      { $sort: { count: -1 } },
      { $limit: 20 }
    ]);

    res.json({
      count: attacksByCountry.length,
      countries: attacksByCountry
    });

  } catch (error) {
    console.error('Get countries error:', error);
    res.status(500).json({ error: 'Failed to fetch country data' });
  }
});

/**
 * @route   GET /api/threats/top-attackers
 * @desc    Get top attacker IPs
 * @access  Public
 */
router.get('/top-attackers', async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    const topAttackers = await AttackLog.aggregate([
      {
        $group: {
          _id: '$sourceIp',
          count: { $sum: 1 },
          countries: { $addToSet: '$sourceCountry' },
          attackTypes: { $addToSet: '$attackType' },
          maxThreatScore: { $max: '$threatScore' },
          lastSeen: { $max: '$detectedAt' }
        }
      },
      { $sort: { count: -1 } },
      { $limit: parseInt(limit) }
    ]);

    res.json({
      count: topAttackers.length,
      attackers: topAttackers
    });

  } catch (error) {
    console.error('Get top attackers error:', error);
    res.status(500).json({ error: 'Failed to fetch top attackers' });
  }
});

module.exports = router;
