/**
 * Database Seed Script
 * Populates MongoDB with fake honeypot data to mislead attackers
 */

const mongoose = require('mongoose');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Honeypot = require('../models/Honeypot');
const DecoyEnvironment = require('../models/DecoyEnvironment');
const AttackLog = require('../models/AttackLog');

// MongoDB connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://ganeshmunaga@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority';

// Fake data generators
const fakeHoneypots = [
  {
    name: 'SSH Honeypot - Production Server',
    type: 'SSH',
    protocol: 'ssh',
    port: 22,
    status: 'active',
    location: 'US-East-1',
    ipAddress: '192.168.1.100',
    attackCount: 1247,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
  {
    name: 'HTTP Server - Web Portal',
    type: 'HTTP',
    protocol: 'http',
    port: 80,
    status: 'active',
    location: 'EU-West-2',
    ipAddress: '192.168.1.101',
    attackCount: 2891,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
  {
    name: 'FTP Server - File Storage',
    type: 'FTP',
    protocol: 'ftp',
    port: 21,
    status: 'active',
    location: 'Asia-Pacific-1',
    ipAddress: '192.168.1.102',
    attackCount: 567,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
  {
    name: 'SMTP Mail Server',
    type: 'SMTP',
    protocol: 'smtp',
    port: 25,
    status: 'active',
    location: 'US-West-1',
    ipAddress: '192.168.1.103',
    attackCount: 934,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
  {
    name: 'MySQL Database Server',
    type: 'Database',
    protocol: 'mysql',
    port: 3306,
    status: 'active',
    location: 'EU-Central-1',
    ipAddress: '192.168.1.104',
    attackCount: 1823,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
  {
    name: 'RDP Windows Server',
    type: 'RDP',
    protocol: 'rdp',
    port: 3389,
    status: 'active',
    location: 'US-East-2',
    ipAddress: '192.168.1.105',
    attackCount: 445,
    lastActivity: new Date(Date.now() - Math.random() * 3600000),
  },
];

const fakeDecoyEnvironments = [
  {
    name: 'Production Database - Customer Records',
    type: 'database',
    status: 'active',
    credentials: [
      { username: 'admin', password: 'admin123', accessLevel: 'root' },
      { username: 'dbuser', password: 'database2024', accessLevel: 'read-write' },
      { username: 'backup_user', password: 'backup@123', accessLevel: 'read-only' },
    ],
    files: [
      { name: 'customers.sql', type: 'database', size: '2.4 GB', path: '/var/db/backups/', isBait: true },
      { name: 'financial_records.csv', type: 'csv', size: '156 MB', path: '/var/db/exports/', isBait: true },
      { name: 'user_passwords.txt', type: 'text', size: '45 KB', path: '/tmp/', isBait: true },
    ],
    services: ['mysql', 'postgresql', 'redis'],
    accessCount: 34,
    lastAccessed: new Date(Date.now() - Math.random() * 86400000),
  },
  {
    name: 'Corporate File Server',
    type: 'fileserver',
    status: 'active',
    credentials: [
      { username: 'administrator', password: 'Password123!', accessLevel: 'admin' },
      { username: 'fileadmin', password: 'files2024', accessLevel: 'read-write' },
    ],
    files: [
      { name: 'company_secrets.docx', type: 'document', size: '234 KB', path: '/shares/confidential/', isBait: true },
      { name: 'salary_data_2024.xlsx', type: 'spreadsheet', size: '89 KB', path: '/shares/hr/', isBait: true },
      { name: 'api_keys.json', type: 'json', size: '12 KB', path: '/shares/dev/', isBait: true },
    ],
    services: ['smb', 'ftp', 'sftp'],
    accessCount: 67,
    lastAccessed: new Date(Date.now() - Math.random() * 86400000),
  },
  {
    name: 'Development Git Repository',
    type: 'repository',
    status: 'active',
    credentials: [
      { username: 'git', password: 'gitpassword', accessLevel: 'read-write' },
      { username: 'developer', password: 'dev@2024', accessLevel: 'contributor' },
    ],
    files: [
      { name: '.env', type: 'environment', size: '2 KB', path: '/repos/main/', isBait: true },
      { name: 'config.production.js', type: 'javascript', size: '8 KB', path: '/repos/main/config/', isBait: true },
      { name: 'aws_credentials.txt', type: 'text', size: '1 KB', path: '/repos/main/.aws/', isBait: true },
    ],
    services: ['git', 'ssh'],
    accessCount: 23,
    lastAccessed: new Date(Date.now() - Math.random() * 86400000),
  },
  {
    name: 'Email Server - Exchange',
    type: 'email',
    status: 'active',
    credentials: [
      { username: 'postmaster', password: 'mail123', accessLevel: 'admin' },
      { username: 'support@company.com', password: 'Support2024', accessLevel: 'user' },
    ],
    files: [
      { name: 'inbox_backup.pst', type: 'email', size: '1.2 GB', path: '/mail/backups/', isBait: true },
      { name: 'contacts.csv', type: 'csv', size: '234 KB', path: '/mail/exports/', isBait: true },
    ],
    services: ['smtp', 'imap', 'pop3'],
    accessCount: 12,
    lastAccessed: new Date(Date.now() - Math.random() * 86400000),
  },
];

const attackTypes = ['SQL Injection', 'SSH Brute Force', 'Port Scan', 'DDoS', 'Malware Upload', 'XSS', 'RCE Attempt'];
const severities = ['critical', 'high', 'medium', 'low'];
const countries = [
  { country: 'China', city: 'Beijing', lat: 39.9042, lon: 116.4074 },
  { country: 'Russia', city: 'Moscow', lat: 55.7558, lon: 37.6173 },
  { country: 'USA', city: 'New York', lat: 40.7128, lon: -74.0060 },
  { country: 'Brazil', city: 'São Paulo', lat: -23.5505, lon: -46.6333 },
  { country: 'India', city: 'Mumbai', lat: 19.0760, lon: 72.8777 },
  { country: 'Germany', city: 'Berlin', lat: 52.5200, lon: 13.4050 },
  { country: 'UK', city: 'London', lat: 51.5074, lon: -0.1278 },
  { country: 'Japan', city: 'Tokyo', lat: 35.6762, lon: 139.6503 },
];

function generateFakeAttacks(count = 100) {
  const attacks = [];
  
  for (let i = 0; i < count; i++) {
    const location = countries[Math.floor(Math.random() * countries.length)];
    const attackType = attackTypes[Math.floor(Math.random() * attackTypes.length)];
    const severity = severities[Math.floor(Math.random() * severities.length)];
    
    attacks.push({
      sourceIp: `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
      targetHoneypot: fakeHoneypots[Math.floor(Math.random() * fakeHoneypots.length)].name,
      attackType,
      severity,
      protocol: ['tcp', 'udp', 'http', 'ssh'][Math.floor(Math.random() * 4)],
      payload: `${attackType} detected at ${new Date().toISOString()}`,
      location: {
        country: location.country,
        city: location.city,
        lat: location.lat,
        lon: location.lon,
      },
      timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000), // Last 7 days
      blocked: Math.random() > 0.3, // 70% blocked
      tags: ['automated', 'suspicious'],
    });
  }
  
  return attacks;
}

async function seedDatabase() {
  try {
    console.log('🌱 Starting database seed...\n');
    
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB Atlas\n');
    
    // Clear existing data
    console.log('🗑️  Clearing existing data...');
    await Promise.all([
      Honeypot.deleteMany({}),
      DecoyEnvironment.deleteMany({}),
      AttackLog.deleteMany({}),
    ]);
    console.log('✅ Cleared old data\n');
    
    // Insert honeypots
    console.log('📡 Inserting honeypots...');
    const honeypots = await Honeypot.insertMany(fakeHoneypots);
    console.log(`✅ Inserted ${honeypots.length} honeypots\n`);
    
    // Insert decoy environments
    console.log('🎭 Inserting decoy environments...');
    const decoys = await DecoyEnvironment.insertMany(fakeDecoyEnvironments);
    console.log(`✅ Inserted ${decoys.length} decoy environments\n`);
    
    // Generate and insert fake attacks
    console.log('⚔️  Generating fake attack logs...');
    const attacks = generateFakeAttacks(200);
    const attackLogs = await AttackLog.insertMany(attacks);
    console.log(`✅ Inserted ${attackLogs.length} attack logs\n`);
    
    // Summary
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✨ Database seeding completed!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`📊 Total Records: ${honeypots.length + decoys.length + attackLogs.length}`);
    console.log(`   • Honeypots: ${honeypots.length}`);
    console.log(`   • Decoy Environments: ${decoys.length}`);
    console.log(`   • Attack Logs: ${attackLogs.length}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    // Display sample data
    console.log('📋 Sample Decoy Credentials (for testing):');
    decoys.slice(0, 2).forEach((decoy, i) => {
      console.log(`\n   ${i + 1}. ${decoy.name}:`);
      decoy.credentials.forEach(cred => {
        console.log(`      - ${cred.username} / ${cred.password} (${cred.accessLevel})`);
      });
    });
    console.log('\n');
    
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  } finally {
    await mongoose.connection.close();
    console.log('👋 Database connection closed');
    process.exit(0);
  }
}

// Run the seed
seedDatabase();
