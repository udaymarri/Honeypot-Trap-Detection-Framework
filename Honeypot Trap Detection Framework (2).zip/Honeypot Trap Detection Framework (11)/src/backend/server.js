/**
 * HONEYPOT TRAP DETECTION FRAMEWORK
 * Node.js + Express + MongoDB Backend API
 * 
 * This server handles:
 * - User authentication with mandatory 2FA
 * - Fake honeypot data storage in MongoDB
 * - Decoy environments to mislead attackers
 * - Attack logs and threat intelligence
 */

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// MongoDB Connection
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://ganeshmunaga@cluster0.15rkrdo.mongodb.net/honeypot-defense?retryWrites=true&w=majority';

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('✅ Connected to MongoDB Atlas');
  console.log('📊 Database: honeypot-defense');
})
.catch((error) => {
  console.error('❌ MongoDB connection error:', error);
  process.exit(1);
});

// Database event handlers
mongoose.connection.on('error', (err) => {
  console.error('MongoDB error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.warn('⚠️ MongoDB disconnected. Attempting to reconnect...');
});

mongoose.connection.on('reconnected', () => {
  console.log('✅ MongoDB reconnected');
});

// Import routes
const authRoutes = require('./routes/auth');
const honeypotRoutes = require('./routes/honeypots');
const decoyRoutes = require('./routes/decoys');
const attackRoutes = require('./routes/attacks');
const threatRoutes = require('./routes/threats');

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/honeypots', honeypotRoutes);
app.use('/api/decoys', decoyRoutes);
app.use('/api/attacks', attackRoutes);
app.use('/api/threats', threatRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    version: '2.4.1'
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    name: 'Honeypot Trap Detection Framework API',
    version: '2.4.1',
    description: 'Cyber Deception & Intrusion Analysis System',
    endpoints: {
      health: '/api/health',
      auth: '/api/auth',
      honeypots: '/api/honeypots',
      decoys: '/api/decoys',
      attacks: '/api/attacks',
      threats: '/api/threats'
    }
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Cannot ${req.method} ${req.path}`,
    timestamp: new Date().toISOString()
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    timestamp: new Date().toISOString(),
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log('\n🚀 ===================================');
  console.log('   HONEYPOT DEFENSE GRID API');
  console.log('   ===================================');
  console.log(`   🌐 Server running on port ${PORT}`);
  console.log(`   🔗 http://localhost:${PORT}`);
  console.log(`   📡 MongoDB: Connected`);
  console.log('   ===================================\n');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  mongoose.connection.close(false, () => {
    console.log('MongoDB connection closed.');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received. Shutting down gracefully...');
  mongoose.connection.close(false, () => {
    console.log('MongoDB connection closed.');
    process.exit(0);
  });
});
