import { useState } from 'react';
import { Plus, Server } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { toast } from 'sonner@2.0.3';

export function AddHoneypotDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [port, setPort] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulate adding honeypot
    toast.success(`Honeypot "${name}" deployed successfully on port ${port}`, {
      description: `Type: ${type} • Status: Active`,
    });
    
    // Reset form
    setName('');
    setType('');
    setPort('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-primary hover:bg-primary/90 font-mono">
          <Plus className="w-4 h-4" />
          Deploy Honeypot
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md bg-card border-primary/30">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2">
            <Server className="w-5 h-5 text-primary" />
            Deploy New Honeypot
          </DialogTitle>
          <DialogDescription className="font-mono text-sm">
            Configure and deploy a new honeypot to your defense grid
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="font-mono text-sm">
              Honeypot Name
            </Label>
            <Input
              id="name"
              placeholder="e.g., SSH Honeypot Delta"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="bg-input-background border-primary/30 font-mono"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type" className="font-mono text-sm">
              Protocol Type
            </Label>
            <Select value={type} onValueChange={setType} required>
              <SelectTrigger className="bg-input-background border-primary/30 font-mono">
                <SelectValue placeholder="Select protocol" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="SSH">SSH</SelectItem>
                <SelectItem value="HTTP">HTTP</SelectItem>
                <SelectItem value="HTTPS">HTTPS</SelectItem>
                <SelectItem value="FTP">FTP</SelectItem>
                <SelectItem value="SMTP">SMTP</SelectItem>
                <SelectItem value="MySQL">MySQL</SelectItem>
                <SelectItem value="Telnet">Telnet</SelectItem>
                <SelectItem value="RDP">RDP</SelectItem>
                <SelectItem value="SMB">SMB</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="port" className="font-mono text-sm">
              Port Number
            </Label>
            <Input
              id="port"
              type="number"
              placeholder="e.g., 2222"
              value={port}
              onChange={(e) => setPort(e.target.value)}
              required
              min="1"
              max="65535"
              className="bg-input-background border-primary/30 font-mono"
            />
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="font-mono"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-primary hover:bg-primary/90 font-mono"
            >
              Deploy Honeypot
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
