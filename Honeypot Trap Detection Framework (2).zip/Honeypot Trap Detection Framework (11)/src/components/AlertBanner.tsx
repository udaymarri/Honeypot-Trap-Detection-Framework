import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, X, Shield } from 'lucide-react';
import { Button } from './ui/button';

interface Alert {
  id: string;
  type: 'critical' | 'warning' | 'info';
  message: string;
  timestamp: string;
}

const criticalAlerts = [
  'Brute force attack detected from 185.220.101.42 - 127 failed login attempts',
  'SQL injection attempt blocked on /admin endpoint',
  'Command injection detected - Shell execution prevented',
  'Multiple credential stuffing attacks from botnet detected',
  'Suspicious file upload attempt blocked - Potential malware',
];

const warningAlerts = [
  'Port scan detected from 103.75.189.34 - Monitoring activity',
  'Unusual traffic pattern detected - Possible reconnaissance',
  'DDoS probe from multiple sources - Mitigation active',
];

export function AlertBanner() {
  const [currentAlert, setCurrentAlert] = useState<Alert | null>(null);

  useEffect(() => {
    const showAlert = () => {
      const isCritical = Math.random() > 0.6;
      const alerts = isCritical ? criticalAlerts : warningAlerts;
      const message = alerts[Math.floor(Math.random() * alerts.length)];
      
      setCurrentAlert({
        id: `alert-${Date.now()}`,
        type: isCritical ? 'critical' : 'warning',
        message,
        timestamp: new Date().toLocaleTimeString(),
      });

      // Auto-dismiss after 8 seconds
      setTimeout(() => {
        setCurrentAlert(null);
      }, 8000);
    };

    // Show first alert after 3 seconds
    const initialTimeout = setTimeout(showAlert, 3000);

    // Then show alerts periodically
    const interval = setInterval(showAlert, 15000);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, []);

  const handleDismiss = () => {
    setCurrentAlert(null);
  };

  return (
    <AnimatePresence>
      {currentAlert && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-4xl px-4"
        >
          <div 
            className={`
              relative rounded-lg border-2 p-4 backdrop-blur-md shadow-2xl overflow-hidden
              ${currentAlert.type === 'critical' 
                ? 'bg-[#ff0055]/5 border-[#ff0055]/60' 
                : 'bg-[#ffbb00]/5 border-[#ffbb00]/60'
              }
            `}
          >
            {/* Animated glow effect */}
            <motion.div
              className="absolute inset-0 opacity-20"
              animate={{
                background: [
                  `radial-gradient(circle at 0% 50%, ${currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00'}, transparent 50%)`,
                  `radial-gradient(circle at 100% 50%, ${currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00'}, transparent 50%)`,
                  `radial-gradient(circle at 0% 50%, ${currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00'}, transparent 50%)`,
                ],
              }}
              transition={{ duration: 3, repeat: Infinity }}
            />

            <div className="relative flex items-center gap-4">
              {/* Icon */}
              <div className="flex-shrink-0">
                {currentAlert.type === 'critical' ? (
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
                  >
                    <AlertTriangle 
                      className="w-6 h-6" 
                      style={{ color: currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00' }}
                    />
                  </motion.div>
                ) : (
                  <Shield 
                    className="w-6 h-6" 
                    style={{ color: currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00' }}
                  />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2 mb-1">
                  <span 
                    className="uppercase tracking-wider text-xs font-mono"
                    style={{ color: currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00' }}
                  >
                    {currentAlert.type === 'critical' ? 'CRITICAL ALERT' : 'WARNING'}
                  </span>
                  <span className="text-xs text-muted-foreground font-mono">
                    {currentAlert.timestamp}
                  </span>
                </div>
                <p className="text-sm text-foreground font-mono">
                  {currentAlert.message}
                </p>
              </div>

              {/* Close button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDismiss}
                className="flex-shrink-0 h-8 w-8 p-0 hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Progress bar */}
            <motion.div
              className="absolute bottom-0 left-0 h-1"
              style={{ 
                backgroundColor: currentAlert.type === 'critical' ? '#ff0055' : '#ffbb00',
                width: '100%',
              }}
              initial={{ scaleX: 1 }}
              animate={{ scaleX: 0 }}
              transition={{ duration: 8, ease: 'linear' }}
              style={{ transformOrigin: 'left' }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
