import { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';

const timeSeriesData = [
  { time: '00:00', ssh: 45, http: 120, ftp: 23, total: 188 },
  { time: '04:00', ssh: 52, http: 145, ftp: 31, total: 228 },
  { time: '08:00', ssh: 78, http: 210, ftp: 45, total: 333 },
  { time: '12:00', ssh: 95, http: 280, ftp: 67, total: 442 },
  { time: '16:00', ssh: 112, http: 195, ftp: 52, total: 359 },
  { time: '20:00', ssh: 134, http: 245, ftp: 78, total: 457 },
  { time: '23:59', ssh: 89, http: 167, ftp: 41, total: 297 },
];

const protocolData = [
  { protocol: 'SSH', attempts: 605, blocked: 598, success: 7 },
  { protocol: 'HTTP', attempts: 1362, blocked: 1340, success: 22 },
  { protocol: 'FTP', attempts: 337, blocked: 331, success: 6 },
  { protocol: 'SMTP', attempts: 198, blocked: 195, success: 3 },
  { protocol: 'MySQL', attempts: 156, blocked: 154, success: 2 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-primary/50 rounded-lg p-3 shadow-lg">
        <p className="text-sm font-mono text-muted-foreground mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center justify-between gap-4 text-sm">
            <span style={{ color: entry.color }}>{entry.name}:</span>
            <span className="font-mono" style={{ color: entry.color }}>{entry.value}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export function AttackChart() {
  const [activeTab, setActiveTab] = useState('timeline');

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Attack Analytics</h3>
        </div>
        <div className="text-sm text-muted-foreground">Last 24 Hours</div>
      </div>

      {/* Tabs */}
      <div className="p-4 flex-1 flex flex-col">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="protocols">By Protocol</TabsTrigger>
          </TabsList>
          
          <TabsContent value="timeline" className="flex-1 mt-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeriesData}>
                <defs>
                  <linearGradient id="colorSSH" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00ffff" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00ffff" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorHTTP" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#7b2cbf" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#7b2cbf" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorFTP" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff0055" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#ff0055" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 255, 255, 0.1)" />
                <XAxis 
                  dataKey="time" 
                  stroke="#9090b0"
                  style={{ fontSize: '12px', fontFamily: 'monospace' }}
                />
                <YAxis 
                  stroke="#9090b0"
                  style={{ fontSize: '12px', fontFamily: 'monospace' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="ssh" 
                  stroke="#00ffff" 
                  fillOpacity={1} 
                  fill="url(#colorSSH)"
                  name="SSH"
                  strokeWidth={2}
                />
                <Area 
                  type="monotone" 
                  dataKey="http" 
                  stroke="#7b2cbf" 
                  fillOpacity={1} 
                  fill="url(#colorHTTP)"
                  name="HTTP"
                  strokeWidth={2}
                />
                <Area 
                  type="monotone" 
                  dataKey="ftp" 
                  stroke="#ff0055" 
                  fillOpacity={1} 
                  fill="url(#colorFTP)"
                  name="FTP"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>
          
          <TabsContent value="protocols" className="flex-1 mt-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={protocolData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 255, 255, 0.1)" />
                <XAxis 
                  type="number"
                  stroke="#9090b0"
                  style={{ fontSize: '12px', fontFamily: 'monospace' }}
                />
                <YAxis 
                  type="category"
                  dataKey="protocol" 
                  stroke="#9090b0"
                  style={{ fontSize: '12px', fontFamily: 'monospace' }}
                  width={80}
                />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="attempts" 
                  stroke="#00ffff"
                  strokeWidth={2}
                  dot={{ fill: '#00ffff', r: 4 }}
                  name="Attempts"
                />
                <Line 
                  type="monotone" 
                  dataKey="blocked" 
                  stroke="#00ff88"
                  strokeWidth={2}
                  dot={{ fill: '#00ff88', r: 4 }}
                  name="Blocked"
                />
                <Line 
                  type="monotone" 
                  dataKey="success" 
                  stroke="#ff0055"
                  strokeWidth={2}
                  dot={{ fill: '#ff0055', r: 4 }}
                  name="Success"
                />
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
