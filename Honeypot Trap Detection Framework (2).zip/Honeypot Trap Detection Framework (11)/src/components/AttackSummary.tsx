import { motion } from 'motion/react';
import { BarChart3, TrendingUp, TrendingDown, Activity, Shield, AlertTriangle, Clock, Target, Zap, Globe, Server, Lock, Unlock, Database, FileText, Wifi, Users, Eye, AlertOctagon, CheckCircle2, XCircle } from 'lucide-react';
import { Card } from './ui/card';
import { ScrollArea, ScrollBar } from './ui/scroll-area';

export function AttackSummary() {
  const summaryData = [
    {
      title: 'Total Attacks',
      value: '3,482',
      change: '+24%',
      trend: 'up',
      description: 'Last 24 hours',
    },
    {
      title: 'Blocked Attacks',
      value: '3,441',
      change: '+22%',
      trend: 'up',
      description: '98.8% success rate',
    },
    {
      title: 'Unique IPs',
      value: '847',
      change: '+15%',
      trend: 'up',
      description: 'Attack sources',
    },
    {
      title: 'Avg Response Time',
      value: '12ms',
      change: '-8%',
      trend: 'down',
      description: 'Faster than usual',
    },
  ];

  const topAttackTypes = [
    { type: 'Brute Force', count: 1245, percentage: 36, color: 'bg-primary' },
    { type: 'SQL Injection', count: 892, percentage: 26, color: 'bg-secondary' },
    { type: 'Port Scanning', count: 654, percentage: 19, color: 'bg-destructive' },
    { type: 'XSS Attempts', count: 421, percentage: 12, color: 'bg-accent' },
    { type: 'DDoS Attempts', count: 312, percentage: 9, color: 'bg-[#00ff88]' },
    { type: 'Malware Upload', count: 198, percentage: 6, color: 'bg-[#ff6b9d]' },
    { type: 'Directory Traversal', count: 156, percentage: 4, color: 'bg-[#ffd700]' },
    { type: 'Command Injection', count: 134, percentage: 4, color: 'bg-[#ff8c42]' },
    { type: 'CSRF', count: 89, percentage: 3, color: 'bg-[#c77dff]' },
    { type: 'Other', count: 104, percentage: 3, color: 'bg-muted-foreground' },
  ];

  const topCountries = [
    { country: 'Russia', count: 845, flag: '🇷🇺', severity: 'critical' },
    { country: 'China', count: 723, flag: '🇨🇳', severity: 'critical' },
    { country: 'USA', count: 512, flag: '🇺🇸', severity: 'high' },
    { country: 'Germany', count: 389, flag: '🇩🇪', severity: 'medium' },
    { country: 'Brazil', count: 267, flag: '🇧🇷', severity: 'medium' },
    { country: 'India', count: 234, flag: '🇮🇳', severity: 'medium' },
    { country: 'Ukraine', count: 189, flag: '🇺🇦', severity: 'low' },
    { country: 'Netherlands', count: 156, flag: '🇳🇱', severity: 'low' },
    { country: 'France', count: 134, flag: '🇫🇷', severity: 'low' },
    { country: 'UK', count: 98, flag: '🇬🇧', severity: 'low' },
  ];

  const severityBreakdown = [
    { level: 'Critical', count: 342, percentage: 10, color: 'bg-destructive' },
    { level: 'High', count: 1156, percentage: 33, color: 'bg-[#ff6b9d]' },
    { level: 'Medium', count: 1389, percentage: 40, color: 'bg-[#ffd700]' },
    { level: 'Low', count: 595, percentage: 17, color: 'bg-primary' },
  ];

  const topTargetedPorts = [
    { port: '22 (SSH)', count: 1245, protocol: 'TCP', status: 'monitored' },
    { port: '80 (HTTP)', count: 892, protocol: 'TCP', status: 'monitored' },
    { port: '443 (HTTPS)', count: 756, protocol: 'TCP', status: 'monitored' },
    { port: '3389 (RDP)', count: 543, protocol: 'TCP', status: 'monitored' },
    { port: '21 (FTP)', count: 421, protocol: 'TCP', status: 'monitored' },
    { port: '25 (SMTP)', count: 312, protocol: 'TCP', status: 'monitored' },
    { port: '3306 (MySQL)', count: 287, protocol: 'TCP', status: 'monitored' },
    { port: '5432 (PostgreSQL)', count: 234, protocol: 'TCP', status: 'monitored' },
  ];

  const hourlyTrend = [
    { hour: '00:00', attacks: 124 },
    { hour: '02:00', attacks: 98 },
    { hour: '04:00', attacks: 89 },
    { hour: '06:00', attacks: 156 },
    { hour: '08:00', attacks: 267 },
    { hour: '10:00', attacks: 345 },
    { hour: '12:00', attacks: 412 },
    { hour: '14:00', attacks: 378 },
    { hour: '16:00', attacks: 356 },
    { hour: '18:00', attacks: 312 },
    { hour: '20:00', attacks: 289 },
    { hour: '22:00', attacks: 198 },
  ];

  const topAttackers = [
    { ip: '192.168.1.45', attacks: 234, country: '🇷🇺', type: 'Brute Force' },
    { ip: '10.0.0.128', attacks: 198, country: '🇨🇳', type: 'SQL Injection' },
    { ip: '172.16.0.92', attacks: 167, country: '🇺🇸', type: 'Port Scan' },
    { ip: '203.0.113.5', attacks: 145, country: '🇩🇪', type: 'XSS' },
    { ip: '198.51.100.42', attacks: 123, country: '🇧🇷', type: 'DDoS' },
    { ip: '185.220.101.23', attacks: 112, country: '🇮🇳', type: 'Malware' },
    { ip: '45.142.212.61', attacks: 98, country: '🇺🇦', type: 'Brute Force' },
  ];

  const protocolBreakdown = [
    { protocol: 'HTTP/HTTPS', attacks: 1648, percentage: 47, color: 'bg-primary' },
    { protocol: 'SSH', attacks: 1245, percentage: 36, color: 'bg-secondary' },
    { protocol: 'FTP', attacks: 421, percentage: 12, color: 'bg-destructive' },
    { protocol: 'SMTP', attacks: 312, percentage: 9, color: 'bg-accent' },
    { protocol: 'RDP', attacks: 543, percentage: 16, color: 'bg-[#00ff88]' },
    { protocol: 'DNS', attacks: 189, percentage: 5, color: 'bg-[#ff6b9d]' },
  ];

  const honeypotInteractions = [
    { honeypot: 'SSH-Trap-01', hits: 1245, success: 1203, failed: 42, type: 'SSH' },
    { honeypot: 'Web-Trap-02', hits: 892, success: 856, failed: 36, type: 'HTTP' },
    { honeypot: 'FTP-Trap-03', hits: 421, success: 401, failed: 20, type: 'FTP' },
    { honeypot: 'DB-Trap-04', hits: 312, success: 298, failed: 14, type: 'MySQL' },
    { honeypot: 'Mail-Trap-05', hits: 267, success: 253, failed: 14, type: 'SMTP' },
  ];

  const payloadAnalysis = [
    { signature: 'Shell Upload Attempt', detections: 234, risk: 'critical' },
    { signature: 'Credential Harvesting', detections: 198, risk: 'critical' },
    { signature: 'SQL Union Attack', detections: 167, risk: 'high' },
    { signature: 'XSS Payload', detections: 145, risk: 'high' },
    { signature: 'Path Traversal', detections: 123, risk: 'medium' },
    { signature: 'Command Execution', detections: 112, risk: 'critical' },
  ];

  const geoHeatZones = [
    { region: 'Eastern Europe', threat_level: 9.2, attacks: 1456 },
    { region: 'East Asia', threat_level: 8.7, attacks: 1289 },
    { region: 'North America', threat_level: 6.5, attacks: 845 },
    { region: 'Western Europe', threat_level: 5.8, attacks: 623 },
    { region: 'South America', threat_level: 5.2, attacks: 512 },
  ];

  const attackTimeline = [
    { time: '23:45', event: 'Mass SSH brute force detected', severity: 'critical' },
    { time: '23:12', event: 'SQL injection attempt blocked', severity: 'high' },
    { time: '22:58', event: 'Port scan from Russia', severity: 'medium' },
    { time: '22:34', event: 'XSS payload neutralized', severity: 'high' },
    { time: '22:15', event: 'Malware upload prevented', severity: 'critical' },
  ];

  const weeklyComparison = [
    { day: 'Monday', attacks: 2845, change: '+12%' },
    { day: 'Tuesday', attacks: 3124, change: '+18%' },
    { day: 'Wednesday', attacks: 2956, change: '+8%' },
    { day: 'Thursday', attacks: 3289, change: '+22%' },
    { day: 'Friday', attacks: 3482, change: '+24%' },
    { day: 'Saturday', attacks: 2734, change: '+5%' },
    { day: 'Sunday', attacks: 2512, change: '-3%' },
  ];

  const threatIntelFeeds = [
    { source: 'AlienVault OTX', threats: 1245, last_update: '2 min ago', status: 'active' },
    { source: 'Abuse.ch', threats: 892, last_update: '5 min ago', status: 'active' },
    { source: 'Emerging Threats', threats: 756, last_update: '8 min ago', status: 'active' },
    { source: 'Spamhaus', threats: 634, last_update: '12 min ago', status: 'active' },
  ];

  const systemHealth = [
    { metric: 'CPU Usage', value: '34%', status: 'normal', color: 'text-[#00ff88]' },
    { metric: 'Memory Usage', value: '58%', status: 'normal', color: 'text-[#00ff88]' },
    { metric: 'Disk I/O', value: '23%', status: 'normal', color: 'text-[#00ff88]' },
    { metric: 'Network Load', value: '76%', status: 'elevated', color: 'text-[#ffd700]' },
    { metric: 'Active Connections', value: '847', status: 'normal', color: 'text-[#00ff88]' },
  ];

  const userAgents = [
    { agent: 'curl/7.68.0', count: 456, percentage: 13 },
    { agent: 'Python-requests', count: 389, percentage: 11 },
    { agent: 'Nmap Scripting', count: 312, percentage: 9 },
    { agent: 'Wget/1.20.3', count: 267, percentage: 8 },
    { agent: 'Nikto/2.1.6', count: 234, percentage: 7 },
  ];

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between bg-muted/30">
        <div className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Attack Summary & Analytics</h3>
        </div>
        <div className="text-sm text-muted-foreground font-mono">Last 24h</div>
      </div>

      {/* Content - Scrollable */}
      <ScrollArea className="flex-1 h-full">
        <div className="p-4 space-y-6 pr-2">
        {/* Summary cards */}
        <div className="grid grid-cols-2 gap-3">
          {summaryData.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-muted/30 border border-border/50 rounded-lg p-3 hover:border-primary/50 transition-colors"
            >
              <div className="text-xs text-muted-foreground mb-1 font-mono">
                {item.title}
              </div>
              <div className="flex items-baseline justify-between">
                <div className="text-2xl font-mono text-foreground">
                  {item.value}
                </div>
                <div className={`flex items-center gap-1 text-xs font-mono ${
                  item.trend === 'up' ? 'text-primary' : 'text-[#00ff88]'
                }`}>
                  {item.trend === 'up' ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {item.change}
                </div>
              </div>
              <div className="text-xs text-muted-foreground mt-1 font-mono">
                {item.description}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Severity Breakdown */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            Severity Distribution
          </h4>
          <div className="space-y-2">
            {severityBreakdown.map((severity, index) => (
              <motion.div
                key={severity.level}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{severity.level}</span>
                  <span className="text-xs font-mono text-muted-foreground">
                    {severity.count} ({severity.percentage}%)
                  </span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full ${severity.color}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${severity.percentage}%` }}
                    transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Top attack types */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            Top Attack Types
          </h4>
          <div className="space-y-2">
            {topAttackTypes.map((attack, index) => (
              <motion.div
                key={attack.type}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{attack.type}</span>
                  <span className="text-xs font-mono text-muted-foreground">
                    {attack.count}
                  </span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full ${attack.color}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${attack.percentage}%` }}
                    transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Protocol Breakdown */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Wifi className="w-4 h-4 text-accent" />
            Protocol Distribution
          </h4>
          <div className="space-y-2">
            {protocolBreakdown.map((protocol, index) => (
              <motion.div
                key={protocol.protocol}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{protocol.protocol}</span>
                  <span className="text-xs font-mono text-muted-foreground">
                    {protocol.attacks} ({protocol.percentage}%)
                  </span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full ${protocol.color}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${protocol.percentage}%` }}
                    transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Top countries */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Globe className="w-4 h-4 text-primary" />
            Top Attack Origins
          </h4>
          <div className="space-y-2">
            {topCountries.map((country, index) => (
              <motion.div
                key={country.country}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between bg-muted/30 border border-border/50 rounded p-2 hover:border-primary/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">{country.flag}</span>
                  <span className="text-sm font-mono">{country.country}</span>
                  <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
                    country.severity === 'critical' ? 'bg-destructive/20 text-destructive' :
                    country.severity === 'high' ? 'bg-[#ff6b9d]/20 text-[#ff6b9d]' :
                    country.severity === 'medium' ? 'bg-[#ffd700]/20 text-[#ffd700]' :
                    'bg-primary/20 text-primary'
                  }`}>
                    {country.severity}
                  </span>
                </div>
                <span className="text-sm font-mono text-primary">
                  {country.count}
                </span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Geographic Heat Zones */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Globe className="w-4 h-4 text-destructive" />
            Geographic Threat Heat Zones
          </h4>
          <div className="space-y-2">
            {geoHeatZones.map((zone, index) => (
              <motion.div
                key={zone.region}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{zone.region}</span>
                  <span className="text-xs font-mono text-destructive">
                    Threat: {zone.threat_level}/10
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="font-mono">{zone.attacks} attacks</span>
                  <div className="h-1.5 w-24 bg-muted rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${zone.threat_level > 8 ? 'bg-destructive' : zone.threat_level > 6 ? 'bg-[#ff6b9d]' : 'bg-[#ffd700]'}`}
                      style={{ width: `${zone.threat_level * 10}%` }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Top Targeted Ports */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-accent" />
            Most Targeted Ports
          </h4>
          <div className="space-y-2">
            {topTargetedPorts.map((port, index) => (
              <motion.div
                key={port.port}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between bg-muted/30 border border-border/50 rounded p-2 hover:border-accent/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono text-accent">{port.port}</span>
                  <span className="text-xs font-mono text-muted-foreground px-1.5 py-0.5 rounded bg-muted">
                    {port.protocol}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-muted-foreground">{port.count}</span>
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Honeypot Interactions */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Server className="w-4 h-4 text-secondary" />
            Honeypot Interaction Stats
          </h4>
          <div className="space-y-2">
            {honeypotInteractions.map((honeypot, index) => (
              <motion.div
                key={honeypot.honeypot}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono">{honeypot.honeypot}</span>
                    <span className="text-xs font-mono text-muted-foreground px-1.5 py-0.5 rounded bg-muted">
                      {honeypot.type}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-primary">{honeypot.hits} hits</span>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono">
                  <div className="flex items-center gap-1 text-[#00ff88]">
                    <CheckCircle2 className="w-3 h-3" />
                    {honeypot.success}
                  </div>
                  <div className="flex items-center gap-1 text-destructive">
                    <XCircle className="w-3 h-3" />
                    {honeypot.failed}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Payload Analysis */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Database className="w-4 h-4 text-[#ff6b9d]" />
            Malicious Payload Signatures
          </h4>
          <div className="space-y-2">
            {payloadAnalysis.map((payload, index) => (
              <motion.div
                key={payload.signature}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between bg-muted/30 border border-border/50 rounded p-2 hover:border-[#ff6b9d]/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono">{payload.signature}</span>
                  <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
                    payload.risk === 'critical' ? 'bg-destructive/20 text-destructive' :
                    payload.risk === 'high' ? 'bg-[#ff6b9d]/20 text-[#ff6b9d]' :
                    'bg-[#ffd700]/20 text-[#ffd700]'
                  }`}>
                    {payload.risk}
                  </span>
                </div>
                <span className="text-xs font-mono text-muted-foreground">{payload.detections}</span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Attack Timeline */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#ffd700]" />
            Recent Critical Events
          </h4>
          <div className="space-y-2">
            {attackTimeline.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">{event.time}</span>
                    <span className={`w-2 h-2 rounded-full ${
                      event.severity === 'critical' ? 'bg-destructive animate-pulse' :
                      event.severity === 'high' ? 'bg-[#ff6b9d] animate-pulse' :
                      'bg-[#ffd700]'
                    }`} />
                  </div>
                  <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
                    event.severity === 'critical' ? 'bg-destructive/20 text-destructive' :
                    event.severity === 'high' ? 'bg-[#ff6b9d]/20 text-[#ff6b9d]' :
                    'bg-[#ffd700]/20 text-[#ffd700]'
                  }`}>
                    {event.severity}
                  </span>
                </div>
                <div className="text-sm font-mono mt-1">{event.event}</div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Hourly Attack Trend */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-secondary" />
            Hourly Attack Trend
          </h4>
          <div className="space-y-2">
            {hourlyTrend.map((hour, index) => (
              <motion.div
                key={hour.hour}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{hour.hour}</span>
                  <span className="text-xs font-mono text-secondary">{hour.attacks} attacks</span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-secondary"
                    initial={{ width: 0 }}
                    animate={{ width: `${(hour.attacks / 412) * 100}%` }}
                    transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Weekly Comparison */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Weekly Attack Comparison
          </h4>
          <div className="space-y-2">
            {weeklyComparison.map((day, index) => (
              <motion.div
                key={day.day}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-mono">{day.day}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">{day.attacks}</span>
                    <span className={`text-xs font-mono ${day.change.startsWith('+') ? 'text-primary' : 'text-[#00ff88]'}`}>
                      {day.change}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Top Attackers */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Zap className="w-4 h-4 text-destructive" />
            Most Active Attackers
          </h4>
          <div className="space-y-2">
            {topAttackers.map((attacker, index) => (
              <motion.div
                key={attacker.ip}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2 hover:border-destructive/50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{attacker.country}</span>
                    <span className="text-sm font-mono text-foreground">{attacker.ip}</span>
                  </div>
                  <span className="text-xs font-mono text-destructive">{attacker.attacks}</span>
                </div>
                <div className="text-xs text-muted-foreground font-mono mt-1">
                  Primary: {attacker.type}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* User Agents */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Users className="w-4 h-4 text-accent" />
            Top Attack User Agents
          </h4>
          <div className="space-y-2">
            {userAgents.map((ua, index) => (
              <motion.div
                key={ua.agent}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{ua.agent}</span>
                  <span className="text-xs font-mono text-muted-foreground">
                    {ua.count} ({ua.percentage}%)
                  </span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-accent"
                    initial={{ width: 0 }}
                    animate={{ width: `${ua.percentage * 7}%` }}
                    transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Threat Intelligence Feeds */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#00ff88]" />
            Threat Intelligence Feeds
          </h4>
          <div className="space-y-2">
            {threatIntelFeeds.map((feed, index) => (
              <motion.div
                key={feed.source}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-muted/30 border border-border/50 rounded p-2"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-mono">{feed.source}</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
                    <span className="text-xs font-mono text-[#00ff88]">{feed.status}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs font-mono text-muted-foreground">
                  <span>{feed.threats} threats</span>
                  <span>{feed.last_update}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* System Health */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#00ff88]" />
            System Health Monitor
          </h4>
          <div className="bg-muted/30 border border-border/50 rounded-lg p-3">
            <div className="space-y-3">
              {systemHealth.map((metric, index) => (
                <motion.div 
                  key={metric.metric}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-between"
                >
                  <span className="text-sm font-mono">{metric.metric}</span>
                  <span className={`text-xs font-mono ${metric.color}`}>{metric.value}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Protection Status */}
        <div>
          <h4 className="text-sm font-mono mb-3 flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#00ff88]" />
            Protection Status
          </h4>
          <div className="bg-muted/30 border border-border/50 rounded-lg p-3">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">Firewall Rules</span>
                <span className="text-xs font-mono text-[#00ff88]">Active (847)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">IDS/IPS</span>
                <span className="text-xs font-mono text-[#00ff88]">Enabled</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">Rate Limiting</span>
                <span className="text-xs font-mono text-[#00ff88]">On</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">Blacklisted IPs</span>
                <span className="text-xs font-mono text-primary">623</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">Auto-Ban Threshold</span>
                <span className="text-xs font-mono text-muted-foreground">5 attempts</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-mono">SSL/TLS Inspection</span>
                <span className="text-xs font-mono text-[#00ff88]">Active</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom padding for scroll */}
        <div className="h-4" />
        </div>
        <ScrollBar className="w-3 bg-muted/20 hover:bg-muted/40" />
      </ScrollArea>
    </div>
  );
}
