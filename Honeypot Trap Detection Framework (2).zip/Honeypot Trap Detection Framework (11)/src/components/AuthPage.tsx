import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Lock, Eye, EyeOff, ShieldCheck, Fingerprint, ArrowLeft, Mail, QrCode, Clock, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { InputOTP, InputOTPGroup, InputOTPSlot } from './ui/input-otp';
import { MatrixBackground } from './MatrixBackground';
import { MockBackendAPI, SessionStorage } from '../services/mockBackend';
import { toast } from 'sonner@2.0.3';

interface AuthPageProps {
  onAuthenticated: () => void;
  onBack: () => void;
}

export function AuthPage({ onAuthenticated, onBack }: AuthPageProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [step, setStep] = useState<'auth' | '2fa' | 'setup2fa'>('auth');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionToken, setSessionToken] = useState('');
  const [use2FAMethod, setUse2FAMethod] = useState<'totp' | 'email'>('totp');
  const [totpQRCode, setTotpQRCode] = useState('');
  const [totpSecret, setTotpSecret] = useState('');
  const [demoOTP, setDemoOTP] = useState(''); // For demo purposes
  const [setupTimer, setSetupTimer] = useState(120); // 2 minutes for setup
  const [setupTimerActive, setSetupTimerActive] = useState(false);
  const [newUserId, setNewUserId] = useState(''); // Store new user ID for 2FA setup
  const [debugCode, setDebugCode] = useState(''); // Debug: show current valid code

  // Timer countdown effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (setupTimerActive && setupTimer > 0) {
      interval = setInterval(() => {
        setSetupTimer((prev) => {
          if (prev <= 1) {
            setSetupTimerActive(false);
            toast.error('Setup time expired. Please try again.');
            setStep('auth');
            return 120;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [setupTimerActive, setupTimer]);

  // Update debug code every 5 seconds during setup
  useEffect(() => {
    if (step === 'setup2fa' && totpSecret) {
      const updateDebugCode = async () => {
        try {
          const { TOTP } = await import('../services/totp');
          const code = await TOTP.getCurrentToken(totpSecret);
          setDebugCode(code);
        } catch (error) {
          console.error('Failed to generate debug code:', error);
        }
      };

      updateDebugCode(); // Initial update
      const interval = setInterval(updateDebugCode, 5000); // Update every 5 seconds

      return () => clearInterval(interval);
    } else {
      setDebugCode('');
    }
  }, [step, totpSecret]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (activeTab === 'signup') {
        // Registration
        if (password !== confirmPassword) {
          toast.error('Passwords do not match');
          setIsLoading(false);
          return;
        }

        const result = await MockBackendAPI.register(username, email, password);
        
        if (!result.success) {
          toast.error(result.error || 'Registration failed');
          setIsLoading(false);
          return;
        }

        toast.success('Account created successfully!');
        
        // Show 2FA setup
        if (result.totp) {
          setNewUserId(result.user.id); // Store user ID
          setTotpQRCode(result.totp.qrCode);
          setTotpSecret(result.totp.secret);
          setStep('setup2fa');
          setSetupTimer(120); // Reset to 2 minutes
          setSetupTimerActive(true); // Start timer
          setIsLoading(false);
          return;
        }
      } else {
        // Sign In
        const result = await MockBackendAPI.login(username, password);
        
        if (!result.success) {
          toast.error(result.error || 'Login failed');
          setIsLoading(false);
          return;
        }

        // Store session token
        setSessionToken(result.token);
        SessionStorage.setToken(result.token);

        toast.success(`Welcome back, ${result.user.username}!`);

        // Always require 2FA if enabled for the account
        if (result.requires2FA) {
          setStep('2fa');
        } else {
          // For legacy accounts without 2FA, still allow login but show warning
          toast.warning('2FA is not enabled. Please enable it for better security.');
          onAuthenticated();
        }
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.');
      console.error('Auth error:', error);
    }
    
    setIsLoading(false);
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;
    
    setIsLoading(true);
    
    try {
      let result;
      
      if (use2FAMethod === 'totp') {
        result = await MockBackendAPI.verify2FA(sessionToken, otp);
      } else {
        result = await MockBackendAPI.verifyEmailOTP(sessionToken, otp);
      }

      if (!result.success) {
        toast.error(result.error || '2FA verification failed');
        setIsLoading(false);
        return;
      }

      toast.success('2FA verified successfully!');
      onAuthenticated();
    } catch (error) {
      toast.error('Verification failed. Please try again.');
      console.error('2FA error:', error);
    }
    
    setIsLoading(false);
  };

  const handleRequestEmailOTP = async () => {
    setIsLoading(true);
    
    try {
      const result = await MockBackendAPI.requestEmailOTP(sessionToken);
      
      if (!result.success) {
        toast.error(result.error || 'Failed to send OTP');
        setIsLoading(false);
        return;
      }

      toast.success('OTP sent to your email!');
      
      // For demo purposes, show the OTP
      if (result.demoOTP) {
        setDemoOTP(result.demoOTP);
        toast.info(`Demo Mode: Your OTP is ${result.demoOTP}`, {
          duration: 10000,
        });
      }
      
      setUse2FAMethod('email');
    } catch (error) {
      toast.error('Failed to send OTP');
      console.error('Email OTP error:', error);
    }
    
    setIsLoading(false);
  };

  const handleVerifySetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;
    
    setIsLoading(true);
    
    try {
      // Verify the TOTP code with the secret we just generated
      const { TOTP } = await import('../services/totp');
      console.log('[AuthPage] === SETUP VERIFICATION START ===');
      console.log('[AuthPage] Secret:', totpSecret);
      console.log('[AuthPage] Secret length:', totpSecret.length);
      console.log('[AuthPage] User entered OTP:', otp);
      console.log('[AuthPage] Current time:', new Date().toISOString());
      
      // Also generate what we expect
      const expectedCode = await TOTP.getCurrentToken(totpSecret);
      console.log('[AuthPage] Expected code:', expectedCode);
      console.log('[AuthPage] Entered code:', otp);
      console.log('[AuthPage] Codes match:', expectedCode === otp);
      
      const isValid = await TOTP.verify(otp, totpSecret);
      console.log('[AuthPage] Verification result:', isValid);
      
      if (!isValid) {
        console.error('[AuthPage] Setup verification failed');
        toast.error(`Invalid code. Expected: ${expectedCode}, Got: ${otp}`, {
          duration: 10000,
          description: 'Make sure your device time is synchronized',
        });
        setIsLoading(false);
        setOtp('');
        return;
      }
      
      console.log('[AuthPage] Setup verification successful!');
      console.log('[AuthPage] === SETUP VERIFICATION END ===');

      // Stop timer
      setSetupTimerActive(false);
      
      toast.success('🎉 2FA configured successfully!');
      toast.info('You will need your authenticator app every time you sign in.', {
        duration: 5000,
      });
      
      // Reset states
      setStep('auth');
      setActiveTab('signin');
      setTotpQRCode('');
      setTotpSecret('');
      setOtp('');
      setSetupTimer(120);
      setNewUserId('');
      
    } catch (error) {
      toast.error('Verification failed. Please try again.');
      console.error('Setup verification error:', error);
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background/95 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Matrix background */}
      <MatrixBackground />

      {/* Backdrop overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-md z-0"
      />

      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="absolute top-6 left-6 z-30 flex items-center gap-2 px-4 py-2 rounded-lg bg-card/70 backdrop-blur-sm border border-border hover:border-primary/50 transition-all hover:scale-105 text-sm font-mono text-muted-foreground hover:text-primary shadow-lg"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </motion.button>

      {/* Auth container - Popup Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 50, rotateX: -15 }}
        animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
        transition={{ 
          type: 'spring', 
          stiffness: 200, 
          damping: 25,
          duration: 0.6 
        }}
        className="relative z-20 w-full max-w-md"
        style={{ 
          transformStyle: 'preserve-3d',
          perspective: '1000px'
        }}
      >
        {/* 3D Glow layers */}
        <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 rounded-2xl blur-3xl opacity-60 animate-pulse" />
        <div className="absolute -inset-2 bg-primary/10 rounded-2xl blur-2xl" />
        
        <motion.div 
          className="bg-card/95 backdrop-blur-2xl border-2 border-primary/30 rounded-2xl shadow-[0_20px_80px_rgba(0,255,255,0.3)] overflow-hidden relative"
          whileHover={{ 
            scale: 1.02,
            boxShadow: '0 25px 100px rgba(0,255,255,0.4)',
            borderColor: 'rgba(0,255,255,0.5)'
          }}
          style={{ 
            transform: 'translateZ(50px)',
            boxShadow: '0 20px 80px rgba(0,255,255,0.3), inset 0 0 60px rgba(0,255,255,0.05)'
          }}
        >
          {/* Header */}
          <div className="text-center p-6 pb-4">
            <motion.div
              className="inline-flex items-center justify-center w-16 h-16 mb-4 relative"
              animate={{ 
                scale: [1, 1.05, 1],
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
              }}
            >
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl" />
              <div className="relative bg-card border-2 border-primary/50 rounded-full w-full h-full flex items-center justify-center">
                <Shield className="w-7 h-7 text-primary" />
                <Lock className="w-3 h-3 text-primary absolute bottom-1 right-1" />
              </div>
            </motion.div>
            
            <h2 className="font-mono mb-1">Secure Access</h2>
            <p className="text-xs text-muted-foreground font-mono">
              Protected by MongoDB + TOTP 2FA
            </p>
          </div>

          <AnimatePresence mode="wait">
            {step === 'auth' ? (
              <motion.div
                key="auth"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                {/* Tabs */}
                <div className="flex border-b border-border">
                  <button
                    type="button"
                    onClick={() => setActiveTab('signin')}
                    className={`flex-1 px-4 py-3 text-sm font-mono transition-all relative ${
                      activeTab === 'signin'
                        ? 'text-primary'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Sign In
                    {activeTab === 'signin' && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                        transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('signup')}
                    className={`flex-1 px-4 py-3 text-sm font-mono transition-all relative ${
                      activeTab === 'signup'
                        ? 'text-primary'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Sign Up
                    {activeTab === 'signup' && (
                      <motion.div
                        layoutId="activeTab"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                        transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                      />
                    )}
                  </button>
                </div>

                {/* Form */}
                <form onSubmit={handleAuth} className="p-6 space-y-4">
                  {/* Username */}
                  <div className="space-y-2">
                    <Label htmlFor="username" className="font-mono text-xs text-foreground">
                      Username
                    </Label>
                    <Input
                      id="username"
                      type="text"
                      placeholder="Enter your username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                      className="bg-input-background border-border focus:border-primary font-mono h-11"
                    />
                  </div>

                  {/* Email (signup only) */}
                  {activeTab === 'signup' && (
                    <div className="space-y-2">
                      <Label htmlFor="email" className="font-mono text-xs text-foreground">
                        Email
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="bg-input-background border-border focus:border-primary font-mono h-11"
                      />
                    </div>
                  )}

                  {/* Password */}
                  <div className="space-y-2">
                    <Label htmlFor="password" className="font-mono text-xs text-foreground">
                      Password
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="bg-input-background border-border focus:border-primary font-mono h-11 pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors"
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password (signup only) */}
                  {activeTab === 'signup' && (
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="font-mono text-xs text-foreground">
                        Confirm Password
                      </Label>
                      <Input
                        id="confirmPassword"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Confirm your password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                        className="bg-input-background border-border focus:border-primary font-mono h-11"
                      />
                    </div>
                  )}

                  {/* 2FA Notice */}
                  {activeTab === 'signin' ? (
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-3 flex items-start gap-2">
                      <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground font-mono">
                        2FA authentication required for all registered accounts
                      </p>
                    </div>
                  ) : (
                    <div className="bg-secondary/10 border border-secondary/30 rounded-lg p-3 flex items-start gap-2">
                      <ShieldCheck className="w-4 h-4 text-secondary flex-shrink-0 mt-0.5" />
                      <p className="text-xs text-muted-foreground font-mono">
                        2FA will be mandatory. You'll need an authenticator app.
                      </p>
                    </div>
                  )}

                  {/* Submit button */}
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-mono relative overflow-hidden"
                  >
                    <span className="relative z-10">
                      {isLoading ? 'Processing...' : activeTab === 'signin' ? 'Sign In Securely' : 'Create Account'}
                    </span>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                      animate={{ x: ['-100%', '200%'] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                    />
                  </Button>

                  {/* Forgot Password */}
                  {activeTab === 'signin' && (
                    <div className="text-center">
                      <button
                        type="button"
                        onClick={() => {
                          toast.info('Password reset functionality coming soon', {
                            description: 'Contact your system administrator for password recovery',
                          });
                        }}
                        className="text-xs text-muted-foreground hover:text-primary transition-colors font-mono underline"
                      >
                        Forgot Password?
                      </button>
                    </div>
                  )}
                </form>

                {/* Footer */}
                <div className="px-6 pb-6 flex items-center justify-center gap-2 text-xs text-muted-foreground font-mono">
                  <Lock className="w-3 h-3 text-primary" />
                  <span>256-bit encryption</span>
                  <span>·</span>
                  <span>MongoDB + TOTP</span>
                </div>
              </motion.div>
            ) : step === 'setup2fa' ? (
              <motion.div
                key="setup2fa"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="p-6 space-y-6"
              >
                {/* 2FA Setup Header with Timer */}
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-14 h-14 mb-4 relative">
                    <div className="absolute inset-0 bg-primary/20 rounded-full blur-lg" />
                    <div className="relative bg-card border-2 border-primary/50 rounded-full w-full h-full flex items-center justify-center">
                      <QrCode className="w-6 h-6 text-primary" />
                    </div>
                  </div>
                  <h3 className="font-mono mb-1">Setup 2FA</h3>
                  <p className="text-xs text-muted-foreground font-mono mb-2">
                    Scan QR code and verify setup
                  </p>
                  
                  {/* Timer Display */}
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/30 rounded-lg">
                    <Clock className="w-3 h-3 text-primary" />
                    <span className={`text-sm font-mono ${setupTimer < 30 ? 'text-destructive animate-pulse' : 'text-primary'}`}>
                      {formatTime(setupTimer)}
                    </span>
                  </div>
                </div>

                {/* QR Code */}
                {totpQRCode && (
                  <div className="flex justify-center">
                    <div className="bg-white p-4 rounded-lg shadow-lg">
                      <img src={totpQRCode} alt="2FA QR Code" className="w-48 h-48" />
                    </div>
                  </div>
                )}

                {/* Secret Key */}
                {totpSecret && (
                  <div className="bg-muted/30 border border-border rounded-lg p-3">
                    <p className="text-xs text-muted-foreground font-mono mb-1">
                      Manual Entry Key (if QR scan fails):
                    </p>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-mono text-primary break-all flex-1">{totpSecret}</p>
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(totpSecret);
                          toast.success('Secret copied to clipboard!');
                        }}
                        className="px-2 py-1 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded text-xs text-primary transition-colors"
                      >
                        Copy
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground font-mono mt-2">
                      In your authenticator app, choose "Enter a setup key" instead of scanning
                    </p>
                  </div>
                )}

                {/* Verification Form */}
                <form onSubmit={handleVerifySetup} className="space-y-4">
                  {/* Instructions */}
                  <div className="bg-muted/30 border border-border rounded-lg p-3 space-y-2">
                    <p className="text-xs font-mono text-foreground">1. Download Google Authenticator or Authy</p>
                    <p className="text-xs font-mono text-foreground">2. Scan the QR code above</p>
                    <p className="text-xs font-mono text-foreground">3. Enter the 6-digit code below to verify</p>
                  </div>

                  {/* OTP Input for Verification */}
                  <div>
                    <Label className="text-xs text-muted-foreground font-mono mb-2 block">
                      Enter code from authenticator app:
                    </Label>
                    <div className="flex justify-center">
                      <InputOTP
                        maxLength={6}
                        value={otp}
                        onChange={setOtp}
                      >
                        <InputOTPGroup>
                          <InputOTPSlot index={0} className="border-border data-[active]:border-primary" />
                          <InputOTPSlot index={1} className="border-border data-[active]:border-primary" />
                          <InputOTPSlot index={2} className="border-border data-[active]:border-primary" />
                          <InputOTPSlot index={3} className="border-border data-[active]:border-primary" />
                          <InputOTPSlot index={4} className="border-border data-[active]:border-primary" />
                          <InputOTPSlot index={5} className="border-border data-[active]:border-primary" />
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                    
                    {/* DEBUG: Show current valid code */}
                    <div className="mt-3 space-y-2">
                      <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-xs text-destructive font-mono">🐛 DEBUG MODE</p>
                          <RefreshCw className="w-3 h-3 text-destructive animate-spin" />
                        </div>
                        
                        {debugCode ? (
                          <div className="bg-background/50 rounded-lg p-4 mb-3">
                            <p className="text-xs text-muted-foreground font-mono mb-2">
                              Expected Code (updates every 5s):
                            </p>
                            <p className="text-3xl font-mono text-primary text-center tracking-widest">
                              {debugCode}
                            </p>
                          </div>
                        ) : (
                          <div className="bg-background/50 rounded-lg p-4 mb-3">
                            <p className="text-sm text-muted-foreground font-mono text-center">
                              Generating...
                            </p>
                          </div>
                        )}
                        
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              console.log('=== TOTP DEBUG START ===');
                              console.log('Secret:', totpSecret);
                              console.log('Secret length:', totpSecret.length);
                              const { TOTP } = await import('../services/totp');
                              const currentCode = await TOTP.getCurrentToken(totpSecret);
                              console.log('Current valid code:', currentCode);
                              console.log('Current time:', new Date().toISOString());
                              console.log('=== TOTP DEBUG END ===');
                              
                              toast.info('Full debug info logged to console', {
                                duration: 5000,
                              });
                            } catch (error) {
                              console.error('Debug error:', error);
                              toast.error('Debug failed - check console');
                            }
                          }}
                          className="w-full text-xs bg-destructive/20 hover:bg-destructive/30 border border-destructive/40 rounded px-3 py-2 text-destructive font-mono transition-colors"
                        >
                          Log Full Debug Info to Console
                        </button>
                        
                        <p className="text-xs text-muted-foreground font-mono mt-2 text-center">
                          Compare this code with your authenticator app
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Verify button */}
                  <Button
                    type="submit"
                    disabled={isLoading || otp.length !== 6}
                    className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-mono relative overflow-hidden"
                  >
                    <span className="relative z-10">
                      {isLoading ? 'Verifying...' : 'Verify & Complete Setup'}
                    </span>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                      animate={{ x: ['-100%', '200%'] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                    />
                  </Button>

                  {/* Cancel button */}
                  <button
                    type="button"
                    onClick={() => {
                      setStep('auth');
                      setSetupTimerActive(false);
                      setSetupTimer(120);
                      setOtp('');
                      setTotpQRCode('');
                      setTotpSecret('');
                    }}
                    className="w-full text-sm text-muted-foreground hover:text-primary transition-colors font-mono"
                  >
                    ← Cancel setup
                  </button>
                </form>

                {/* Security Notice */}
                <div className="bg-primary/10 border border-primary/30 rounded-lg p-3 flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground font-mono">
                    Save your backup codes after verification. You'll need them if you lose access to your device.
                  </p>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="2fa"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <form onSubmit={handleVerify2FA} className="p-6 space-y-6">
                  {/* 2FA Header */}
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-14 h-14 mb-4 relative">
                      <div className="absolute inset-0 bg-primary/20 rounded-full blur-lg" />
                      <div className="relative bg-card border-2 border-primary/50 rounded-full w-full h-full flex items-center justify-center">
                        {use2FAMethod === 'totp' ? (
                          <Fingerprint className="w-6 h-6 text-primary" />
                        ) : (
                          <Mail className="w-6 h-6 text-primary" />
                        )}
                      </div>
                    </div>
                    <h3 className="font-mono mb-1">
                      {use2FAMethod === 'totp' ? 'Authenticator Code' : 'Email Verification'}
                    </h3>
                    <p className="text-xs text-muted-foreground font-mono">
                      {use2FAMethod === 'totp' 
                        ? 'Enter the 6-digit code from your authenticator app'
                        : 'Enter the code sent to your email'
                      }
                    </p>
                  </div>

                  {/* Demo OTP Display */}
                  {demoOTP && use2FAMethod === 'email' && (
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-3 text-center">
                      <p className="text-xs text-muted-foreground font-mono mb-1">Demo Mode - Your OTP:</p>
                      <p className="text-2xl font-mono text-primary tracking-widest">{demoOTP}</p>
                    </div>
                  )}

                  {/* OTP Input */}
                  <div className="flex justify-center">
                    <InputOTP
                      maxLength={6}
                      value={otp}
                      onChange={setOtp}
                    >
                      <InputOTPGroup>
                        <InputOTPSlot index={0} className="border-border data-[active]:border-primary" />
                        <InputOTPSlot index={1} className="border-border data-[active]:border-primary" />
                        <InputOTPSlot index={2} className="border-border data-[active]:border-primary" />
                        <InputOTPSlot index={3} className="border-border data-[active]:border-primary" />
                        <InputOTPSlot index={4} className="border-border data-[active]:border-primary" />
                        <InputOTPSlot index={5} className="border-border data-[active]:border-primary" />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>

                  {/* Alternative methods */}
                  <div className="flex justify-center gap-2">
                    {use2FAMethod === 'totp' ? (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={handleRequestEmailOTP}
                        disabled={isLoading}
                        className="text-xs font-mono"
                      >
                        <Mail className="w-3 h-3 mr-2" />
                        Use Email OTP instead
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setUse2FAMethod('totp');
                          setDemoOTP('');
                        }}
                        className="text-xs font-mono"
                      >
                        <Fingerprint className="w-3 h-3 mr-2" />
                        Use Authenticator instead
                      </Button>
                    )}
                  </div>

                  {/* Security notice */}
                  <div className="bg-muted/30 border border-border rounded-lg p-3 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground font-mono">
                      Your session is encrypted with AES-256 encryption
                    </p>
                  </div>

                  {/* Verify button */}
                  <Button
                    type="submit"
                    disabled={isLoading || otp.length !== 6}
                    className="w-full h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-mono relative overflow-hidden"
                  >
                    <span className="relative z-10">
                      {isLoading ? 'Verifying...' : 'Verify & Access'}
                    </span>
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                      animate={{ x: ['-100%', '200%'] }}
                      transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                    />
                  </Button>

                  {/* Back button */}
                  <button
                    type="button"
                    onClick={() => setStep('auth')}
                    className="w-full text-sm text-muted-foreground hover:text-primary transition-colors font-mono"
                  >
                    ← Back to authentication
                  </button>
                </form>

                {/* Footer */}
                <div className="px-6 pb-6 flex items-center justify-center gap-2 text-xs text-muted-foreground font-mono">
                  <Lock className="w-3 h-3 text-primary" />
                  <span>256-bit encryption</span>
                  <span>·</span>
                  <span>TOTP 2FA</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Floating corner accents */}
          <div className="absolute top-0 left-0 w-20 h-20 border-l-2 border-t-2 border-primary/50 rounded-tl-2xl" />
          <div className="absolute bottom-0 right-0 w-20 h-20 border-r-2 border-b-2 border-primary/50 rounded-br-2xl" />
          
          {/* Animated border glow */}
          <div className="absolute inset-0 rounded-2xl opacity-50 pointer-events-none">
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{
                background: 'linear-gradient(45deg, transparent 30%, rgba(0,255,255,0.3) 50%, transparent 70%)',
              }}
              animate={{
                backgroundPosition: ['0% 0%', '200% 200%'],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: 'linear',
              }}
            />
          </div>
        </motion.div>
      </motion.div>

      {/* Floating particles around modal */}
      <div className="absolute inset-0 pointer-events-none z-10">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-primary/40 rounded-full"
            style={{
              left: `${50 + Math.cos((i / 8) * Math.PI * 2) * 40}%`,
              top: `${50 + Math.sin((i / 8) * Math.PI * 2) * 40}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.2, 0.8, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.2,
            }}
          />
        ))}
      </div>
    </div>
  );
}
