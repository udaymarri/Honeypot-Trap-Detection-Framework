import { motion } from 'motion/react';

export function CircuitBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Animated circuit board pattern */}
      <svg className="absolute inset-0 w-full h-full opacity-30">
        <defs>
          <pattern id="circuit-pattern" x="0" y="0" width="200" height="200" patternUnits="userSpaceOnUse">
            {/* Horizontal lines */}
            <line x1="0" y1="50" x2="200" y2="50" stroke="rgba(0, 255, 255, 0.3)" strokeWidth="1" />
            <line x1="0" y1="150" x2="200" y2="150" stroke="rgba(107, 70, 255, 0.3)" strokeWidth="1" />
            
            {/* Vertical lines */}
            <line x1="50" y1="0" x2="50" y2="200" stroke="rgba(123, 44, 191, 0.3)" strokeWidth="1" />
            <line x1="150" y1="0" x2="150" y2="200" stroke="rgba(0, 255, 255, 0.3)" strokeWidth="1" />
            
            {/* Circuit nodes */}
            <circle cx="50" cy="50" r="3" fill="rgba(0, 255, 255, 0.6)" />
            <circle cx="150" cy="50" r="3" fill="rgba(107, 70, 255, 0.6)" />
            <circle cx="50" cy="150" r="3" fill="rgba(123, 44, 191, 0.6)" />
            <circle cx="150" cy="150" r="3" fill="rgba(0, 255, 255, 0.6)" />
            
            {/* Small connecting lines */}
            <line x1="50" y1="50" x2="80" y2="50" stroke="rgba(0, 255, 255, 0.4)" strokeWidth="1" />
            <line x1="120" y1="150" x2="150" y2="150" stroke="rgba(123, 44, 191, 0.4)" strokeWidth="1" />
          </pattern>
          
          <linearGradient id="pulse-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(0, 255, 255, 0)" />
            <stop offset="50%" stopColor="rgba(0, 255, 255, 0.8)" />
            <stop offset="100%" stopColor="rgba(0, 255, 255, 0)" />
          </linearGradient>
        </defs>
        
        <rect width="100%" height="100%" fill="url(#circuit-pattern)" />
      </svg>

      {/* Animated scanning lines */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute h-px left-0 right-0"
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(0, 255, 255, 0.8), transparent)',
            top: `${20 + i * 15}%`,
            boxShadow: '0 0 10px rgba(0, 255, 255, 0.8)',
          }}
          animate={{
            scaleX: [0, 1, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: i * 0.6,
            ease: 'easeInOut',
          }}
        />
      ))}

      {/* Data stream particles */}
      <div className="absolute inset-0">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full"
            style={{
              left: `${(i % 6) * 16.6}%`,
              top: `${Math.random() * 100}%`,
              backgroundColor: i % 3 === 0 ? '#00ffff' : i % 3 === 1 ? '#7b2cbf' : '#6b46ff',
              boxShadow: `0 0 8px ${i % 3 === 0 ? '#00ffff' : i % 3 === 1 ? '#7b2cbf' : '#6b46ff'}`,
            }}
            animate={{
              y: ['0vh', '100vh'],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: Math.random() * 3 + 4,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      {/* Glowing energy orbs */}
      <motion.div
        className="absolute w-96 h-96 rounded-full"
        style={{
          top: '10%',
          right: '15%',
          background: 'radial-gradient(circle, rgba(0, 255, 255, 0.15) 0%, transparent 70%)',
          filter: 'blur(60px)',
        }}
        animate={{
          scale: [1, 1.3, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <motion.div
        className="absolute w-80 h-80 rounded-full"
        style={{
          bottom: '20%',
          left: '20%',
          background: 'radial-gradient(circle, rgba(123, 44, 191, 0.12) 0%, transparent 70%)',
          filter: 'blur(70px)',
        }}
        animate={{
          scale: [1, 1.4, 1],
          opacity: [0.4, 0.7, 0.4],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Hexagonal tech overlay */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='52' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l15 8.7v17.3L30 34.6 15 26V8.7z' fill='none' stroke='%2300ffff' stroke-width='0.5'/%3E%3C/svg%3E")`,
          backgroundSize: '60px 52px',
        }}
      />

      {/* Pulsing grid squares */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute border border-primary/20"
          style={{
            width: `${Math.random() * 100 + 50}px`,
            height: `${Math.random() * 100 + 50}px`,
            left: `${Math.random() * 80}%`,
            top: `${Math.random() * 80}%`,
          }}
          animate={{
            opacity: [0.1, 0.5, 0.1],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: Math.random() * 3 + 3,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background/80" />
    </div>
  );
}
