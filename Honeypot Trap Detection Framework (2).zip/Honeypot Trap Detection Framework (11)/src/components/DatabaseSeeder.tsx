import { useState } from 'react';
import { seedDatabase } from '../utils/supabase/seedData';
import { Button } from './ui/button';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { CheckCircle2, Database, Loader2, AlertCircle } from 'lucide-react';

/**
 * Database Seeder Component
 * Allows seeding Supabase with fake honeypot data from the UI
 */

export function DatabaseSeeder() {
  const [isSeeding, setIsSeeding] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    data?: any;
  } | null>(null);

  const handleSeed = async () => {
    setIsSeeding(true);
    setResult(null);

    try {
      console.log('🌱 Starting database seed...');
      const data = await seedDatabase();

      setResult({
        success: true,
        message: 'Database seeded successfully!',
        data,
      });
    } catch (error: any) {
      console.error('❌ Seed error:', error);
      
      setResult({
        success: false,
        message: error.message || 'Failed to seed database',
      });
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="p-6 space-y-4 bg-card border-2 border-cyan-500/30 rounded-lg shadow-lg shadow-cyan-500/20">
      <div className="flex items-center gap-3">
        <div className="relative">
          <Database className="w-8 h-8 text-cyan-400 animate-pulse" />
          <div className="absolute inset-0 blur-lg bg-cyan-500 opacity-50" />
        </div>
        <div>
          <h3 className="text-xl font-semibold text-white">Database Seeder</h3>
          <p className="text-sm text-gray-400">
            Populate Supabase with fake honeypot data
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <Button
          onClick={handleSeed}
          disabled={isSeeding}
          className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500"
        >
          {isSeeding ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Seeding Database...
            </>
          ) : (
            <>
              <Database className="w-4 h-4 mr-2" />
              Seed Database
            </>
          )}
        </Button>

        {result && (
          <Alert
            className={
              result.success
                ? 'border-green-500/50 bg-green-500/10'
                : 'border-red-500/50 bg-red-500/10'
            }
          >
            {result.success ? (
              <CheckCircle2 className="h-4 w-4 text-green-500" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-500" />
            )}
            <AlertTitle className={result.success ? 'text-green-500' : 'text-red-500'}>
              {result.success ? 'Success!' : 'Error'}
            </AlertTitle>
            <AlertDescription className="text-gray-300">
              <div className="whitespace-pre-wrap">{result.message}</div>
              {result.success && result.data && (
                <div className="mt-2 space-y-1 text-xs">
                  <div>✅ Honeypots: {result.data.honeypots}</div>
                  <div>✅ Decoy Environments: {result.data.decoys}</div>
                  <div>✅ Attack Logs: {result.data.attacks}</div>
                  <div className="mt-2 text-cyan-400">
                    Total: {result.data.honeypots + result.data.decoys + result.data.attacks}{' '}
                    records
                  </div>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}
      </div>

      <div className="text-xs text-gray-500 space-y-2">
        <div className="bg-red-500/10 border border-red-500/30 rounded p-3 mb-2">
          <p className="font-semibold text-red-400 mb-2">🚨 FIRST TIME? READ THIS!</p>
          <p className="text-gray-300 text-xs mb-2">
            Before clicking "Seed Database", you MUST run SQL in Supabase:
          </p>
          <ol className="list-decimal list-inside space-y-1 ml-2 text-gray-300 text-xs">
            <li>Go to <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">Supabase Dashboard</a></li>
            <li>Click "SQL Editor" → "+ New Query"</li>
            <li>Open file: <span className="text-purple-400 font-mono">ALL_IN_ONE_FIX.sql</span></li>
            <li>Copy ALL the SQL and paste in editor</li>
            <li>Click "Run" → Wait for "Success"</li>
            <li>Come back and click "Seed Database"</li>
          </ol>
          <p className="mt-2 text-yellow-400 font-semibold text-xs">
            ⚠️ If you skip this step, seeding will fail!
          </p>
        </div>
        
        <div className="border-t border-gray-700 pt-2">
          <p className="font-semibold text-gray-400 mb-1">This will create:</p>
          <ul className="list-disc list-inside space-y-1 ml-2">
            <li>6 Honeypots (SSH, HTTP, FTP, SMTP, MySQL, RDP)</li>
            <li>4 Decoy Environments with fake credentials</li>
            <li>200 Fake Attack Logs from various countries</li>
          </ul>
        </div>
        
        <p className="text-yellow-500 pt-2">
          ⚠️ This will clear existing honeypot data!
        </p>
      </div>
    </div>
  );
}
