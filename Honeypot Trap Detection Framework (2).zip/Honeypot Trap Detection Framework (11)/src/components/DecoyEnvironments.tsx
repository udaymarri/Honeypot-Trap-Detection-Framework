import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Database, 
  FolderOpen, 
  Key, 
  Users, 
  DollarSign, 
  Server, 
  FileText,
  Lock,
  Eye,
  EyeOff,
  Copy,
  CheckCircle2,
  Terminal,
  Code,
  Wifi,
  HardDrive,
  Shield
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { toast } from 'sonner@2.0.3';

interface FileItem {
  name: string;
  type: 'file' | 'folder';
  size?: string;
  modified: string;
  sensitive?: boolean;
}

interface Credential {
  service: string;
  username: string;
  password: string;
  apiKey?: string;
  lastUsed: string;
  status: 'active' | 'inactive';
}

interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  role: string;
  ssn: string;
  salary: string;
}

export function DecoyEnvironments() {
  const [activeTab, setActiveTab] = useState('filesystem');
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Set<string>>(new Set());

  // Fake filesystem
  const fileSystem: FileItem[] = [
    { name: 'admin_passwords.txt', type: 'file', size: '2.4 KB', modified: '2 hours ago', sensitive: true },
    { name: 'database_backup.sql', type: 'file', size: '847 MB', modified: '1 day ago', sensitive: true },
    { name: 'api_keys.env', type: 'file', size: '1.8 KB', modified: '3 hours ago', sensitive: true },
    { name: 'employee_records/', type: 'folder', modified: '5 hours ago', sensitive: true },
    { name: 'financial_reports/', type: 'folder', modified: '1 day ago', sensitive: true },
    { name: 'ssh_private_keys/', type: 'folder', modified: '2 days ago', sensitive: true },
    { name: 'config.production.json', type: 'file', size: '4.2 KB', modified: '6 hours ago', sensitive: true },
    { name: 'customer_database.csv', type: 'file', size: '124 MB', modified: '8 hours ago', sensitive: true },
    { name: 'credit_cards.xlsx', type: 'file', size: '8.9 MB', modified: '12 hours ago', sensitive: true },
    { name: 'vpn_credentials.txt', type: 'file', size: '892 B', modified: '1 hour ago', sensitive: true },
    { name: 'admin_panel_access.md', type: 'file', size: '1.1 KB', modified: '4 hours ago', sensitive: true },
    { name: 'server_root_passwords.txt', type: 'file', size: '643 B', modified: '30 min ago', sensitive: true },
  ];

  // Fake credentials
  const credentials: Credential[] = [
    {
      service: 'AWS Production',
      username: 'admin@company.com',
      password: 'Pr0d@dm!n2024$',
      apiKey: 'AKIAIOSFODNN7EXAMPLE',
      lastUsed: '15 min ago',
      status: 'active',
    },
    {
      service: 'MySQL Database',
      username: 'root',
      password: 'MyS3cur3P@ssw0rd!',
      lastUsed: '2 hours ago',
      status: 'active',
    },
    {
      service: 'SSH Server',
      username: 'administrator',
      password: 'SSH_r00t_K3y_2024',
      lastUsed: '1 hour ago',
      status: 'active',
    },
    {
      service: 'Stripe API',
      username: 'api_user',
      password: 'sk_live_51HyperSecretKey789',
      apiKey: 'sk_live_51HyperSecretKey789ABC',
      lastUsed: '45 min ago',
      status: 'active',
    },
    {
      service: 'Admin Dashboard',
      username: 'superadmin',
      password: 'SuperAdm!n#2024',
      lastUsed: '3 hours ago',
      status: 'active',
    },
    {
      service: 'VPN Gateway',
      username: 'vpn_admin',
      password: 'VPN_Acc3ss_K3y!',
      lastUsed: '5 hours ago',
      status: 'active',
    },
  ];

  // Fake employee data
  const employees: Employee[] = [
    {
      id: 'EMP001',
      name: 'John Anderson',
      email: 'j.anderson@company.com',
      department: 'Engineering',
      role: 'Senior Developer',
      ssn: '123-45-6789',
      salary: '$142,000',
    },
    {
      id: 'EMP002',
      name: 'Sarah Mitchell',
      email: 's.mitchell@company.com',
      department: 'Finance',
      role: 'CFO',
      ssn: '234-56-7890',
      salary: '$285,000',
    },
    {
      id: 'EMP003',
      name: 'Michael Chen',
      email: 'm.chen@company.com',
      department: 'Security',
      role: 'CISO',
      ssn: '345-67-8901',
      salary: '$198,000',
    },
    {
      id: 'EMP004',
      name: 'Emily Rodriguez',
      email: 'e.rodriguez@company.com',
      department: 'Operations',
      role: 'VP Operations',
      ssn: '456-78-9012',
      salary: '$175,000',
    },
    {
      id: 'EMP005',
      name: 'David Kim',
      email: 'd.kim@company.com',
      department: 'Engineering',
      role: 'DevOps Lead',
      ssn: '567-89-0123',
      salary: '$156,000',
    },
  ];

  // Fake database tables
  const databaseTables = [
    { name: 'users', records: '48,392', size: '2.4 GB' },
    { name: 'transactions', records: '1,284,921', size: '8.7 GB' },
    { name: 'credit_cards', records: '12,847', size: '124 MB' },
    { name: 'admin_sessions', records: '3,421', size: '48 MB' },
    { name: 'api_tokens', records: '892', size: '12 MB' },
    { name: 'employee_data', records: '247', size: '8 MB' },
  ];

  // Fake server configs
  const serverConfigs = [
    {
      server: 'prod-db-01.internal',
      ip: '10.0.1.45',
      type: 'Database Server',
      credentials: 'root:MyS3cur3P@ssw0rd!',
      status: 'running',
    },
    {
      server: 'prod-web-01.internal',
      ip: '10.0.1.67',
      type: 'Web Server',
      credentials: 'admin:W3bS3rv3r@2024',
      status: 'running',
    },
    {
      server: 'prod-api-01.internal',
      ip: '10.0.1.89',
      type: 'API Gateway',
      credentials: 'apiuser:AP1_Acc3ss!',
      status: 'running',
    },
    {
      server: 'backup-server.internal',
      ip: '10.0.2.12',
      type: 'Backup Server',
      credentials: 'backup:B@ckup_Adm1n',
      status: 'running',
    },
  ];

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(label);
    toast.success(`Copied ${label}`, {
      description: 'Credentials copied to clipboard',
      duration: 2000,
    });
    setTimeout(() => setCopiedItem(null), 2000);
  };

  const togglePasswordVisibility = (service: string) => {
    setRevealedPasswords(prev => {
      const newSet = new Set(prev);
      if (newSet.has(service)) {
        newSet.delete(service);
      } else {
        newSet.add(service);
      }
      return newSet;
    });
  };

  return (
    <Card className="border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4 bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            <h3 className="font-mono">Decoy Data Environments</h3>
          </div>
          <Badge variant="outline" className="font-mono text-xs border-primary/50 text-primary">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse mr-2" />
            Active Deception Layer
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground font-mono mt-2">
          Fake environments to mislead and trap attackers
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b border-border bg-muted/10">
          <TabsList className="w-full justify-start h-auto p-0 bg-transparent rounded-none">
            <TabsTrigger 
              value="filesystem" 
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary font-mono text-xs"
            >
              <FolderOpen className="w-4 h-4 mr-2" />
              Filesystem
            </TabsTrigger>
            <TabsTrigger 
              value="credentials" 
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary font-mono text-xs"
            >
              <Key className="w-4 h-4 mr-2" />
              Credentials
            </TabsTrigger>
            <TabsTrigger 
              value="database" 
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary font-mono text-xs"
            >
              <Database className="w-4 h-4 mr-2" />
              Database
            </TabsTrigger>
            <TabsTrigger 
              value="employees" 
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary font-mono text-xs"
            >
              <Users className="w-4 h-4 mr-2" />
              Employees
            </TabsTrigger>
            <TabsTrigger 
              value="servers" 
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary font-mono text-xs"
            >
              <Server className="w-4 h-4 mr-2" />
              Servers
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="h-[500px]">
          {/* Filesystem Tab */}
          <TabsContent value="filesystem" className="p-4 m-0">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground font-mono mb-4 bg-muted/30 p-3 rounded border border-border/50">
                <Terminal className="w-4 h-4 text-primary" />
                <span className="text-primary">~/decoy/sensitive_files</span>
                <Badge variant="outline" className="ml-auto text-xs">
                  {fileSystem.length} items
                </Badge>
              </div>

              {fileSystem.map((file, index) => (
                <motion.div
                  key={file.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="flex items-center justify-between p-3 bg-muted/20 border border-border/50 rounded hover:border-primary/50 hover:bg-muted/40 transition-all group"
                >
                  <div className="flex items-center gap-3 flex-1">
                    {file.type === 'folder' ? (
                      <FolderOpen className="w-5 h-5 text-primary" />
                    ) : (
                      <FileText className="w-5 h-5 text-muted-foreground" />
                    )}
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-mono text-foreground">
                          {file.name}
                        </span>
                        {file.sensitive && (
                          <Lock className="w-3 h-3 text-destructive" />
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground font-mono mt-1">
                        {file.size && <span>{file.size}</span>}
                        <span>Modified {file.modified}</span>
                      </div>
                    </div>
                  </div>
                  {file.sensitive && (
                    <Badge variant="destructive" className="text-xs font-mono">
                      SENSITIVE
                    </Badge>
                  )}
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Credentials Tab */}
          <TabsContent value="credentials" className="p-4 m-0">
            <div className="space-y-3">
              {credentials.map((cred, index) => (
                <motion.div
                  key={cred.service}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border border-border/50 rounded-lg p-4 bg-muted/20 hover:border-primary/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                        <Key className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-mono text-sm text-foreground">{cred.service}</h4>
                        <p className="text-xs text-muted-foreground font-mono">
                          Last used {cred.lastUsed}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant={cred.status === 'active' ? 'default' : 'secondary'}
                      className="text-xs font-mono"
                    >
                      {cred.status}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between bg-background/50 p-2 rounded border border-border/30">
                      <div className="flex-1">
                        <span className="text-xs text-muted-foreground font-mono">Username</span>
                        <p className="text-sm font-mono text-foreground mt-0.5">{cred.username}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(cred.username, 'username')}
                        className="h-7 w-7 p-0"
                      >
                        {copiedItem === 'username' ? (
                          <CheckCircle2 className="w-3 h-3 text-primary" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between bg-background/50 p-2 rounded border border-border/30">
                      <div className="flex-1">
                        <span className="text-xs text-muted-foreground font-mono">Password</span>
                        <p className="text-sm font-mono text-foreground mt-0.5">
                          {revealedPasswords.has(cred.service) 
                            ? cred.password 
                            : '••••••••••••'}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => togglePasswordVisibility(cred.service)}
                          className="h-7 w-7 p-0"
                        >
                          {revealedPasswords.has(cred.service) ? (
                            <EyeOff className="w-3 h-3" />
                          ) : (
                            <Eye className="w-3 h-3" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(cred.password, 'password')}
                          className="h-7 w-7 p-0"
                        >
                          {copiedItem === 'password' ? (
                            <CheckCircle2 className="w-3 h-3 text-primary" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {cred.apiKey && (
                      <div className="flex items-center justify-between bg-background/50 p-2 rounded border border-border/30">
                        <div className="flex-1">
                          <span className="text-xs text-muted-foreground font-mono">API Key</span>
                          <p className="text-sm font-mono text-foreground mt-0.5 truncate">
                            {cred.apiKey}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopy(cred.apiKey!, 'API key')}
                          className="h-7 w-7 p-0"
                        >
                          {copiedItem === 'API key' ? (
                            <CheckCircle2 className="w-3 h-3 text-primary" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Database Tab */}
          <TabsContent value="database" className="p-4 m-0">
            <div className="space-y-3">
              <div className="bg-muted/30 p-3 rounded border border-border/50 mb-4">
                <div className="flex items-center gap-2 text-sm font-mono">
                  <Database className="w-4 h-4 text-primary" />
                  <span className="text-primary">production_db</span>
                  <span className="text-muted-foreground">@</span>
                  <span className="text-foreground">10.0.1.45:3306</span>
                </div>
              </div>

              {databaseTables.map((table, index) => (
                <motion.div
                  key={table.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.04 }}
                  className="flex items-center justify-between p-3 bg-muted/20 border border-border/50 rounded hover:border-primary/50 hover:bg-muted/40 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                      <HardDrive className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-mono text-sm text-foreground">{table.name}</h4>
                      <p className="text-xs text-muted-foreground font-mono">
                        {table.records} records
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className="font-mono text-xs">
                    {table.size}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Employees Tab */}
          <TabsContent value="employees" className="p-4 m-0">
            <div className="space-y-3">
              {employees.map((emp, index) => (
                <motion.div
                  key={emp.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border border-border/50 rounded-lg p-4 bg-muted/20 hover:border-primary/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Users className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-mono text-sm text-foreground">{emp.name}</h4>
                        <p className="text-xs text-muted-foreground font-mono">{emp.email}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="font-mono text-xs">
                      {emp.id}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-background/50 p-2 rounded border border-border/30">
                      <span className="text-xs text-muted-foreground font-mono">Department</span>
                      <p className="text-sm font-mono text-foreground mt-0.5">{emp.department}</p>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/30">
                      <span className="text-xs text-muted-foreground font-mono">Role</span>
                      <p className="text-sm font-mono text-foreground mt-0.5">{emp.role}</p>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/30">
                      <span className="text-xs text-muted-foreground font-mono">SSN</span>
                      <p className="text-sm font-mono text-destructive mt-0.5">{emp.ssn}</p>
                    </div>
                    <div className="bg-background/50 p-2 rounded border border-border/30">
                      <span className="text-xs text-muted-foreground font-mono">Salary</span>
                      <p className="text-sm font-mono text-primary mt-0.5">{emp.salary}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Servers Tab */}
          <TabsContent value="servers" className="p-4 m-0">
            <div className="space-y-3">
              {serverConfigs.map((server, index) => (
                <motion.div
                  key={server.server}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border border-border/50 rounded-lg p-4 bg-muted/20 hover:border-primary/50 transition-all"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-primary/10 flex items-center justify-center">
                        <Server className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-mono text-sm text-foreground">{server.server}</h4>
                        <p className="text-xs text-muted-foreground font-mono">{server.type}</p>
                      </div>
                    </div>
                    <Badge 
                      variant="default"
                      className="text-xs font-mono bg-primary/20 text-primary border border-primary/50"
                    >
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse mr-1" />
                      {server.status}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between bg-background/50 p-2 rounded border border-border/30">
                      <div className="flex-1">
                        <span className="text-xs text-muted-foreground font-mono">IP Address</span>
                        <p className="text-sm font-mono text-foreground mt-0.5">{server.ip}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(server.ip, 'IP address')}
                        className="h-7 w-7 p-0"
                      >
                        {copiedItem === 'IP address' ? (
                          <CheckCircle2 className="w-3 h-3 text-primary" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                    </div>

                    <div className="flex items-center justify-between bg-background/50 p-2 rounded border border-border/30">
                      <div className="flex-1">
                        <span className="text-xs text-muted-foreground font-mono">Credentials</span>
                        <p className="text-sm font-mono text-destructive mt-0.5">
                          {server.credentials}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCopy(server.credentials, 'credentials')}
                        className="h-7 w-7 p-0"
                      >
                        {copiedItem === 'credentials' ? (
                          <CheckCircle2 className="w-3 h-3 text-primary" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </Card>
  );
}
