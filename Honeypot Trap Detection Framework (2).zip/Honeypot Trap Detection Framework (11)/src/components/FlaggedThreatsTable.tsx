import { motion } from 'motion/react';
import { Flag, X, MapPin, Clock, Server, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { ScrollArea } from './ui/scroll-area';

interface FlaggedThreat {
  id: string;
  ip: string;
  country: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  attackType: string;
  protocol: string;
  timestamp: string;
  attempts: number;
}

interface FlaggedThreatsTableProps {
  threats: FlaggedThreat[];
  onUnflag: (id: string) => void;
  onViewDetails: (threat: FlaggedThreat) => void;
}

const severityColors = {
  critical: '#ff0055',
  high: '#ff6b00',
  medium: '#ffbb00',
  low: '#00ff88',
};

export function FlaggedThreatsTable({ threats, onUnflag, onViewDetails }: FlaggedThreatsTableProps) {
  if (threats.length === 0) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-lg overflow-hidden mb-6"
    >
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flag className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Flagged Threats</h3>
          <Badge variant="outline" className="border-primary/50 text-primary font-mono">
            {threats.length} Active
          </Badge>
        </div>
      </div>

      {/* Table */}
      <ScrollArea className="h-[300px]">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent border-border">
              <TableHead className="font-mono text-xs">Severity</TableHead>
              <TableHead className="font-mono text-xs">IP Address</TableHead>
              <TableHead className="font-mono text-xs">Origin</TableHead>
              <TableHead className="font-mono text-xs">Attack Type</TableHead>
              <TableHead className="font-mono text-xs">Protocol</TableHead>
              <TableHead className="font-mono text-xs">Attempts</TableHead>
              <TableHead className="font-mono text-xs">First Seen</TableHead>
              <TableHead className="font-mono text-xs text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {threats.map((threat, index) => (
              <motion.tr
                key={threat.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="border-border hover:bg-muted/30 transition-colors cursor-pointer group"
                onClick={() => onViewDetails(threat)}
              >
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: severityColors[threat.severity] }}
                    />
                    <Badge
                      variant="outline"
                      style={{
                        borderColor: severityColors[threat.severity],
                        color: severityColors[threat.severity],
                      }}
                      className="uppercase text-xs font-mono"
                    >
                      {threat.severity}
                    </Badge>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Server className="w-3 h-3 text-muted-foreground" />
                    <span className="font-mono text-sm">{threat.ip}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3 h-3 text-muted-foreground" />
                    <span className="font-mono text-sm">{threat.country}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-3 h-3 text-primary" />
                    <span className="font-mono text-sm">{threat.attackType}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="border-primary/30 font-mono text-xs">
                    {threat.protocol}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span
                    className="font-mono text-sm"
                    style={{ color: severityColors[threat.severity] }}
                  >
                    {threat.attempts}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3 h-3 text-muted-foreground" />
                    <span className="font-mono text-sm text-muted-foreground">
                      {threat.timestamp}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUnflag(threat.id);
                    }}
                    className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </ScrollArea>
    </motion.div>
  );
}
