import { motion } from 'motion/react';

export function HolographicBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Holographic grid base */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0, 255, 255, 0.08) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 255, 0.08) 1px, transparent 1px),
            linear-gradient(rgba(123, 44, 191, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(123, 44, 191, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px, 80px 80px, 20px 20px, 20px 20px',
          backgroundPosition: '0 0, 0 0, 0 0, 0 0',
        }}
      />

      {/* Scanning radar effect */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="absolute"
          style={{
            width: '1px',
            height: '800px',
            background: 'linear-gradient(180deg, transparent, rgba(0, 255, 255, 0.6), transparent)',
            transformOrigin: 'center',
          }}
          animate={{
            rotate: 360,
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'linear',
          }}
        >
          <div className="absolute top-1/2 left-0 w-full h-px bg-primary shadow-[0_0_20px_rgba(0,255,255,0.8)]" />
        </motion.div>
      </div>

      {/* Holographic data cubes */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute border border-primary/20"
          style={{
            width: `${Math.random() * 40 + 30}px`,
            height: `${Math.random() * 40 + 30}px`,
            left: `${Math.random() * 90}%`,
            top: `${Math.random() * 90}%`,
            transform: 'rotateX(45deg) rotateZ(45deg)',
            transformStyle: 'preserve-3d',
          }}
          animate={{
            rotateX: [45, 225, 45],
            rotateZ: [45, 405, 45],
            opacity: [0.2, 0.6, 0.2],
          }}
          transition={{
            duration: Math.random() * 8 + 10,
            repeat: Infinity,
            delay: Math.random() * 3,
            ease: 'linear',
          }}
        />
      ))}

      {/* Floating digital panels */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={`panel-${i}`}
          className="absolute bg-gradient-to-br from-primary/10 to-secondary/10 backdrop-blur-sm"
          style={{
            width: `${Math.random() * 150 + 100}px`,
            height: `${Math.random() * 80 + 60}px`,
            left: `${Math.random() * 80}%`,
            top: `${Math.random() * 80}%`,
            border: '1px solid rgba(0, 255, 255, 0.15)',
            borderRadius: '4px',
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 0.7, 0.3],
          }}
          transition={{
            duration: Math.random() * 5 + 6,
            repeat: Infinity,
            delay: Math.random() * 2,
            ease: 'easeInOut',
          }}
        >
          {/* Panel scanlines */}
          <div className="absolute inset-0 opacity-40" style={{
            backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 255, 0.1) 2px, rgba(0, 255, 255, 0.1) 4px)',
          }} />
        </motion.div>
      ))}

      {/* Energy waves */}
      {[...Array(4)].map((_, i) => (
        <motion.div
          key={`wave-${i}`}
          className="absolute inset-0 border-2 rounded-full"
          style={{
            borderColor: i % 2 === 0 ? 'rgba(0, 255, 255, 0.2)' : 'rgba(123, 44, 191, 0.2)',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
          animate={{
            width: ['0px', '1200px'],
            height: ['0px', '1200px'],
            opacity: [0.6, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            delay: i * 1.5,
            ease: 'easeOut',
          }}
        />
      ))}

      {/* Digital rain - different style */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={`rain-${i}`}
            className="absolute w-px"
            style={{
              left: `${(i * 5)}%`,
              height: `${Math.random() * 100 + 50}px`,
              background: `linear-gradient(180deg, transparent, ${
                i % 3 === 0 ? 'rgba(0, 255, 255, 0.6)' : 
                i % 3 === 1 ? 'rgba(123, 44, 191, 0.6)' : 
                'rgba(107, 70, 255, 0.6)'
              }, transparent)`,
            }}
            animate={{
              y: ['-100%', '200vh'],
              opacity: [0, 1, 1, 0],
            }}
            transition={{
              duration: Math.random() * 3 + 4,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      {/* Glowing orbs with different positioning */}
      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full"
        style={{
          top: '30%',
          left: '5%',
          background: 'radial-gradient(circle, rgba(0, 255, 255, 0.1) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
        animate={{
          x: [0, 100, 0],
          y: [0, -80, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 16,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <motion.div
        className="absolute w-[500px] h-[500px] rounded-full"
        style={{
          bottom: '20%',
          right: '10%',
          background: 'radial-gradient(circle, rgba(107, 70, 255, 0.12) 0%, transparent 70%)',
          filter: 'blur(70px)',
        }}
        animate={{
          x: [0, -80, 0],
          y: [0, 60, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 14,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Intersecting laser beams */}
      <svg className="absolute inset-0 w-full h-full opacity-15">
        <defs>
          <linearGradient id="laser-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(0, 255, 255, 0)" />
            <stop offset="50%" stopColor="rgba(0, 255, 255, 1)" />
            <stop offset="100%" stopColor="rgba(0, 255, 255, 0)" />
          </linearGradient>
        </defs>
        
        {[...Array(8)].map((_, i) => (
          <motion.line
            key={i}
            x1={i % 2 === 0 ? "0%" : "100%"}
            y1={`${i * 12.5}%`}
            x2={i % 2 === 0 ? "100%" : "0%"}
            y2={`${i * 12.5}%`}
            stroke="url(#laser-gradient)"
            strokeWidth="1"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: [0, 1, 0] }}
            transition={{
              duration: 4,
              repeat: Infinity,
              delay: i * 0.5,
              ease: 'linear',
            }}
          />
        ))}
      </svg>

      {/* Particle constellation */}
      <div className="absolute inset-0">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={`star-${i}`}
            className="absolute rounded-full"
            style={{
              width: `${Math.random() * 3 + 1}px`,
              height: `${Math.random() * 3 + 1}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              backgroundColor: i % 3 === 0 ? '#00ffff' : i % 3 === 1 ? '#7b2cbf' : '#6b46ff',
              boxShadow: `0 0 ${Math.random() * 8 + 4}px ${
                i % 3 === 0 ? '#00ffff' : i % 3 === 1 ? '#7b2cbf' : '#6b46ff'
              }`,
            }}
            animate={{
              opacity: [0.2, 1, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: Math.random() * 3 + 2,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          />
        ))}
      </div>

      {/* Gradient overlay for content readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/30 to-background/90" />
    </div>
  );
}
