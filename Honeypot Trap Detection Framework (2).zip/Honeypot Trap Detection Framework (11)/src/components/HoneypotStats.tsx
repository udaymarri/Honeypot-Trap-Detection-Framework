import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Shield, Users, AlertTriangle, Database, Lock } from 'lucide-react';
import { MockBackendAPI } from '../services/mockBackend';

interface HoneypotStatsData {
  totalAccounts: number;
  honeypotAccounts: number;
  realAccounts: number;
  honeypotTypes: {
    admin: number;
    developer: number;
    service: number;
    weakPassword: number;
  };
}

export function HoneypotStats() {
  const [stats, setStats] = useState<HoneypotStatsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const result = await MockBackendAPI.getHoneypotStats();
    if (result.success) {
      setStats(result.stats);
    }
    setLoading(false);
  };

  if (loading || !stats) {
    return (
      <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Honeypot Database Status</h3>
        </div>
        <p className="text-sm text-muted-foreground font-mono">Loading...</p>
      </div>
    );
  }

  const honeypotPercentage = Math.round((stats.honeypotAccounts / stats.totalAccounts) * 100);

  return (
    <div className="bg-card/50 backdrop-blur-sm border border-border rounded-lg p-6 relative overflow-hidden group hover:border-primary/50 transition-all">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg border border-primary/30">
              <Database className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-mono">Honeypot Database</h3>
              <p className="text-xs text-muted-foreground font-mono">MongoDB Status</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs text-primary font-mono">ACTIVE</span>
          </div>
        </div>

        {/* Main Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <motion.div
            className="bg-muted/30 rounded-lg p-3 border border-border"
            whileHover={{ scale: 1.05, borderColor: 'rgba(0,255,255,0.5)' }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Users className="w-4 h-4 text-primary" />
              <p className="text-xs text-muted-foreground font-mono">Total</p>
            </div>
            <p className="text-2xl font-mono text-foreground">{stats.totalAccounts}</p>
          </motion.div>

          <motion.div
            className="bg-muted/30 rounded-lg p-3 border border-border"
            whileHover={{ scale: 1.05, borderColor: 'rgba(255,0,85,0.5)' }}
          >
            <div className="flex items-center gap-2 mb-1">
              <AlertTriangle className="w-4 h-4 text-destructive" />
              <p className="text-xs text-muted-foreground font-mono">Honeypots</p>
            </div>
            <p className="text-2xl font-mono text-destructive">{stats.honeypotAccounts}</p>
          </motion.div>

          <motion.div
            className="bg-muted/30 rounded-lg p-3 border border-border"
            whileHover={{ scale: 1.05, borderColor: 'rgba(0,255,136,0.5)' }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Lock className="w-4 h-4 text-chart-5" />
              <p className="text-xs text-muted-foreground font-mono">Real</p>
            </div>
            <p className="text-2xl font-mono text-chart-5">{stats.realAccounts}</p>
          </motion.div>
        </div>

        {/* Honeypot Percentage Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-muted-foreground font-mono">Deception Rate</p>
            <p className="text-xs text-primary font-mono">{honeypotPercentage}%</p>
          </div>
          <div className="h-2 bg-muted/30 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-secondary"
              initial={{ width: 0 }}
              animate={{ width: `${honeypotPercentage}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
            />
          </div>
        </div>

        {/* Honeypot Types Breakdown */}
        <div>
          <p className="text-xs text-muted-foreground font-mono mb-3">Honeypot Categories</p>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-destructive" />
                <span className="text-xs font-mono text-foreground">Admin Accounts</span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">{stats.honeypotTypes.admin}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-chart-4" />
                <span className="text-xs font-mono text-foreground">Developer Accounts</span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">{stats.honeypotTypes.developer}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-secondary" />
                <span className="text-xs font-mono text-foreground">Service Accounts</span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">{stats.honeypotTypes.service}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-xs font-mono text-foreground">Weak Password Traps</span>
              </div>
              <span className="text-xs font-mono text-muted-foreground">{stats.honeypotTypes.weakPassword}</span>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="mt-6 bg-primary/10 border border-primary/30 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <Shield className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-mono text-primary mb-1">🍯 Honeypot Protection Active</p>
              <p className="text-xs font-mono text-muted-foreground">
                Fake accounts deployed to detect and track unauthorized access attempts. 
                All honeypot logins are logged and analyzed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
