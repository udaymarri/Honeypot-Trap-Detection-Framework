import { motion } from 'motion/react';
import { Server, Wifi, CheckCircle2, XCircle } from 'lucide-react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface Honeypot {
  id: string;
  name: string;
  type: string;
  status: 'active' | 'inactive';
  port: number;
  attacks: number;
  uptime: string;
}

const honeypots: Honeypot[] = [
  { id: '1', name: 'SSH Honeypot Alpha', type: 'SSH', status: 'active', port: 22, attacks: 847, uptime: '99.8%' },
  { id: '2', name: 'HTTP Honeypot Beta', type: 'HTTP', status: 'active', port: 80, attacks: 1523, uptime: '100%' },
  { id: '3', name: 'FTP Honeypot Gamma', type: 'FTP', status: 'active', port: 21, attacks: 456, uptime: '98.2%' },
  { id: '4', name: 'SMTP Honeypot Delta', type: 'SMTP', status: 'active', port: 25, attacks: 234, uptime: '99.1%' },
  { id: '5', name: 'MySQL Honeypot Epsilon', type: 'MySQL', status: 'active', port: 3306, attacks: 189, uptime: '97.5%' },
  { id: '6', name: 'Telnet Honeypot Zeta', type: 'Telnet', status: 'inactive', port: 23, attacks: 0, uptime: '0%' },
];

function getProtocolColor(type: string) {
  const colors: Record<string, string> = {
    SSH: '#00ffff',
    HTTP: '#7b2cbf',
    FTP: '#ff0055',
    SMTP: '#00ff88',
    MySQL: '#6b46ff',
    Telnet: '#9090b0',
  };
  return colors[type] || '#00ffff';
}

export function HoneypotStatus() {
  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Server className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Honeypot Network Status</h3>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <CheckCircle2 className="w-4 h-4 text-[#00ff88]" />
          <span className="text-muted-foreground font-mono">
            {honeypots.filter(h => h.status === 'active').length}/{honeypots.length} Active
          </span>
        </div>
      </div>

      {/* Honeypot list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {honeypots.map((honeypot, index) => (
          <motion.div
            key={honeypot.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative bg-muted/30 border border-border/50 rounded-lg p-4 overflow-hidden group hover:border-primary/50 transition-colors"
          >
            {/* Status indicator bar */}
            <div 
              className="absolute left-0 top-0 bottom-0 w-1"
              style={{ 
                backgroundColor: honeypot.status === 'active' ? '#00ff88' : '#9090b0',
              }}
            />

            <div className="ml-3">
              {/* Header */}
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-mono mb-1">{honeypot.name}</h4>
                  <div className="flex items-center gap-2">
                    <Badge 
                      variant="outline" 
                      className="border-primary/50 text-xs font-mono"
                      style={{ 
                        borderColor: getProtocolColor(honeypot.type),
                        color: getProtocolColor(honeypot.type),
                      }}
                    >
                      {honeypot.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground font-mono">
                      Port {honeypot.port}
                    </span>
                  </div>
                </div>
                
                {honeypot.status === 'active' ? (
                  <div className="flex items-center gap-2 text-[#00ff88]">
                    <Wifi className="w-4 h-4" />
                    <span className="text-xs uppercase tracking-wider font-mono">Active</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <XCircle className="w-4 h-4" />
                    <span className="text-xs uppercase tracking-wider font-mono">Offline</span>
                  </div>
                )}
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-2">
                <div>
                  <div className="text-xs text-muted-foreground mb-1 font-mono">Attacks Captured</div>
                  <div 
                    className="text-xl font-mono"
                    style={{ color: getProtocolColor(honeypot.type) }}
                  >
                    {honeypot.attacks.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1 font-mono">Uptime</div>
                  <div className="text-xl font-mono text-foreground">{honeypot.uptime}</div>
                </div>
              </div>

              {/* Uptime progress */}
              {honeypot.status === 'active' && (
                <div className="mt-3">
                  <Progress 
                    value={parseFloat(honeypot.uptime)} 
                    className="h-1.5"
                  />
                </div>
              )}
            </div>

            {/* Hover glow */}
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none"
              style={{
                background: `radial-gradient(circle at center, ${getProtocolColor(honeypot.type)}, transparent 70%)`
              }}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
}
