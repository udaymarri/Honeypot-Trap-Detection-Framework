import { motion } from 'motion/react';
import { Shield, Lock, Eye, Activity, Zap, AlertTriangle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { MatrixBackground } from './MatrixBackground';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  const features = [
    {
      icon: Shield,
      title: 'Advanced Honeypot Deployment',
      description: 'Deploy multi-protocol honeypots (SSH, HTTP, FTP) to trap attackers',
    },
    {
      icon: Eye,
      title: 'Real-time Monitoring',
      description: 'Track attacker behavior with live threat feeds and analytics',
    },
    {
      icon: Activity,
      title: '3D Threat Visualization',
      description: 'Interactive network maps with geographic attack tracking',
    },
    {
      icon: Zap,
      title: 'Instant Threat Intelligence',
      description: 'Automated analysis and classification of attack patterns',
    },
    {
      icon: Lock,
      title: 'Decoy Environments',
      description: 'Fake data systems to mislead and trap sophisticated attackers',
    },
    {
      icon: AlertTriangle,
      title: 'Smart Alert System',
      description: 'Intelligent notifications with severity-based filtering',
    },
  ];

  const stats = [
    { value: '99.8%', label: 'Detection Rate' },
    { value: '50K+', label: 'Threats Blocked' },
    { value: '<1ms', label: 'Response Time' },
    { value: '24/7', label: 'Active Protection' },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      {/* Matrix background */}
      <MatrixBackground />

      {/* Hero Section */}
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="border-b border-border bg-card/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div
                  className="relative"
                  animate={{ 
                    rotate: [0, 360],
                  }}
                  transition={{ 
                    duration: 20, 
                    repeat: Infinity, 
                    ease: 'linear' 
                  }}
                >
                  <Shield className="w-8 h-8 text-primary" />
                  <div className="absolute inset-0 blur-lg bg-primary opacity-50" />
                </motion.div>
                <div>
                  <h1 className="font-mono">
                    <span className="text-primary">HONEYPOT</span>
                    <span className="text-muted-foreground"> // </span>
                    <span>DEFENSE</span>
                  </h1>
                </div>
              </div>

              <Button
                onClick={onGetStarted}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-mono"
              >
                Access System
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        </nav>

        {/* Hero Content */}
        <section className="max-w-7xl mx-auto px-6 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Column */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/30 mb-6">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <span className="text-xs font-mono text-primary">NEXT-GEN CYBER DEFENSE</span>
              </div>

              <h2 className="text-5xl mb-6">
                <span className="text-foreground">Trap Attackers</span>
                <br />
                <span className="text-primary">Before They Strike</span>
              </h2>

              <p className="text-lg text-muted-foreground font-mono mb-8">
                Advanced honeypot trap detection framework with real-time threat intelligence, 
                3D attack visualization, and intelligent decoy environments. Deception is the new defense.
              </p>

              <div className="flex flex-wrap gap-4 mb-12">
                <Button
                  onClick={onGetStarted}
                  size="lg"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-mono group"
                >
                  Get Started
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-primary/30 hover:border-primary hover:bg-primary/10 font-mono"
                >
                  View Demo
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-4 gap-4">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="text-center"
                  >
                    <div className="text-2xl text-primary font-mono mb-1">{stat.value}</div>
                    <div className="text-xs text-muted-foreground font-mono">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Right Column - Animated Dashboard Preview */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="relative bg-card/50 backdrop-blur-sm border border-border rounded-xl p-6 shadow-2xl">
                {/* Fake Dashboard Preview */}
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-center justify-between pb-3 border-b border-border">
                    <div className="flex items-center gap-2">
                      <Activity className="w-4 h-4 text-primary" />
                      <span className="text-sm font-mono">Live Threat Monitor</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <span className="text-xs font-mono text-muted-foreground">ACTIVE</span>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'Attacks Blocked', value: '3,482', trend: '+24%' },
                      { label: 'Active Honeypots', value: '12', trend: '+2' },
                      { label: 'Threat Sources', value: '847', trend: '+15%' },
                      { label: 'Response Time', value: '0.8ms', trend: '-12%' },
                    ].map((stat, i) => (
                      <motion.div
                        key={stat.label}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.8 + i * 0.1 }}
                        className="bg-muted/30 border border-border/50 rounded-lg p-3"
                      >
                        <div className="text-xs text-muted-foreground font-mono mb-1">{stat.label}</div>
                        <div className="flex items-baseline justify-between">
                          <div className="text-xl font-mono text-foreground">{stat.value}</div>
                          <div className="text-xs font-mono text-primary">{stat.trend}</div>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Threat Activity */}
                  <div className="space-y-2">
                    <div className="text-xs font-mono text-muted-foreground mb-2">Recent Threats</div>
                    {[
                      { ip: '203.45.67.89', country: 'Russia', severity: 'critical' },
                      { ip: '118.23.45.67', country: 'China', severity: 'high' },
                      { ip: '87.156.23.45', country: 'Iran', severity: 'medium' },
                    ].map((threat, i) => (
                      <motion.div
                        key={threat.ip}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.2 + i * 0.1 }}
                        className="flex items-center justify-between p-2 bg-muted/20 border border-border/30 rounded"
                      >
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${
                            threat.severity === 'critical' ? 'bg-destructive' :
                            threat.severity === 'high' ? 'bg-orange-500' : 'bg-yellow-500'
                          } animate-pulse`} />
                          <span className="text-xs font-mono">{threat.ip}</span>
                        </div>
                        <span className="text-xs font-mono text-muted-foreground">{threat.country}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Glow effect */}
                <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 rounded-xl blur-xl -z-10 opacity-50" />
              </div>
            </motion.div>
          </div>
        </section>

        {/* Lower Half - Auth-Style Background */}
        <div className="relative">
          {/* Backdrop overlay similar to AuthPage */}
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md" />
          
          {/* Floating particles - Auth-style flowing dots */}
          <div className="absolute inset-0 pointer-events-none z-5 overflow-hidden">
            {[...Array(30)].map((_, i) => {
              const randomX = Math.random() * 100;
              const randomY = Math.random() * 100;
              const randomDelay = Math.random() * 3;
              const randomDuration = 3 + Math.random() * 4;
              const randomSize = 2 + Math.random() * 6;
              
              return (
                <motion.div
                  key={i}
                  className="absolute rounded-full bg-primary/30"
                  style={{
                    left: `${randomX}%`,
                    top: `${randomY}%`,
                    width: `${randomSize}px`,
                    height: `${randomSize}px`,
                  }}
                  animate={{
                    y: [0, -30, 0],
                    x: [0, Math.sin(i) * 20, 0],
                    opacity: [0.1, 0.6, 0.1],
                    scale: [1, 1.5, 1],
                  }}
                  transition={{
                    duration: randomDuration,
                    repeat: Infinity,
                    delay: randomDelay,
                    ease: 'easeInOut',
                  }}
                />
              );
            })}
            
            {/* Larger accent particles */}
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={`accent-${i}`}
                className="absolute rounded-full"
                style={{
                  left: `${10 + (i * 8)}%`,
                  top: `${20 + Math.sin(i) * 30}%`,
                  width: '4px',
                  height: '4px',
                  background: i % 2 === 0 ? 'rgba(0, 255, 255, 0.4)' : 'rgba(123, 44, 191, 0.4)',
                }}
                animate={{
                  y: [0, -40, 0],
                  opacity: [0.2, 0.8, 0.2],
                  scale: [1, 2, 1],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  delay: i * 0.3,
                  ease: 'easeInOut',
                }}
              />
            ))}
          </div>
          
          {/* Features Section */}
          <section className="max-w-7xl mx-auto px-6 py-20 relative z-10">
            <motion.div 
              className="text-center mb-12"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h3 className="text-3xl mb-4">
                <span className="text-foreground">Comprehensive</span>{' '}
                <span className="text-primary">Cyber Defense</span>
              </h3>
              <p className="text-muted-foreground font-mono max-w-2xl mx-auto">
                Deploy sophisticated honeypots, analyze attacker behavior, and protect your infrastructure 
                with cutting-edge deception technology
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, scale: 0.9, y: 30 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: index * 0.1,
                  type: 'spring',
                  stiffness: 200,
                  damping: 20
                }}
                whileHover={{ 
                  scale: 1.05,
                  y: -10,
                  transition: { duration: 0.3 }
                }}
                className="relative bg-card/70 backdrop-blur-sm border border-border rounded-lg p-6 hover:border-primary/50 transition-all group"
                style={{ 
                  transformStyle: 'preserve-3d',
                  perspective: '1000px'
                }}
              >
                {/* Glow layers similar to AuthPage */}
                <div className="absolute -inset-2 bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 rounded-lg blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute -inset-1 bg-primary/5 rounded-lg blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h4 className="mb-2 font-mono">{feature.title}</h4>
                <p className="text-sm text-muted-foreground font-mono">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

          {/* CTA Section */}
          <section className="max-w-7xl mx-auto px-6 py-20 relative z-10">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                type: 'spring',
                stiffness: 200,
                damping: 20
              }}
              whileHover={{ 
                scale: 1.02,
                y: -5,
                transition: { duration: 0.3 }
              }}
              className="relative bg-card/70 backdrop-blur-sm border border-primary/30 rounded-xl p-12 text-center overflow-hidden"
              style={{ 
                transformStyle: 'preserve-3d',
                perspective: '1000px'
              }}
            >
              {/* Enhanced glow layers */}
              <div className="absolute -inset-4 bg-gradient-to-r from-primary/20 via-secondary/20 to-primary/20 rounded-2xl blur-3xl opacity-40" />
              <div className="absolute -inset-2 bg-primary/10 rounded-2xl blur-2xl opacity-60" />
              {/* Content */}
              <div className="relative z-10">
                <h3 className="text-3xl mb-4">
                  <span className="text-foreground">Ready to Deploy</span>{' '}
                  <span className="text-primary">Advanced Deception?</span>
                </h3>
                <p className="text-muted-foreground font-mono mb-8 max-w-2xl mx-auto">
                  Join security teams worldwide using honeypot technology to catch attackers 
                  before they compromise your systems
                </p>

                {/* Features checklist */}
                <div className="flex flex-wrap justify-center gap-6 mb-8">
                  {['24/7 Monitoring', 'Instant Alerts', 'Zero False Positives', 'Easy Setup'].map((item, idx) => (
                    <motion.div 
                      key={item} 
                      className="flex items-center gap-2"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1 }}
                    >
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                      <span className="text-sm font-mono text-foreground">{item}</span>
                    </motion.div>
                  ))}
                </div>

                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    onClick={onGetStarted}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg group shadow-[0_0_30px_rgba(0,255,255,0.3)]"
                  >
                    <span>Start Free Trial</span>
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </motion.div>
              </div>
            </motion.div>
          </section>

          {/* Footer */}
          <footer className="border-t border-border bg-card/70 backdrop-blur-sm relative z-10">
            <div className="max-w-7xl mx-auto px-6 py-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="text-xs text-muted-foreground font-mono">
                  <span className="text-primary">HONEYPOT TRAP DETECTION FRAMEWORK</span>
                  <span className="mx-2">//</span>
                  <span>v2.4.1</span>
                  <span className="mx-2">|</span>
                  <span>© 2025 Cyber Defense Systems</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
                  <span>Deception is the new defense.</span>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>

      {/* Scanline effect */}
      <motion.div
        className="absolute inset-0 pointer-events-none z-5 opacity-10"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 255, 0.5) 2px, rgba(0, 255, 255, 0.5) 4px)',
        }}
        animate={{ y: [0, 20] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
      />
    </div>
  );
}
