import { motion, AnimatePresence } from 'motion/react';
import { X, AlertTriangle, Shield, Info, CheckCircle2, Clock, Trash2, Star } from 'lucide-react';
import { Button } from './ui/button';
import { ScrollArea, ScrollBar } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { useState } from 'react';

interface Notification {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  starred: boolean;
}

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'critical',
    title: 'Critical Threat Detected',
    message: 'Brute force attack from 185.220.101.42 - 127 failed attempts',
    timestamp: '2 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '2',
    type: 'critical',
    title: 'SQL Injection Attempt',
    message: 'Malicious SQL query blocked on /admin endpoint',
    timestamp: '8 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '3',
    type: 'warning',
    title: 'Port Scan Detected',
    message: 'Unusual port scanning activity from 103.75.189.34',
    timestamp: '15 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '4',
    type: 'critical',
    title: 'XSS Attack Prevented',
    message: 'Cross-site scripting attempt blocked in web honeypot form submission',
    timestamp: '22 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '5',
    type: 'high',
    title: 'Malware Upload Blocked',
    message: 'Suspicious executable file upload prevented from 91.203.5.165',
    timestamp: '35 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '6',
    type: 'warning',
    title: 'SSH Tunnel Attempt',
    message: 'Unauthorized SSH tunneling detected from China-based IP',
    timestamp: '47 minutes ago',
    read: false,
    starred: false,
  },
  {
    id: '7',
    type: 'success',
    title: 'Honeypot Deployed',
    message: 'New SSH honeypot successfully activated on port 2222',
    timestamp: '1 hour ago',
    read: true,
    starred: false,
  },
  {
    id: '8',
    type: 'critical',
    title: 'Ransomware Signature Detected',
    message: 'Known ransomware behavior pattern identified and blocked',
    timestamp: '1 hour ago',
    read: true,
    starred: false,
  },
  {
    id: '9',
    type: 'info',
    title: 'System Update',
    message: 'Threat database updated with 247 new signatures',
    timestamp: '2 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '10',
    type: 'warning',
    title: 'DDoS Probe',
    message: 'Potential DDoS reconnaissance detected from multiple IPs',
    timestamp: '3 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '11',
    type: 'critical',
    title: 'Command Injection Blocked',
    message: 'Shell execution attempt prevented in FTP honeypot',
    timestamp: '4 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '12',
    type: 'warning',
    title: 'Credential Stuffing Attack',
    message: 'Multiple login attempts with leaked credential database detected',
    timestamp: '5 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '13',
    type: 'info',
    title: 'Honeypot Maintenance',
    message: 'Routine maintenance completed on MySQL honeypot cluster',
    timestamp: '6 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '14',
    type: 'success',
    title: 'Threat Intelligence Update',
    message: 'Successfully integrated 1,247 new IoCs from global threat feeds',
    timestamp: '8 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '15',
    type: 'critical',
    title: 'Zero-Day Exploit Attempt',
    message: 'Potential zero-day vulnerability exploitation detected and contained',
    timestamp: '10 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '16',
    type: 'warning',
    title: 'Botnet Activity Detected',
    message: 'Coordinated attack from known Mirai botnet nodes identified',
    timestamp: '12 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '17',
    type: 'info',
    title: 'Security Audit Completed',
    message: 'Monthly security audit passed with 98.8% compliance score',
    timestamp: '18 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '18',
    type: 'success',
    title: 'API Rate Limiting Active',
    message: 'Successfully blocked 2,341 API abuse attempts in the last 24 hours',
    timestamp: '20 hours ago',
    read: true,
    starred: false,
  },
  {
    id: '19',
    type: 'info',
    title: 'Weekly Report Ready',
    message: 'Attack summary report for last 7 days is available for download',
    timestamp: '1 day ago',
    read: true,
    starred: false,
  },
  {
    id: '20',
    type: 'warning',
    title: 'Suspicious DNS Queries',
    message: 'Abnormal DNS query patterns detected from internal network segment',
    timestamp: '1 day ago',
    read: true,
    starred: false,
  },
];

function getNotificationIcon(type: string) {
  switch (type) {
    case 'critical':
      return <AlertTriangle className="w-5 h-5" />;
    case 'warning':
      return <Shield className="w-5 h-5" />;
    case 'success':
      return <CheckCircle2 className="w-5 h-5" />;
    case 'info':
      return <Info className="w-5 h-5" />;
    default:
      return <Info className="w-5 h-5" />;
  }
}

function getNotificationColor(type: string) {
  switch (type) {
    case 'critical':
      return '#ff0055';
    case 'warning':
      return '#ffbb00';
    case 'success':
      return '#00ff88';
    case 'info':
      return '#00ffff';
    default:
      return '#00ffff';
  }
}

export function NotificationPanel({ isOpen, onClose }: NotificationPanelProps) {
  const [notifications, setNotifications] = useState(mockNotifications);

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
  };

  const toggleStar = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, starred: !notif.starred } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    );
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;
  const starredCount = notifications.filter(n => n.starred).length;

  // Sort: starred first, then by timestamp
  const sortedNotifications = [...notifications].sort((a, b) => {
    if (a.starred && !b.starred) return -1;
    if (!a.starred && b.starred) return 1;
    return 0;
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          {/* Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-card border-l border-border shadow-2xl z-50 flex flex-col"
          >
            {/* Header */}
            <div className="border-b border-border p-4 bg-muted/30">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <h2 className="font-mono">Notifications</h2>
                  {unreadCount > 0 && (
                    <Badge variant="destructive" className="font-mono">
                      {unreadCount} new
                    </Badge>
                  )}
                  {starredCount > 0 && (
                    <Badge variant="outline" className="font-mono border-primary/50 text-primary">
                      <Star className="w-3 h-3 mr-1 fill-primary" />
                      {starredCount}
                    </Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="h-8 w-8 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={markAllAsRead}
                  disabled={unreadCount === 0}
                  className="flex-1 h-8 text-xs font-mono"
                >
                  Mark all read
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearAll}
                  disabled={notifications.length === 0}
                  className="flex-1 h-8 text-xs font-mono"
                >
                  Clear all
                </Button>
              </div>
            </div>

            {/* Notifications list */}
            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <div className="p-4 space-y-3">
                <AnimatePresence initial={false}>
                  {notifications.length === 0 ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-center py-12"
                    >
                      <CheckCircle2 className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-muted-foreground font-mono text-sm">
                        No notifications
                      </p>
                    </motion.div>
                  ) : (
                    sortedNotifications.map((notification) => (
                      <motion.div
                        key={notification.id}
                        layout
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: 100 }}
                        onClick={() => markAsRead(notification.id)}
                        className={`
                          relative bg-muted/30 border rounded-lg p-4 cursor-pointer
                          transition-all hover:border-primary/50 group
                          ${notification.read ? 'border-border/50' : 'border-primary/30'}
                        `}
                      >
                        {/* Unread indicator */}
                        {!notification.read && (
                          <div
                            className="absolute left-0 top-0 bottom-0 w-1 rounded-l-lg"
                            style={{ backgroundColor: getNotificationColor(notification.type) }}
                          />
                        )}

                        <div className="ml-3">
                          {/* Header */}
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex items-start gap-2 flex-1">
                              <div
                                className="mt-0.5"
                                style={{ color: getNotificationColor(notification.type) }}
                              >
                                {getNotificationIcon(notification.type)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="text-sm font-mono">
                                    {notification.title}
                                  </h3>
                                  {notification.starred && (
                                    <Star className="w-3 h-3 fill-primary text-primary flex-shrink-0" />
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground">
                                  {notification.message}
                                </p>
                              </div>
                            </div>
                            
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleStar(notification.id);
                                }}
                                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Star className={`w-3 h-3 ${notification.starred ? 'fill-primary text-primary' : ''}`} />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteNotification(notification.id);
                                }}
                                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>

                          {/* Footer */}
                          <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono ml-7">
                            <Clock className="w-3 h-3" />
                            {notification.timestamp}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
                </div>
              </ScrollArea>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
