import { useState } from 'react';
import { Settings, Server, Bell, Download, FileText, Power } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [criticalOnly, setCriticalOnly] = useState(false);
  const [autoBlock, setAutoBlock] = useState(true);
  const [logRetention, setLogRetention] = useState(true);

  const handleConfigureHoneypots = () => {
    toast.info('Opening honeypot configuration panel...');
    onOpenChange(false);
  };

  const handleAlertSettings = () => {
    toast.success('Alert settings saved successfully');
  };

  const handleExportLogs = () => {
    // Generate PDF content
    const generatePDF = async () => {
      // Create a simple PDF using HTML canvas approach
      const pdfContent = `
        <html>
          <head>
            <style>
              body { 
                font-family: monospace; 
                padding: 40px; 
                background: white;
                color: black;
              }
              .header { 
                text-align: center; 
                border-bottom: 2px solid #00ffff; 
                padding-bottom: 20px;
                margin-bottom: 30px;
              }
              .header h1 { color: #00ffff; margin: 0; }
              .section { margin: 20px 0; }
              .section h2 { 
                color: #00ffff; 
                border-bottom: 1px solid #ccc; 
                padding-bottom: 5px;
              }
              table { 
                width: 100%; 
                border-collapse: collapse; 
                margin: 10px 0;
              }
              th, td { 
                border: 1px solid #ddd; 
                padding: 8px; 
                text-align: left;
              }
              th { background-color: #f0f0f0; }
              .critical { color: #ff0055; font-weight: bold; }
              .high { color: #ff6b00; }
              .medium { color: #ffbb00; }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>🛡 HONEYPOT DEFENSE GRID</h1>
              <p>System Logs Export</p>
              <p>Generated: ${new Date().toLocaleString()}</p>
            </div>

            <div class="section">
              <h2>System Overview</h2>
              <p><strong>Version:</strong> v2.4.1</p>
              <p><strong>Status:</strong> Active</p>
              <p><strong>Total Events:</strong> 3,482</p>
              <p><strong>Blocked Attacks:</strong> 3,441 (98.8%)</p>
              <p><strong>Active Honeypots:</strong> 24</p>
            </div>

            <div class="section">
              <h2>Recent Threat Events</h2>
              <table>
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>IP Address</th>
                    <th>Event</th>
                    <th>Severity</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>2025-10-11 10:23:45</td>
                    <td>185.220.101.42</td>
                    <td>Brute force attempt blocked</td>
                    <td class="critical">CRITICAL</td>
                  </tr>
                  <tr>
                    <td>2025-10-11 10:24:12</td>
                    <td>103.75.189.34</td>
                    <td>Port scan detected</td>
                    <td class="high">HIGH</td>
                  </tr>
                  <tr>
                    <td>2025-10-11 10:25:33</td>
                    <td>45.142.212.61</td>
                    <td>SQL injection blocked</td>
                    <td class="critical">CRITICAL</td>
                  </tr>
                  <tr>
                    <td>2025-10-11 10:26:45</td>
                    <td>198.98.57.207</td>
                    <td>Bot activity detected</td>
                    <td class="medium">MEDIUM</td>
                  </tr>
                  <tr>
                    <td>2025-10-11 10:27:12</td>
                    <td>162.142.125.33</td>
                    <td>Credential stuffing blocked</td>
                    <td class="high">HIGH</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="section">
              <h2>Attack Statistics</h2>
              <p><strong>Brute Force:</strong> 1,245 (36%)</p>
              <p><strong>SQL Injection:</strong> 892 (26%)</p>
              <p><strong>Port Scanning:</strong> 654 (19%)</p>
              <p><strong>XSS Attempts:</strong> 421 (12%)</p>
              <p><strong>Other:</strong> 270 (7%)</p>
            </div>

            <div class="section">
              <h2>Top Attack Origins</h2>
              <p>🇷🇺 Russia: 845 attacks</p>
              <p>🇨🇳 China: 723 attacks</p>
              <p>🇺🇸 USA: 512 attacks</p>
              <p>🇩🇪 Germany: 389 attacks</p>
              <p>🇧🇷 Brazil: 267 attacks</p>
            </div>
          </body>
        </html>
      `;

      // Create a temporary window to render and print
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(pdfContent);
        printWindow.document.close();
        
        // Wait for content to load
        setTimeout(() => {
          printWindow.print();
          setTimeout(() => {
            printWindow.close();
          }, 100);
        }, 500);
      }
    };

    generatePDF();

    toast.success('PDF export initiated', {
      description: 'Print dialog opened',
    });
  };

  const handleSystemReports = () => {
    // Generate system report
    const reportData = `
HONEYPOT DEFENSE GRID - SYSTEM REPORT
Generated: ${new Date().toLocaleString()}
========================================

SYSTEM OVERVIEW
---------------
Version: v2.4.1
Status: Active
Uptime: 99.8%

ATTACK STATISTICS (Last 24h)
----------------------------
Total Attacks: 3,482
Blocked Attacks: 3,441
Success Rate: 98.8%
Unique Attack IPs: 847
Average Response Time: 12ms

HONEYPOT STATUS
--------------
Active Honeypots: 24
SSH Honeypots: 8
HTTP Honeypots: 6
FTP Honeypots: 4
SMTP Honeypots: 3
MySQL Honeypots: 2
Telnet Honeypots: 1

TOP ATTACK TYPES
---------------
1. Brute Force: 1,245 (36%)
2. SQL Injection: 892 (26%)
3. Port Scanning: 654 (19%)
4. XSS Attempts: 421 (12%)
5. Other: 270 (7%)

TOP ATTACK ORIGINS
-----------------
1. Russia: 845 attacks
2. China: 723 attacks
3. USA: 512 attacks
4. Germany: 389 attacks
5. Brazil: 267 attacks

RECOMMENDATIONS
--------------
- Continue monitoring SSH honeypot on port 2222
- Update threat database (247 new signatures available)
- Review flagged IPs for permanent blocking
- Schedule weekly security audit

END OF REPORT
    `;

    const blob = new Blob([reportData], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `honeypot-report-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.info('System report generated', {
      description: 'Download started',
    });
  };

  const handleShutdown = () => {
    toast.error('System shutdown initiated', {
      description: 'All honeypots will be deactivated',
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-card border-primary/30">
        <DialogHeader>
          <DialogTitle className="font-mono flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            System Settings
          </DialogTitle>
          <DialogDescription className="font-mono text-sm">
            Configure honeypot system preferences and security settings
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="alerts" className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="honeypots">Honeypots</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          <TabsContent value="alerts" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="font-mono">Email Alerts</Label>
                  <p className="text-sm text-muted-foreground">
                    Receive threat notifications via email
                  </p>
                </div>
                <Switch
                  checked={emailAlerts}
                  onCheckedChange={setEmailAlerts}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="font-mono">Push Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Real-time browser notifications
                  </p>
                </div>
                <Switch
                  checked={pushNotifications}
                  onCheckedChange={setPushNotifications}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="font-mono">Critical Only</Label>
                  <p className="text-sm text-muted-foreground">
                    Only notify for critical threats
                  </p>
                </div>
                <Switch
                  checked={criticalOnly}
                  onCheckedChange={setCriticalOnly}
                />
              </div>

              <Button 
                onClick={handleAlertSettings}
                className="w-full bg-primary hover:bg-primary/90 font-mono"
              >
                Save Alert Settings
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="honeypots" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="font-mono">Auto-Block IPs</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically block malicious IPs
                  </p>
                </div>
                <Switch
                  checked={autoBlock}
                  onCheckedChange={setAutoBlock}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="font-mono">Log All Activity</Label>
                  <p className="text-sm text-muted-foreground">
                    Store complete interaction logs
                  </p>
                </div>
                <Switch
                  checked={logRetention}
                  onCheckedChange={setLogRetention}
                />
              </div>

              <Button 
                onClick={handleConfigureHoneypots}
                variant="outline"
                className="w-full font-mono"
              >
                <Server className="w-4 h-4 mr-2" />
                Configure Honeypots
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="system" className="space-y-3 mt-4">
            <Button 
              onClick={handleExportLogs}
              variant="outline"
              className="w-full justify-start font-mono"
            >
              <Download className="w-4 h-4 mr-2" />
              Export System Logs
            </Button>

            <Button 
              onClick={handleSystemReports}
              variant="outline"
              className="w-full justify-start font-mono"
            >
              <FileText className="w-4 h-4 mr-2" />
              Generate System Report
            </Button>

            <div className="border-t border-border my-4" />

            <Button 
              onClick={handleShutdown}
              variant="destructive"
              className="w-full justify-start font-mono"
            >
              <Power className="w-4 h-4 mr-2" />
              Shutdown System
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
