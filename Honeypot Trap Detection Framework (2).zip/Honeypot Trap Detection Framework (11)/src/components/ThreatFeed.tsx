import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal, Wifi, Globe, Clock, Search, Filter } from 'lucide-react';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface ThreatEvent {
  id: string;
  timestamp: string;
  ip: string;
  country: string;
  type: string;
  protocol: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  action: string;
}

const mockThreats: Omit<ThreatEvent, 'id' | 'timestamp'>[] = [
  { ip: '185.220.101.42', country: 'Russia', type: 'Brute Force', protocol: 'SSH', severity: 'critical', action: 'login attempt on root' },
  { ip: '103.75.189.34', country: 'China', type: 'Port Scan', protocol: 'TCP', severity: 'high', action: 'scanning ports 22-8080' },
  { ip: '45.142.212.61', country: 'Netherlands', type: 'SQLi Attempt', protocol: 'HTTP', severity: 'critical', action: 'injection detected in /admin' },
  { ip: '198.98.57.207', country: 'USA', type: 'Bot Activity', protocol: 'HTTP', severity: 'medium', action: 'crawling honeypot pages' },
  { ip: '162.142.125.33', country: 'Germany', type: 'Credential Stuffing', protocol: 'HTTPS', severity: 'high', action: 'multiple login failures' },
  { ip: '91.203.5.165', country: 'Ukraine', type: 'Command Injection', protocol: 'FTP', severity: 'critical', action: 'attempted shell execution' },
  { ip: '37.120.141.42', country: 'Iran', type: 'DDoS Probe', protocol: 'UDP', severity: 'medium', action: 'flood testing detected' },
  { ip: '194.76.225.61', country: 'France', type: 'XSS Attempt', protocol: 'HTTP', severity: 'high', action: 'script injection in form' },
];

function getSeverityColor(severity: string) {
  switch (severity) {
    case 'critical': return '#ff0055';
    case 'high': return '#ff6b00';
    case 'medium': return '#ffbb00';
    case 'low': return '#00ff88';
    default: return '#00ffff';
  }
}

export function ThreatFeed() {
  const [threats, setThreats] = useState<ThreatEvent[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [severityFilter, setSeverityFilter] = useState<Set<string>>(new Set(['critical', 'high', 'medium', 'low']));

  useEffect(() => {
    // Add initial threats
    const initialThreats = mockThreats.slice(0, 5).map((threat, index) => ({
      ...threat,
      id: `threat-${Date.now()}-${index}`,
      timestamp: new Date(Date.now() - index * 5000).toLocaleTimeString(),
    }));
    setThreats(initialThreats);

    // Add new threat every 3-5 seconds
    const interval = setInterval(() => {
      const randomThreat = mockThreats[Math.floor(Math.random() * mockThreats.length)];
      const newThreat: ThreatEvent = {
        ...randomThreat,
        id: `threat-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString(),
      };
      
      setThreats(prev => [newThreat, ...prev.slice(0, 19)]); // Keep last 20
    }, Math.random() * 2000 + 3000);

    return () => clearInterval(interval);
  }, []);

  const toggleSeverity = (severity: string) => {
    setSeverityFilter(prev => {
      const newSet = new Set(prev);
      if (newSet.has(severity)) {
        newSet.delete(severity);
      } else {
        newSet.add(severity);
      }
      return newSet;
    });
  };

  const filteredThreats = threats.filter(threat => {
    const matchesSeverity = severityFilter.has(threat.severity);
    const matchesSearch = searchQuery === '' || 
      threat.ip.toLowerCase().includes(searchQuery.toLowerCase()) ||
      threat.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      threat.type.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesSeverity && matchesSearch;
  });

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-primary" />
            <h3 className="font-mono">Live Threat Feed</h3>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm text-muted-foreground">ACTIVE</span>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by IP, country, type..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 bg-input-background border-primary/30 font-mono text-sm"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 gap-2">
                <Filter className="w-4 h-4" />
                Filter
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="font-mono text-xs">Severity Level</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem
                checked={severityFilter.has('critical')}
                onCheckedChange={() => toggleSeverity('critical')}
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#ff0055]" />
                  <span className="font-mono text-sm">Critical</span>
                </div>
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={severityFilter.has('high')}
                onCheckedChange={() => toggleSeverity('high')}
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#ff6b00]" />
                  <span className="font-mono text-sm">High</span>
                </div>
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={severityFilter.has('medium')}
                onCheckedChange={() => toggleSeverity('medium')}
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#ffbb00]" />
                  <span className="font-mono text-sm">Medium</span>
                </div>
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={severityFilter.has('low')}
                onCheckedChange={() => toggleSeverity('low')}
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#00ff88]" />
                  <span className="font-mono text-sm">Low</span>
                </div>
              </DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Feed content */}
      <div className="flex-1 overflow-hidden p-4">
        <div className="h-full overflow-y-auto space-y-2 scrollbar-thin">
          <AnimatePresence initial={false}>
            {filteredThreats.map((threat) => (
              <motion.div
                key={threat.id}
                initial={{ opacity: 0, x: -20, height: 0 }}
                animate={{ opacity: 1, x: 0, height: 'auto' }}
                exit={{ opacity: 0, x: 20, height: 0 }}
                transition={{ duration: 0.3 }}
                className="relative bg-muted/30 border border-border/50 rounded p-3 overflow-hidden group hover:border-primary/50 transition-colors"
              >
                {/* Severity indicator */}
                <div 
                  className="absolute left-0 top-0 bottom-0 w-1"
                  style={{ backgroundColor: getSeverityColor(threat.severity) }}
                />
                
                <div className="ml-3">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline" 
                        className="border-primary/50 text-primary text-xs font-mono"
                      >
                        {threat.protocol}
                      </Badge>
                      <span 
                        className="text-xs uppercase tracking-wider font-mono"
                        style={{ color: getSeverityColor(threat.severity) }}
                      >
                        {threat.severity}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {threat.timestamp}
                    </div>
                  </div>
                  
                  <div className="text-sm mb-2">{threat.type}</div>
                  
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Wifi className="w-3 h-3" />
                      <span className="font-mono">{threat.ip}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Globe className="w-3 h-3" />
                      <span>{threat.country}</span>
                    </div>
                  </div>
                  
                  <div className="mt-2 text-xs text-muted-foreground font-mono">
                    → {threat.action}
                  </div>
                </div>

                {/* Hover glow effect */}
                <div 
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none"
                  style={{
                    background: `radial-gradient(circle at center, ${getSeverityColor(threat.severity)}, transparent 70%)`
                  }}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
