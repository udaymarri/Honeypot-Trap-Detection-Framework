import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Crosshair, Flag, X, Wifi, Server, Clock, ShieldAlert, Maximize2, Minimize2 } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { FlaggedThreatsTable } from './FlaggedThreatsTable';

interface AttackNode {
  id: string;
  x: number;
  y: number;
  country: string;
  ip: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  attackType: string;
  protocol: string;
  timestamp: string;
  attempts: number;
  flagged: boolean;
}

interface AttackBeam {
  id: string;
  startX: number;
  startY: number;
  endX: number;
  endY: number;
  color: string;
}

const severityColors = {
  critical: '#ff0055',
  high: '#ff6b00',
  medium: '#ffbb00',
  low: '#00ff88',
};

const attackOrigins = [
  { country: 'Russia', region: 'Eastern Europe' },
  { country: 'China', region: 'East Asia' },
  { country: 'USA', region: 'North America' },
  { country: 'Iran', region: 'Middle East' },
  { country: 'Brazil', region: 'South America' },
  { country: 'Germany', region: 'Western Europe' },
  { country: 'India', region: 'South Asia' },
];

const attackTypes = ['Brute Force', 'SQL Injection', 'Port Scan', 'DDoS', 'XSS', 'Command Injection'];
const protocols = ['SSH', 'HTTP', 'FTP', 'SMTP', 'MySQL', 'Telnet'];

function generateRandomIP() {
  return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
}

export function ThreatMap() {
  const [nodes, setNodes] = useState<AttackNode[]>([]);
  const [beams, setBeams] = useState<AttackBeam[]>([]);
  const [selectedNode, setSelectedNode] = useState<AttackNode | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const centerX = 50;
  const centerY = 50;

  useEffect(() => {
    // Generate initial nodes
    const initialNodes: AttackNode[] = Array.from({ length: 6 }, (_, i) => {
      const angle = (i / 6) * 2 * Math.PI;
      const radius = 35;
      const origin = attackOrigins[i % attackOrigins.length];
      return {
        id: `node-${i}`,
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        country: origin.country,
        ip: generateRandomIP(),
        severity: ['critical', 'high', 'medium', 'low'][Math.floor(Math.random() * 4)] as any,
        attackType: attackTypes[Math.floor(Math.random() * attackTypes.length)],
        protocol: protocols[Math.floor(Math.random() * protocols.length)],
        timestamp: new Date().toLocaleTimeString(),
        attempts: Math.floor(Math.random() * 200) + 10,
        flagged: false,
      };
    });
    setNodes(initialNodes);

    // Animate attack beams
    const beamInterval = setInterval(() => {
      const randomNode = initialNodes[Math.floor(Math.random() * initialNodes.length)];
      const newBeam: AttackBeam = {
        id: `beam-${Date.now()}`,
        startX: randomNode.x,
        startY: randomNode.y,
        endX: centerX,
        endY: centerY,
        color: severityColors[randomNode.severity],
      };
      
      setBeams(prev => [...prev, newBeam]);
      
      // Remove beam after animation
      setTimeout(() => {
        setBeams(prev => prev.filter(b => b.id !== newBeam.id));
      }, 2000);
    }, 1500);

    // Occasionally add new nodes
    const nodeInterval = setInterval(() => {
      const angle = Math.random() * 2 * Math.PI;
      const radius = 30 + Math.random() * 10;
      const randomOrigin = attackOrigins[Math.floor(Math.random() * attackOrigins.length)];
      const severity = ['critical', 'high', 'medium', 'low'][Math.floor(Math.random() * 4)] as any;
      
      const newNode: AttackNode = {
        id: `node-${Date.now()}`,
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        country: randomOrigin.country,
        ip: generateRandomIP(),
        severity,
        attackType: attackTypes[Math.floor(Math.random() * attackTypes.length)],
        protocol: protocols[Math.floor(Math.random() * protocols.length)],
        timestamp: new Date().toLocaleTimeString(),
        attempts: Math.floor(Math.random() * 200) + 10,
        flagged: false,
      };
      
      setNodes(prev => [...prev.slice(-8), newNode]);
      
      // Remove non-flagged nodes after a delay (critical dots stay 2 seconds longer)
      setTimeout(() => {
        setNodes(current => 
          current.filter(n => n.id !== newNode.id || n.flagged)
        );
      }, severity === 'critical' ? 7000 : 5000); // Critical: 7s, Others: 5s
    }, 5000);

    return () => {
      clearInterval(beamInterval);
      clearInterval(nodeInterval);
    };
  }, []);

  const toggleFlag = (nodeId: string) => {
    setNodes(prev =>
      prev.map(node =>
        node.id === nodeId ? { ...node, flagged: !node.flagged } : node
      )
    );
  };

  const flaggedNodes = nodes.filter(n => n.flagged);

  const containerClasses = isFullscreen
    ? "fixed inset-0 z-[60] bg-background flex flex-col"
    : "";

  return (
    <div className={containerClasses}>
      {/* Flagged threats table - only show when not in fullscreen */}
      {!isFullscreen && flaggedNodes.length > 0 && (
        <FlaggedThreatsTable
          threats={flaggedNodes}
          onUnflag={toggleFlag}
          onViewDetails={setSelectedNode}
        />
      )}

      <div className={isFullscreen ? "flex-1 bg-card flex flex-col" : "bg-card border border-border rounded-lg h-full flex flex-col overflow-hidden"}>
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Crosshair className="w-5 h-5 text-primary" />
          <h3 className="font-mono">Threat Visualization</h3>
        </div>
        <div className="flex items-center gap-3">
          {flaggedNodes.length > 0 && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Flag className="w-4 h-4 text-primary" />
              <span className="font-mono">{flaggedNodes.length} Flagged</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span className="font-mono">Global Attack Map</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="h-8 w-8 p-0"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </Button>
        </div>
        </div>

        {/* Map visualization */}
        <div className="flex-1 relative p-8">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet">
          {/* Grid background */}
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(0, 255, 255, 0.1)" strokeWidth="0.5"/>
            </pattern>
            <radialGradient id="centerGlow">
              <stop offset="0%" stopColor="#00ffff" stopOpacity="0.3"/>
              <stop offset="100%" stopColor="#00ffff" stopOpacity="0"/>
            </radialGradient>
          </defs>
          
          <rect width="100" height="100" fill="url(#grid)" />
          
          {/* Center honeypot */}
          <circle 
            cx={centerX} 
            cy={centerY} 
            r="15" 
            fill="url(#centerGlow)"
            stroke="#00ffff"
            strokeWidth="0.5"
          />
          <circle 
            cx={centerX} 
            cy={centerY} 
            r="3" 
            fill="#00ffff"
          />
          
          {/* Concentric circles */}
          {[15, 25, 35].map((radius, i) => (
            <circle
              key={i}
              cx={centerX}
              cy={centerY}
              r={radius}
              fill="none"
              stroke="rgba(0, 255, 255, 0.2)"
              strokeWidth="0.3"
              strokeDasharray="2,2"
            />
          ))}
          
          {/* Attack beams */}
          <AnimatePresence>
            {beams.map((beam) => (
              <motion.line
                key={beam.id}
                x1={beam.startX}
                y1={beam.startY}
                x2={beam.startX}
                y2={beam.startY}
                stroke={beam.color}
                strokeWidth="0.5"
                initial={{ x2: beam.startX, y2: beam.startY, opacity: 0 }}
                animate={{ x2: beam.endX, y2: beam.endY, opacity: [0, 1, 0] }}
                exit={{ opacity: 0 }}
                transition={{ duration: 2, ease: 'easeOut' }}
              />
            ))}
          </AnimatePresence>
          
          {/* Attack nodes */}
          <AnimatePresence>
            {nodes.map((node) => (
              <g key={node.id}>
                <motion.circle
                  cx={node.x}
                  cy={node.y}
                  r="2"
                  fill={severityColors[node.severity]}
                  initial={{ r: 0, opacity: 0 }}
                  animate={{ 
                    r: 2, 
                    opacity: node.flagged ? 1 : [1, 0.3, 1]
                  }}
                  exit={{ r: 0, opacity: 0 }}
                  transition={{ 
                    duration: 0.5,
                    opacity: { duration: node.flagged ? 0 : 2, repeat: node.flagged ? 0 : Infinity }
                  }}
                  className="cursor-pointer hover:opacity-80"
                  onClick={() => setSelectedNode(node)}
                  style={{ pointerEvents: 'all' }}
                />
                {!node.flagged && (
                  <motion.circle
                    cx={node.x}
                    cy={node.y}
                    r="2"
                    fill="none"
                    stroke={severityColors[node.severity]}
                    strokeWidth="0.3"
                    initial={{ r: 2, opacity: 0.5 }}
                    animate={{ r: 6, opacity: 0 }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}
                {node.flagged && (
                  <>
                    {/* Pinned node - solid with flag */}
                    <motion.circle
                      cx={node.x}
                      cy={node.y}
                      r="2.5"
                      fill="none"
                      stroke="#00ffff"
                      strokeWidth="0.5"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                    />
                    {/* Flag icon */}
                    <motion.g
                      initial={{ opacity: 0, y: 2 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <path
                        d={`M ${node.x - 1.5} ${node.y - 5} L ${node.x - 1.5} ${node.y - 1}`}
                        stroke="#00ffff"
                        strokeWidth="0.3"
                        fill="none"
                      />
                      <path
                        d={`M ${node.x - 1.5} ${node.y - 5} L ${node.x + 1} ${node.y - 4} L ${node.x - 1.5} ${node.y - 3} Z`}
                        fill="#00ffff"
                      />
                    </motion.g>
                  </>
                )}
              </g>
            ))}
          </AnimatePresence>
        </svg>

        {/* Legend - Enhanced with full colors */}
        <div className="absolute bottom-4 right-4 bg-card/95 border-2 border-primary/30 rounded-lg p-4 backdrop-blur-md shadow-lg">
          <div className="text-xs text-primary mb-3 font-mono uppercase tracking-wider">Threat Levels</div>
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full shadow-lg"
                style={{ 
                  backgroundColor: severityColors.critical,
                  boxShadow: `0 0 10px ${severityColors.critical}50`
                }}
              />
              <span className="font-mono text-sm" style={{ color: severityColors.critical }}>
                Critical
              </span>
              <span className="ml-auto text-xs text-muted-foreground font-mono">7s</span>
            </div>
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full shadow-lg"
                style={{ 
                  backgroundColor: severityColors.high,
                  boxShadow: `0 0 10px ${severityColors.high}50`
                }}
              />
              <span className="font-mono text-sm" style={{ color: severityColors.high }}>
                High
              </span>
              <span className="ml-auto text-xs text-muted-foreground font-mono">5s</span>
            </div>
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full shadow-lg"
                style={{ 
                  backgroundColor: severityColors.medium,
                  boxShadow: `0 0 10px ${severityColors.medium}50`
                }}
              />
              <span className="font-mono text-sm" style={{ color: severityColors.medium }}>
                Medium
              </span>
              <span className="ml-auto text-xs text-muted-foreground font-mono">5s</span>
            </div>
            <div className="flex items-center gap-3">
              <div 
                className="w-4 h-4 rounded-full shadow-lg"
                style={{ 
                  backgroundColor: severityColors.low,
                  boxShadow: `0 0 10px ${severityColors.low}50`
                }}
              />
              <span className="font-mono text-sm" style={{ color: severityColors.low }}>
                Low
              </span>
              <span className="ml-auto text-xs text-muted-foreground font-mono">5s</span>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Flag className="w-3 h-3 text-primary" />
              <span className="font-mono">Click to pin threat</span>
            </div>
          </div>
        </div>

        {/* Live attack counter - animated */}
        <motion.div
          className="absolute top-4 right-4 bg-card/90 border border-primary/50 rounded-lg p-3 backdrop-blur-sm"
          animate={{
            boxShadow: [
              '0 0 10px rgba(0, 255, 255, 0.3)',
              '0 0 20px rgba(0, 255, 255, 0.5)',
              '0 0 10px rgba(0, 255, 255, 0.3)',
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="text-xs text-muted-foreground mb-1 font-mono">LIVE ATTACKS</div>
          <motion.div
            key={nodes.length}
            initial={{ scale: 1.2, color: '#ff0055' }}
            animate={{ scale: 1, color: '#00ffff' }}
            transition={{ duration: 0.3 }}
            className="text-2xl font-mono text-primary"
          >
            {nodes.length}
          </motion.div>
          <div className="text-xs text-primary/70 mt-1 font-mono">
            {nodes.filter(n => !n.flagged).length} Active
          </div>
        </motion.div>

        {/* Node details modal */}
        <AnimatePresence>
          {selectedNode && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 flex items-center justify-center z-10 p-8"
            >
              <div 
                className="absolute inset-0 bg-black/50 backdrop-blur-sm"
                onClick={() => setSelectedNode(null)}
              />
              
              <div className="relative bg-card border-2 border-primary/50 rounded-lg p-6 max-w-lg w-full shadow-2xl max-h-[80vh] overflow-y-auto">
                {/* Close button */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedNode(null)}
                  className="absolute top-3 right-3 h-8 w-8 p-0 z-10 bg-card"
                >
                  <X className="w-4 h-4" />
                </Button>

                {/* Header */}
                <div className="mb-4 pr-8">
                  <div className="flex items-center gap-2 mb-2">
                    <ShieldAlert 
                      className="w-5 h-5"
                      style={{ color: severityColors[selectedNode.severity] }}
                    />
                    <h3 className="font-mono">Threat Details</h3>
                  </div>
                  <Badge 
                    variant="outline"
                    style={{ 
                      borderColor: severityColors[selectedNode.severity],
                      color: severityColors[selectedNode.severity],
                    }}
                    className="uppercase text-xs"
                  >
                    {selectedNode.severity} THREAT
                  </Badge>
                </div>

                {/* Details */}
                <div className="space-y-3 mb-4 text-sm">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-start gap-2 bg-muted/30 border border-border/50 rounded p-3">
                      <Wifi className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-muted-foreground mb-1">IP Address</div>
                        <div className="font-mono text-sm break-all">{selectedNode.ip}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 bg-muted/30 border border-border/50 rounded p-3">
                      <MapPin className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-muted-foreground mb-1">Origin</div>
                        <div className="font-mono text-sm truncate">{selectedNode.country}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 bg-muted/30 border border-border/50 rounded p-3">
                      <Server className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-muted-foreground mb-1">Attack Type</div>
                        <div className="font-mono text-sm">{selectedNode.attackType}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 bg-muted/30 border border-border/50 rounded p-3">
                      <Server className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs text-muted-foreground mb-1">Protocol</div>
                        <div className="font-mono text-sm">{selectedNode.protocol}</div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 bg-muted/30 border border-border/50 rounded p-3">
                    <Clock className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="text-xs text-muted-foreground mb-1">First Detected</div>
                      <div className="font-mono text-sm">{selectedNode.timestamp}</div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/30 rounded-lg p-4">
                    <div className="text-xs text-muted-foreground mb-2">Total Attack Attempts</div>
                    <div className="text-3xl font-mono text-primary">{selectedNode.attempts}</div>
                    <div className="text-xs text-muted-foreground mt-1">
                      Captured by {selectedNode.protocol} Honeypot
                    </div>
                  </div>

                  {/* Additional threat information */}
                  <div className="bg-muted/20 border border-border/50 rounded-lg p-3">
                    <div className="text-xs text-muted-foreground mb-2">Threat Assessment</div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Risk Level:</span>
                        <span className="font-mono" style={{ color: severityColors[selectedNode.severity] }}>
                          {selectedNode.severity.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Action Taken:</span>
                        <span className="font-mono text-primary">BLOCKED</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Status:</span>
                        <span className="font-mono text-[#00ff88]">CONTAINED</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      toggleFlag(selectedNode.id);
                      setSelectedNode(prev => prev ? { ...prev, flagged: !prev.flagged } : null);
                    }}
                    variant={selectedNode.flagged ? 'default' : 'outline'}
                    className="flex-1 font-mono gap-2"
                  >
                    <Flag className="w-4 h-4" />
                    {selectedNode.flagged ? 'Unflag' : 'Flag for Review'}
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
