import { Shield, Activity, AlertTriangle, Target } from 'lucide-react';
import { motion } from 'motion/react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  trend?: string;
}

function StatCard({ title, value, icon, color, trend }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative bg-card border border-border rounded-lg p-6 overflow-hidden group"
    >
      {/* Glow effect */}
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle at center, ${color}, transparent 70%)`
        }}
      />
      
      {/* Corner accent */}
      <div 
        className="absolute top-0 right-0 w-20 h-20 opacity-20"
        style={{
          background: `linear-gradient(135deg, ${color}, transparent)`
        }}
      />
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="text-muted-foreground">{title}</div>
          <div style={{ color }}>{icon}</div>
        </div>
        
        <div className="flex items-end justify-between">
          <div className="text-4xl font-mono" style={{ color }}>{value}</div>
          {trend && (
            <div className="text-sm text-muted-foreground">{trend}</div>
          )}
        </div>
      </div>
      
      {/* Scan line effect */}
      <motion.div
        className="absolute inset-x-0 h-px opacity-30"
        style={{ background: color }}
        animate={{
          top: ['0%', '100%'],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: 'linear',
        }}
      />
    </motion.div>
  );
}

export function ThreatStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard
        title="Active Threats"
        value="127"
        icon={<AlertTriangle className="w-6 h-6" />}
        color="#ff0055"
        trend="+12%"
      />
      <StatCard
        title="Honeypots Active"
        value="24"
        icon={<Target className="w-6 h-6" />}
        color="#00ffff"
        trend="100%"
      />
      <StatCard
        title="Attacks Blocked"
        value="3,482"
        icon={<Shield className="w-6 h-6" />}
        color="#00ff88"
        trend="+24%"
      />
      <StatCard
        title="Live Sessions"
        value="89"
        icon={<Activity className="w-6 h-6" />}
        color="#7b2cbf"
        trend="+8"
      />
    </div>
  );
}
