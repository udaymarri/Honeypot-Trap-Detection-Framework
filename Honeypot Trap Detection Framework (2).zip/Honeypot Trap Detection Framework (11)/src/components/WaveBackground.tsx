import { motion } from 'motion/react';

export function WaveBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Animated wave layers */}
      <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
        <defs>
          <linearGradient id="wave-gradient-1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(0, 255, 255, 0.1)" />
            <stop offset="50%" stopColor="rgba(0, 255, 255, 0.2)" />
            <stop offset="100%" stopColor="rgba(0, 255, 255, 0.1)" />
          </linearGradient>
          <linearGradient id="wave-gradient-2" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(123, 44, 191, 0.1)" />
            <stop offset="50%" stopColor="rgba(123, 44, 191, 0.2)" />
            <stop offset="100%" stopColor="rgba(123, 44, 191, 0.1)" />
          </linearGradient>
          <linearGradient id="wave-gradient-3" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(107, 70, 255, 0.08)" />
            <stop offset="50%" stopColor="rgba(107, 70, 255, 0.15)" />
            <stop offset="100%" stopColor="rgba(107, 70, 255, 0.08)" />
          </linearGradient>
        </defs>
        
        {/* Wave 1 - Cyan */}
        <motion.path
          d="M0,200 Q250,150 500,200 T1000,200 T1500,200 T2000,200 V1000 H0 Z"
          fill="url(#wave-gradient-1)"
          initial={{ d: "M0,200 Q250,150 500,200 T1000,200 T1500,200 T2000,200 V1000 H0 Z" }}
          animate={{ 
            d: [
              "M0,200 Q250,150 500,200 T1000,200 T1500,200 T2000,200 V1000 H0 Z",
              "M0,180 Q250,230 500,180 T1000,180 T1500,180 T2000,180 V1000 H0 Z",
              "M0,200 Q250,150 500,200 T1000,200 T1500,200 T2000,200 V1000 H0 Z"
            ]
          }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Wave 2 - Purple */}
        <motion.path
          d="M0,300 Q250,350 500,300 T1000,300 T1500,300 T2000,300 V1000 H0 Z"
          fill="url(#wave-gradient-2)"
          initial={{ d: "M0,300 Q250,350 500,300 T1000,300 T1500,300 T2000,300 V1000 H0 Z" }}
          animate={{ 
            d: [
              "M0,300 Q250,350 500,300 T1000,300 T1500,300 T2000,300 V1000 H0 Z",
              "M0,320 Q250,270 500,320 T1000,320 T1500,320 T2000,320 V1000 H0 Z",
              "M0,300 Q250,350 500,300 T1000,300 T1500,300 T2000,300 V1000 H0 Z"
            ]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        />
        
        {/* Wave 3 - Blue */}
        <motion.path
          d="M0,400 Q250,450 500,400 T1000,400 T1500,400 T2000,400 V1000 H0 Z"
          fill="url(#wave-gradient-3)"
          initial={{ d: "M0,400 Q250,450 500,400 T1000,400 T1500,400 T2000,400 V1000 H0 Z" }}
          animate={{ 
            d: [
              "M0,400 Q250,450 500,400 T1000,400 T1500,400 T2000,400 V1000 H0 Z",
              "M0,380 Q250,430 500,380 T1000,380 T1500,380 T2000,380 V1000 H0 Z",
              "M0,400 Q250,450 500,400 T1000,400 T1500,400 T2000,400 V1000 H0 Z"
            ]
          }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        />
      </svg>

      {/* Particle field */}
      <div className="absolute inset-0">
        {[...Array(40)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 4 + 2 + 'px',
              height: Math.random() * 4 + 2 + 'px',
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: i % 3 === 0 
                ? 'rgba(0, 255, 255, 0.6)' 
                : i % 3 === 1 
                ? 'rgba(123, 44, 191, 0.6)' 
                : 'rgba(107, 70, 255, 0.6)',
              boxShadow: `0 0 ${Math.random() * 10 + 10}px ${
                i % 3 === 0 
                  ? 'rgba(0, 255, 255, 0.8)' 
                  : i % 3 === 1 
                  ? 'rgba(123, 44, 191, 0.8)' 
                  : 'rgba(107, 70, 255, 0.8)'
              }`,
            }}
            animate={{
              y: [0, Math.random() * -100 - 50, 0],
              x: [0, Math.random() * 60 - 30, 0],
              opacity: [0.3, 1, 0.3],
              scale: [1, Math.random() + 1.5, 1],
            }}
            transition={{
              duration: Math.random() * 5 + 8,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Rotating radar circles */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          className="absolute rounded-full border border-primary/10"
          style={{ width: '400px', height: '400px' }}
          animate={{ rotate: 360 }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        >
          <div className="absolute top-1/2 left-1/2 w-2 h-2 -ml-1 -mt-1 bg-primary rounded-full shadow-[0_0_20px_rgba(0,255,255,0.8)]" />
        </motion.div>
        
        <motion.div
          className="absolute rounded-full border border-secondary/10"
          style={{ width: '600px', height: '600px' }}
          animate={{ rotate: -360 }}
          transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
        >
          <div className="absolute top-1/2 left-1/2 w-2 h-2 -ml-1 -mt-1 bg-secondary rounded-full shadow-[0_0_20px_rgba(123,44,191,0.8)]" />
        </motion.div>
        
        <motion.div
          className="absolute rounded-full border border-accent/10"
          style={{ width: '800px', height: '800px' }}
          animate={{ rotate: 360 }}
          transition={{ duration: 50, repeat: Infinity, ease: 'linear' }}
        >
          <div className="absolute top-1/2 left-1/2 w-2 h-2 -ml-1 -mt-1 bg-accent rounded-full shadow-[0_0_20px_rgba(107,70,255,0.8)]" />
        </motion.div>
      </div>

      {/* Energy beam lines */}
      <svg className="absolute inset-0 w-full h-full opacity-15" preserveAspectRatio="none">
        <defs>
          <linearGradient id="beam-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(0, 255, 255, 0)" />
            <stop offset="50%" stopColor="rgba(0, 255, 255, 1)" />
            <stop offset="100%" stopColor="rgba(0, 255, 255, 0)" />
          </linearGradient>
        </defs>
        
        {[...Array(6)].map((_, i) => (
          <motion.line
            key={i}
            x1={`${i * 16.6}%`}
            y1="0"
            x2={`${i * 16.6}%`}
            y2="100%"
            stroke="url(#beam-gradient)"
            strokeWidth="1"
            initial={{ opacity: 0.3 }}
            animate={{ opacity: [0.3, 0.8, 0.3] }}
            transition={{
              duration: 2 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </svg>

      {/* Glowing orbs */}
      <motion.div
        className="absolute w-[500px] h-[500px] rounded-full"
        style={{
          top: '20%',
          left: '10%',
          background: 'radial-gradient(circle, rgba(0, 255, 255, 0.12) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
        animate={{
          x: [0, 150, 0],
          y: [0, -100, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      <motion.div
        className="absolute w-[600px] h-[600px] rounded-full"
        style={{
          bottom: '10%',
          right: '10%',
          background: 'radial-gradient(circle, rgba(123, 44, 191, 0.15) 0%, transparent 70%)',
          filter: 'blur(90px)',
        }}
        animate={{
          x: [0, -120, 0],
          y: [0, 80, 0],
          scale: [1, 1.4, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Digital noise texture */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
        }}
      />

      {/* Gradient overlay for smooth blend */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background/90" />
    </div>
  );
}
