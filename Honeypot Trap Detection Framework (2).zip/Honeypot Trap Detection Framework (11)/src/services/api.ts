/**
 * API Service Layer
 * Handles all HTTP requests to the Node.js backend
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'ApiError';
  }
}

/**
 * Base fetch wrapper with error handling
 */
async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = sessionStorage.getItem('auth_token');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
      credentials: 'include',
    });

    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(response.status, data.error || data.message || 'Request failed');
    }

    return data;
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    
    // Network error or server not reachable
    console.error('[API] Network error:', error);
    throw new ApiError(0, 'Unable to connect to server. Please check your connection.');
  }
}

/**
 * Authentication API
 */
export const AuthAPI = {
  /**
   * Register new user
   */
  async register(username: string, email: string, password: string) {
    return apiFetch<{
      success: boolean;
      userId: string;
      message: string;
    }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, email, password }),
    });
  },

  /**
   * Login user (step 1 - credentials)
   */
  async login(username: string, password: string) {
    return apiFetch<{
      success: boolean;
      requires2FA: boolean;
      userId?: string;
      message: string;
    }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
  },

  /**
   * Verify 2FA code
   */
  async verify2FA(userId: string, code: string) {
    return apiFetch<{
      success: boolean;
      token: string;
      user: {
        id: string;
        username: string;
        email: string;
        role: string;
      };
    }>('/auth/verify-2fa', {
      method: 'POST',
      body: JSON.stringify({ userId, code }),
    });
  },

  /**
   * Setup 2FA for new user
   */
  async setup2FA(userId: string) {
    return apiFetch<{
      success: boolean;
      secret: string;
      qrCode: string;
    }>('/auth/setup-2fa', {
      method: 'POST',
      body: JSON.stringify({ userId }),
    });
  },

  /**
   * Verify 2FA setup
   */
  async verifySetup(userId: string, code: string) {
    return apiFetch<{
      success: boolean;
      token: string;
      user: {
        id: string;
        username: string;
        email: string;
        role: string;
      };
    }>('/auth/verify-setup', {
      method: 'POST',
      body: JSON.stringify({ userId, code }),
    });
  },

  /**
   * Logout
   */
  async logout() {
    sessionStorage.removeItem('auth_token');
    return { success: true };
  },
};

/**
 * Honeypots API
 */
export const HoneypotsAPI = {
  /**
   * Get all honeypots
   */
  async getAll() {
    return apiFetch<{
      success: boolean;
      honeypots: Array<{
        _id: string;
        name: string;
        type: string;
        protocol: string;
        port: number;
        status: string;
        location: string;
        attackCount: number;
        lastActivity: string;
        createdAt: string;
      }>;
    }>('/honeypots');
  },

  /**
   * Create new honeypot
   */
  async create(honeypot: {
    name: string;
    type: string;
    protocol: string;
    port: number;
    location: string;
  }) {
    return apiFetch('/honeypots', {
      method: 'POST',
      body: JSON.stringify(honeypot),
    });
  },

  /**
   * Update honeypot
   */
  async update(id: string, updates: any) {
    return apiFetch(`/honeypots/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  /**
   * Delete honeypot
   */
  async delete(id: string) {
    return apiFetch(`/honeypots/${id}`, {
      method: 'DELETE',
    });
  },
};

/**
 * Decoy Environments API
 */
export const DecoysAPI = {
  /**
   * Get all decoy environments
   */
  async getAll() {
    return apiFetch<{
      success: boolean;
      decoys: Array<{
        _id: string;
        name: string;
        type: string;
        status: string;
        credentials: Array<{
          username: string;
          password: string;
          accessLevel: string;
        }>;
        files: Array<{
          name: string;
          type: string;
          size: string;
          path: string;
        }>;
        services: string[];
        lastAccessed: string;
        accessCount: number;
      }>;
    }>('/decoys');
  },

  /**
   * Create new decoy environment
   */
  async create(decoy: any) {
    return apiFetch('/decoys', {
      method: 'POST',
      body: JSON.stringify(decoy),
    });
  },

  /**
   * Update decoy environment
   */
  async update(id: string, updates: any) {
    return apiFetch(`/decoys/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  /**
   * Delete decoy environment
   */
  async delete(id: string) {
    return apiFetch(`/decoys/${id}`, {
      method: 'DELETE',
    });
  },
};

/**
 * Attacks API
 */
export const AttacksAPI = {
  /**
   * Get all attack logs
   */
  async getAll(limit?: number) {
    const query = limit ? `?limit=${limit}` : '';
    return apiFetch<{
      success: boolean;
      attacks: Array<{
        _id: string;
        sourceIp: string;
        targetHoneypot: string;
        attackType: string;
        severity: string;
        protocol: string;
        payload: string;
        location: {
          country: string;
          city: string;
          lat: number;
          lon: number;
        };
        timestamp: string;
        blocked: boolean;
      }>;
      total: number;
    }>(`/attacks${query}`);
  },

  /**
   * Get attack statistics
   */
  async getStats() {
    return apiFetch<{
      success: boolean;
      stats: {
        total: number;
        today: number;
        byType: Record<string, number>;
        bySeverity: Record<string, number>;
        byCountry: Record<string, number>;
      };
    }>('/attacks/stats');
  },

  /**
   * Log new attack
   */
  async log(attack: any) {
    return apiFetch('/attacks', {
      method: 'POST',
      body: JSON.stringify(attack),
    });
  },
};

/**
 * Threats API
 */
export const ThreatsAPI = {
  /**
   * Get threat feed
   */
  async getFeed(limit?: number) {
    const query = limit ? `?limit=${limit}` : '';
    return apiFetch<{
      success: boolean;
      threats: Array<{
        id: string;
        type: string;
        severity: string;
        source: string;
        target: string;
        timestamp: string;
        status: string;
      }>;
    }>(`/threats${query}`);
  },

  /**
   * Get threat statistics
   */
  async getStats() {
    return apiFetch<{
      success: boolean;
      stats: {
        total: number;
        active: number;
        blocked: number;
        critical: number;
      };
    }>('/threats/stats');
  },
};

/**
 * Health check
 */
export const HealthAPI = {
  async check() {
    return apiFetch<{
      status: string;
      timestamp: string;
      database: string;
      version: string;
    }>('/health');
  },
};

// Export API error for error handling
export { ApiError };
