/**
 * Mock Backend - Simulates Node + TypeScript + MongoDB + TOTP 2FA
 * This simulates a real backend API with authentication, 2FA, and honeypot data
 */

import { TOTP } from './totp';

// Simulated MongoDB User Schema
interface User {
  _id: string;
  username: string;
  email: string;
  passwordHash: string;
  totpSecret?: string;
  twoFactorEnabled: boolean;
  emailOtpSecret?: string;
  emailOtpExpiry?: number;
  createdAt: Date;
  lastLogin?: Date;
  isHoneypot?: boolean; // Flag to mark fake honeypot accounts
}

// Simulated Session
interface Session {
  userId: string;
  token: string;
  createdAt: Date;
  expiresAt: Date;
  verified2FA: boolean;
}

// In-memory "database" (simulates MongoDB)
class MockDatabase {
  private users: Map<string, User> = new Map();
  private sessions: Map<string, Session> = new Map();
  
  constructor() {
    this.seedFakeData();
  }

  // Seed fake honeypot data to mislead attackers
  private seedFakeData() {
    const fakeUsers: Partial<User>[] = [
      // Admin accounts (honeypots)
      {
        username: 'admin',
        email: 'admin@cyberdefense.local',
        passwordHash: this.hashPassword('admin123'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      {
        username: 'administrator',
        email: 'administrator@cyberdefense.local',
        passwordHash: this.hashPassword('password'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      {
        username: 'root',
        email: 'root@cyberdefense.local',
        passwordHash: this.hashPassword('root'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      // Developer accounts (honeypots)
      {
        username: 'developer',
        email: 'dev@cyberdefense.local',
        passwordHash: this.hashPassword('dev123'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      {
        username: 'testuser',
        email: 'test@cyberdefense.local',
        passwordHash: this.hashPassword('test123'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      // Service accounts (honeypots)
      {
        username: 'backup',
        email: 'backup@cyberdefense.local',
        passwordHash: this.hashPassword('backup2024'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      {
        username: 'monitoring',
        email: 'monitor@cyberdefense.local',
        passwordHash: this.hashPassword('monitor123'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      // Weak password accounts (honeypots)
      {
        username: 'user',
        email: 'user@cyberdefense.local',
        passwordHash: this.hashPassword('password123'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
      {
        username: 'guest',
        email: 'guest@cyberdefense.local',
        passwordHash: this.hashPassword('guest'),
        twoFactorEnabled: false,
        isHoneypot: true,
      },
    ];

    // Create fake users
    fakeUsers.forEach((userData) => {
      const user: User = {
        _id: this.generateId(),
        username: userData.username!,
        email: userData.email!,
        passwordHash: userData.passwordHash!,
        twoFactorEnabled: userData.twoFactorEnabled!,
        createdAt: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000), // Random date in past year
        isHoneypot: userData.isHoneypot,
      };
      this.users.set(user.username.toLowerCase(), user);
    });

    console.log('🍯 Honeypot Database Seeded:', this.users.size, 'fake accounts created');
  }

  // Simple hash function (in real backend, use bcrypt)
  private hashPassword(password: string): string {
    // Simple simulation - in real backend use bcrypt
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return 'hash_' + Math.abs(hash).toString(16);
  }

  private generateId(): string {
    return 'usr_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  }

  private generateToken(): string {
    return 'tok_' + Math.random().toString(36).substr(2, 16) + Date.now().toString(36);
  }

  // Create user
  async createUser(username: string, email: string, password: string, totpSecret?: string): Promise<User> {
    if (this.users.has(username.toLowerCase())) {
      throw new Error('Username already exists');
    }

    const user: User = {
      _id: this.generateId(),
      username,
      email,
      passwordHash: this.hashPassword(password),
      totpSecret: totpSecret,
      twoFactorEnabled: !!totpSecret, // Enable 2FA if secret is provided
      createdAt: new Date(),
    };

    this.users.set(username.toLowerCase(), user);
    return user;
  }

  // Find user by username
  async findUserByUsername(username: string): Promise<User | null> {
    return this.users.get(username.toLowerCase()) || null;
  }

  // Verify password
  verifyPassword(user: User, password: string): boolean {
    return user.passwordHash === this.hashPassword(password);
  }

  // Enable 2FA for user
  async enable2FA(userId: string, totpSecret: string): Promise<void> {
    for (const [key, user] of this.users.entries()) {
      if (user._id === userId) {
        user.totpSecret = totpSecret;
        user.twoFactorEnabled = true;
        this.users.set(key, user);
        return;
      }
    }
  }

  // Generate email OTP (fallback 2FA)
  async generateEmailOTP(userId: string): Promise<string> {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    
    for (const [key, user] of this.users.entries()) {
      if (user._id === userId) {
        user.emailOtpSecret = otp;
        user.emailOtpExpiry = Date.now() + 5 * 60 * 1000; // 5 minutes
        this.users.set(key, user);
        
        // Simulate email sending
        console.log(`📧 Email OTP sent to ${user.email}: ${otp}`);
        return otp;
      }
    }
    
    throw new Error('User not found');
  }

  // Verify email OTP
  verifyEmailOTP(user: User, otp: string): boolean {
    if (!user.emailOtpSecret || !user.emailOtpExpiry) {
      return false;
    }
    
    if (Date.now() > user.emailOtpExpiry) {
      return false; // Expired
    }
    
    return user.emailOtpSecret === otp;
  }

  // Create session
  async createSession(userId: string, verified2FA: boolean = false): Promise<Session> {
    const session: Session = {
      userId,
      token: this.generateToken(),
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      verified2FA,
    };

    this.sessions.set(session.token, session);
    
    // Update last login
    for (const [key, user] of this.users.entries()) {
      if (user._id === userId) {
        user.lastLogin = new Date();
        this.users.set(key, user);
        break;
      }
    }

    return session;
  }

  // Get session
  async getSession(token: string): Promise<Session | null> {
    const session = this.sessions.get(token);
    if (!session) return null;
    
    if (new Date() > session.expiresAt) {
      this.sessions.delete(token);
      return null;
    }
    
    return session;
  }

  // Update session 2FA status
  async updateSession2FA(token: string): Promise<void> {
    const session = this.sessions.get(token);
    if (session) {
      session.verified2FA = true;
      this.sessions.set(token, session);
    }
  }

  // Delete session (logout)
  async deleteSession(token: string): Promise<void> {
    this.sessions.delete(token);
  }

  // Log honeypot access attempt
  logHoneypotAccess(username: string, success: boolean) {
    const user = this.users.get(username.toLowerCase());
    if (user?.isHoneypot) {
      console.log('🚨 HONEYPOT TRIGGERED!', {
        username,
        timestamp: new Date().toISOString(),
        success,
        alert: 'Potential attacker detected - accessing fake account',
      });
      
      // In real system, this would:
      // - Log to SIEM
      // - Alert security team
      // - Track attacker IP/fingerprint
      // - Potentially deploy additional honeypots
    }
  }
}

// Singleton database instance
const db = new MockDatabase();

/**
 * Mock Backend API
 */
export const MockBackendAPI = {
  // Register new user
  async register(username: string, email: string, password: string) {
    await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
    
    try {
      // Generate TOTP secret for new user (before creating user)
      const totpSecret = TOTP.generateSecret();
      
      // Create user with TOTP secret (2FA will be enabled after verification)
      const user = await db.createUser(username, email, password, totpSecret);
      const qrCode = TOTP.generateQRCode(user.email, totpSecret);
      
      return {
        success: true,
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
        },
        totp: {
          secret: totpSecret,
          qrCode,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: (error as Error).message,
      };
    }
  },

  // Login (step 1 - credentials)
  async login(username: string, password: string) {
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
    
    const user = await db.findUserByUsername(username);
    
    if (!user) {
      db.logHoneypotAccess(username, false);
      return {
        success: false,
        error: 'Invalid username or password',
      };
    }

    if (!db.verifyPassword(user, password)) {
      db.logHoneypotAccess(username, false);
      return {
        success: false,
        error: 'Invalid username or password',
      };
    }

    // Log successful honeypot access
    db.logHoneypotAccess(username, true);

    // Create session (not verified yet if 2FA enabled)
    const session = await db.createSession(user._id, !user.twoFactorEnabled);

    return {
      success: true,
      requires2FA: user.twoFactorEnabled,
      token: session.token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        twoFactorEnabled: user.twoFactorEnabled,
      },
    };
  },

  // Verify TOTP token
  async verify2FA(token: string, totpCode: string) {
    await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
    
    const session = await db.getSession(token);
    if (!session) {
      return {
        success: false,
        error: 'Invalid session',
      };
    }

    const user = await db.findUserByUsername(''); // Get user by ID
    let foundUser: User | null = null;
    for (const [, u] of (db as any).users.entries()) {
      if (u._id === session.userId) {
        foundUser = u;
        break;
      }
    }

    if (!foundUser || !foundUser.totpSecret) {
      return {
        success: false,
        error: '2FA not configured',
      };
    }

    const isValid = await TOTP.verify(totpCode, foundUser.totpSecret);
    
    if (!isValid) {
      return {
        success: false,
        error: 'Invalid 2FA code',
      };
    }

    // Update session
    await db.updateSession2FA(token);

    return {
      success: true,
      message: '2FA verified successfully',
    };
  },

  // Request email OTP (fallback 2FA)
  async requestEmailOTP(token: string) {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const session = await db.getSession(token);
    if (!session) {
      return {
        success: false,
        error: 'Invalid session',
      };
    }

    try {
      const otp = await db.generateEmailOTP(session.userId);
      
      return {
        success: true,
        message: 'OTP sent to your email',
        // In demo mode, return the OTP (remove in production!)
        demoOTP: otp,
      };
    } catch (error) {
      return {
        success: false,
        error: (error as Error).message,
      };
    }
  },

  // Verify email OTP
  async verifyEmailOTP(token: string, otp: string) {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const session = await db.getSession(token);
    if (!session) {
      return {
        success: false,
        error: 'Invalid session',
      };
    }

    let foundUser: User | null = null;
    for (const [, u] of (db as any).users.entries()) {
      if (u._id === session.userId) {
        foundUser = u;
        break;
      }
    }

    if (!foundUser) {
      return {
        success: false,
        error: 'User not found',
      };
    }

    const isValid = db.verifyEmailOTP(foundUser, otp);
    
    if (!isValid) {
      return {
        success: false,
        error: 'Invalid or expired OTP',
      };
    }

    // Update session
    await db.updateSession2FA(token);

    return {
      success: true,
      message: 'Email OTP verified successfully',
    };
  },

  // Get current user (validate session)
  async getCurrentUser(token: string) {
    const session = await db.getSession(token);
    if (!session || !session.verified2FA) {
      return {
        success: false,
        error: 'Not authenticated',
      };
    }

    let foundUser: User | null = null;
    for (const [, u] of (db as any).users.entries()) {
      if (u._id === session.userId) {
        foundUser = u;
        break;
      }
    }

    if (!foundUser) {
      return {
        success: false,
        error: 'User not found',
      };
    }

    return {
      success: true,
      user: {
        id: foundUser._id,
        username: foundUser.username,
        email: foundUser.email,
        twoFactorEnabled: foundUser.twoFactorEnabled,
        lastLogin: foundUser.lastLogin,
      },
    };
  },

  // Logout
  async logout(token: string) {
    await db.deleteSession(token);
    return {
      success: true,
      message: 'Logged out successfully',
    };
  },

  // Enable 2FA for existing user
  async enable2FA(token: string) {
    const session = await db.getSession(token);
    if (!session) {
      return {
        success: false,
        error: 'Not authenticated',
      };
    }

    const totpSecret = TOTP.generateSecret();
    await db.enable2FA(session.userId, totpSecret);

    let userEmail = '';
    for (const [, u] of (db as any).users.entries()) {
      if (u._id === session.userId) {
        userEmail = u.email;
        break;
      }
    }

    const qrCode = TOTP.generateQRCode(userEmail, totpSecret);

    return {
      success: true,
      totp: {
        secret: totpSecret,
        qrCode,
      },
    };
  },

  // Get honeypot statistics
  async getHoneypotStats() {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const totalUsers = (db as any).users.size;
    let honeypotCount = 0;
    
    for (const [, user] of (db as any).users.entries()) {
      if (user.isHoneypot) honeypotCount++;
    }

    return {
      success: true,
      stats: {
        totalAccounts: totalUsers,
        honeypotAccounts: honeypotCount,
        realAccounts: totalUsers - honeypotCount,
        honeypotTypes: {
          admin: 3,
          developer: 2,
          service: 2,
          weakPassword: 2,
        },
      },
    };
  },
};

// Store session token in localStorage
export const SessionStorage = {
  setToken(token: string) {
    localStorage.setItem('honeypot_session_token', token);
  },

  getToken(): string | null {
    return localStorage.getItem('honeypot_session_token');
  },

  clearToken() {
    localStorage.removeItem('honeypot_session_token');
  },
};
