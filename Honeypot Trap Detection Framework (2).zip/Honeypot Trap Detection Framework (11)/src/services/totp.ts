/**
 * TOTP (Time-based One-Time Password) Implementation
 * Simulates speakeasy functionality for 2FA
 */

// Simple base32 encoding/decoding
const BASE32_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(buffer: Uint8Array): string {
  let bits = 0;
  let value = 0;
  let output = '';

  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;

    while (bits >= 5) {
      output += BASE32_CHARS[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }

  if (bits > 0) {
    output += BASE32_CHARS[(value << (5 - bits)) & 31];
  }

  return output;
}

function base32Decode(input: string): Uint8Array {
  try {
    const cleanedInput = input.toUpperCase().replace(/=+$/, '').replace(/\s/g, '');
    console.log('[base32Decode] Input:', input.substring(0, 8) + '...', 'Length:', input.length);
    console.log('[base32Decode] Cleaned:', cleanedInput.substring(0, 8) + '...', 'Length:', cleanedInput.length);
    
    const output: number[] = [];
    let bits = 0;
    let value = 0;

    for (let i = 0; i < cleanedInput.length; i++) {
      const idx = BASE32_CHARS.indexOf(cleanedInput[i]);
      if (idx === -1) {
        console.warn('[base32Decode] Invalid character at position', i, ':', cleanedInput[i]);
        continue;
      }

      value = (value << 5) | idx;
      bits += 5;

      if (bits >= 8) {
        output.push((value >>> (bits - 8)) & 255);
        bits -= 8;
      }
    }

    console.log('[base32Decode] Output length:', output.length);
    return new Uint8Array(output);
  } catch (error) {
    console.error('[base32Decode] ERROR:', error);
    throw error;
  }
}

// HMAC-SHA1 implementation (simplified)
async function hmacSha1(key: Uint8Array, message: Uint8Array): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    key,
    { name: 'HMAC', hash: 'SHA-1' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign('HMAC', cryptoKey, message);
  return new Uint8Array(signature);
}

// Dynamic truncation
function dynamicTruncate(hmac: Uint8Array): number {
  const offset = hmac[hmac.length - 1] & 0x0f;
  return (
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff)
  );
}

/**
 * TOTP Service
 */
export const TOTP = {
  // Generate a random secret
  generateSecret(): string {
    const buffer = new Uint8Array(20);
    crypto.getRandomValues(buffer);
    return base32Encode(buffer);
  },

  // Generate TOTP token
  async generate(secret: string, time?: number): Promise<string> {
    try {
      const epoch = Math.floor((time || Date.now()) / 1000);
      const timeCounter = Math.floor(epoch / 30); // 30-second window

      console.log('[TOTP.generate] Epoch:', epoch, 'Counter:', timeCounter);

      // Convert counter to 8-byte buffer
      const buffer = new ArrayBuffer(8);
      const view = new DataView(buffer);
      view.setUint32(4, timeCounter, false);

      const key = base32Decode(secret);
      console.log('[TOTP.generate] Decoded key length:', key.length);
      
      const hmac = await hmacSha1(key, new Uint8Array(buffer));
      const code = dynamicTruncate(hmac) % 1000000;

      const paddedCode = code.toString().padStart(6, '0');
      console.log('[TOTP.generate] Generated code:', paddedCode);

      return paddedCode;
    } catch (error) {
      console.error('[TOTP.generate] ERROR:', error);
      throw error;
    }
  },

  // Verify TOTP token
  async verify(token: string, secret: string, window: number = 1): Promise<boolean> {
    const now = Date.now();
    
    // Debug logging
    console.log('[TOTP] Verifying token:', token);
    console.log('[TOTP] Secret (first 8 chars):', secret.substring(0, 8) + '...');
    
    // Check current time and ±window periods (30 seconds each)
    for (let i = -window; i <= window; i++) {
      const time = now + i * 30000;
      const validToken = await this.generate(secret, time);
      
      console.log(`[TOTP] Window ${i}: Generated token:`, validToken);
      
      if (token === validToken) {
        console.log('[TOTP] ✅ Token verified successfully!');
        return true;
      }
    }

    console.log('[TOTP] ❌ Token verification failed - no match found');
    return false;
  },

  // Generate QR code URL for authenticator apps
  generateQRCode(email: string, secret: string): string {
    const issuer = 'Honeypot Defense Grid';
    const label = `${issuer}:${email}`;
    const otpauthUrl = `otpauth://totp/${encodeURIComponent(label)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}`;
    
    console.log('[TOTP.generateQRCode] Email:', email);
    console.log('[TOTP.generateQRCode] Secret:', secret);
    console.log('[TOTP.generateQRCode] OTPAuth URL:', otpauthUrl);
    
    // Generate QR code using a free service
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(otpauthUrl)}`;
    console.log('[TOTP.generateQRCode] QR URL:', qrUrl);
    
    return qrUrl;
  },

  // Generate a backup code (for when user loses device)
  generateBackupCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 16; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
      if ((i + 1) % 4 === 0 && i < 15) code += '-';
    }
    return code;
  },

  // DEBUG: Generate current valid token for a secret
  async getCurrentToken(secret: string): Promise<string> {
    return await this.generate(secret);
  },
};
