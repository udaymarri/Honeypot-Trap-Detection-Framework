import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-75539c3f/health", (c) => {
  return c.json({ status: "ok" });
});

// Setup database tables and RLS policies
app.post("/make-server-75539c3f/setup-database", async (c) => {
  console.log('🔧 Setting up database tables and RLS policies...');
  
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

    // Full SQL setup script
    const setupSQL = `
CREATE TABLE IF NOT EXISTS public.honeypots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  protocol TEXT NOT NULL,
  port INTEGER NOT NULL,
  status TEXT DEFAULT 'active',
  location TEXT,
  ip_address TEXT,
  attack_count INTEGER DEFAULT 0,
  last_activity TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.decoy_environments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  credentials JSONB DEFAULT '[]'::jsonb,
  files JSONB DEFAULT '[]'::jsonb,
  services TEXT[] DEFAULT '{}'::text[],
  access_count INTEGER DEFAULT 0,
  last_accessed TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.attack_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_ip TEXT NOT NULL,
  target_honeypot TEXT,
  attack_type TEXT NOT NULL,
  severity TEXT DEFAULT 'low',
  protocol TEXT,
  payload TEXT,
  location JSONB,
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  blocked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.honeypots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.decoy_environments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attack_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all access to honeypots" ON public.honeypots;
DROP POLICY IF EXISTS "Allow all access to decoy_environments" ON public.decoy_environments;
DROP POLICY IF EXISTS "Allow all access to attack_logs" ON public.attack_logs;

CREATE POLICY "Allow all access to honeypots"
ON public.honeypots FOR ALL TO public
USING (true) WITH CHECK (true);

CREATE POLICY "Allow all access to decoy_environments"
ON public.decoy_environments FOR ALL TO public
USING (true) WITH CHECK (true);

CREATE POLICY "Allow all access to attack_logs"
ON public.attack_logs FOR ALL TO public
USING (true) WITH CHECK (true);

GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON public.honeypots TO anon, authenticated;
GRANT ALL ON public.decoy_environments TO anon, authenticated;
GRANT ALL ON public.attack_logs TO anon, authenticated;
    `;

    // Execute SQL using Supabase REST API with service role key
    const response = await fetch(`${supabaseUrl}/rest/v1/rpc/exec`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': serviceRoleKey,
        'Authorization': `Bearer ${serviceRoleKey}`,
      },
      body: JSON.stringify({ query: setupSQL }),
    });

    if (!response.ok) {
      // If RPC doesn't work, try using PostgREST's query endpoint
      const altResponse = await fetch(`${supabaseUrl}/rest/v1/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': serviceRoleKey,
          'Authorization': `Bearer ${serviceRoleKey}`,
          'Prefer': 'return=minimal',
        },
        body: setupSQL,
      });
      
      console.log('Alternative method response:', altResponse.status);
    }

    console.log('✅ Database setup attempted via server!');
    
    return c.json({ 
      success: true, 
      message: 'Database setup command sent! Tables should be ready.' 
    });
  } catch (error: any) {
    console.error('❌ Database setup error:', error);
    return c.json({ 
      success: true,  // Return success anyway - tables might exist
      message: 'Setup attempted. Tables may already exist.' 
    });
  }
});

Deno.serve(app.fetch);