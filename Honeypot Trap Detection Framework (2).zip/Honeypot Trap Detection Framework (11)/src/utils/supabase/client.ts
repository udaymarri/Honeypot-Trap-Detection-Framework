import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

/**
 * Supabase Client for Honeypot Defense Grid
 * Handles all database operations and authentication
 */

const supabaseUrl = `https://${projectId}.supabase.co`;

export const supabase = createClient(supabaseUrl, publicAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Database types for TypeScript
export interface User {
  id: string;
  email: string;
  username: string;
  role: string;
  totp_secret?: string;
  is_2fa_verified: boolean;
  created_at: string;
}

export interface Honeypot {
  id: string;
  name: string;
  type: string;
  protocol: string;
  port: number;
  status: string;
  location: string;
  ip_address: string;
  attack_count: number;
  last_activity: string;
  created_at: string;
}

export interface DecoyEnvironment {
  id: string;
  name: string;
  type: string;
  status: string;
  credentials: Array<{
    username: string;
    password: string;
    access_level: string;
  }>;
  files: Array<{
    name: string;
    type: string;
    size: string;
    path: string;
    is_bait: boolean;
  }>;
  services: string[];
  access_count: number;
  last_accessed: string;
  created_at: string;
}

export interface AttackLog {
  id: string;
  source_ip: string;
  target_honeypot: string;
  attack_type: string;
  severity: string;
  protocol: string;
  payload: string;
  location: {
    country: string;
    city: string;
    lat: number;
    lon: number;
  };
  timestamp: string;
  blocked: boolean;
  created_at: string;
}
