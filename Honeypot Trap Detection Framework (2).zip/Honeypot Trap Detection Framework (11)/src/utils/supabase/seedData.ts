/**
 * Supabase Database Seeder
 * Populates database with fake honeypot data to mislead attackers
 */

import { supabase } from './client';

// Fake honeypots data
const fakeHoneypots = [
  {
    name: 'SSH Honeypot - Production Server',
    type: 'SSH',
    protocol: 'ssh',
    port: 22,
    status: 'active',
    location: 'US-East-1',
    ip_address: '192.168.1.100',
    attack_count: 1247,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
  {
    name: 'HTTP Server - Web Portal',
    type: 'HTTP',
    protocol: 'http',
    port: 80,
    status: 'active',
    location: 'EU-West-2',
    ip_address: '192.168.1.101',
    attack_count: 2891,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
  {
    name: 'FTP Server - File Storage',
    type: 'FTP',
    protocol: 'ftp',
    port: 21,
    status: 'active',
    location: 'Asia-Pacific-1',
    ip_address: '192.168.1.102',
    attack_count: 567,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
  {
    name: 'SMTP Mail Server',
    type: 'SMTP',
    protocol: 'smtp',
    port: 25,
    status: 'active',
    location: 'US-West-1',
    ip_address: '192.168.1.103',
    attack_count: 934,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
  {
    name: 'MySQL Database Server',
    type: 'Database',
    protocol: 'mysql',
    port: 3306,
    status: 'active',
    location: 'EU-Central-1',
    ip_address: '192.168.1.104',
    attack_count: 1823,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
  {
    name: 'RDP Windows Server',
    type: 'RDP',
    protocol: 'rdp',
    port: 3389,
    status: 'active',
    location: 'US-East-2',
    ip_address: '192.168.1.105',
    attack_count: 445,
    last_activity: new Date(Date.now() - Math.random() * 3600000).toISOString(),
  },
];

// Fake decoy environments
const fakeDecoyEnvironments = [
  {
    name: 'Production Database - Customer Records',
    type: 'database',
    status: 'active',
    credentials: [
      { username: 'admin', password: 'admin123', access_level: 'root' },
      { username: 'dbuser', password: 'database2024', access_level: 'read-write' },
      { username: 'backup_user', password: 'backup@123', access_level: 'read-only' },
    ],
    files: [
      {
        name: 'customers.sql',
        type: 'database',
        size: '2.4 GB',
        path: '/var/db/backups/',
        is_bait: true,
      },
      {
        name: 'financial_records.csv',
        type: 'csv',
        size: '156 MB',
        path: '/var/db/exports/',
        is_bait: true,
      },
      {
        name: 'user_passwords.txt',
        type: 'text',
        size: '45 KB',
        path: '/tmp/',
        is_bait: true,
      },
    ],
    services: ['mysql', 'postgresql', 'redis'],
    access_count: 34,
    last_accessed: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  },
  {
    name: 'Corporate File Server',
    type: 'fileserver',
    status: 'active',
    credentials: [
      { username: 'administrator', password: 'Password123!', access_level: 'admin' },
      { username: 'fileadmin', password: 'files2024', access_level: 'read-write' },
    ],
    files: [
      {
        name: 'company_secrets.docx',
        type: 'document',
        size: '234 KB',
        path: '/shares/confidential/',
        is_bait: true,
      },
      {
        name: 'salary_data_2024.xlsx',
        type: 'spreadsheet',
        size: '89 KB',
        path: '/shares/hr/',
        is_bait: true,
      },
      {
        name: 'api_keys.json',
        type: 'json',
        size: '12 KB',
        path: '/shares/dev/',
        is_bait: true,
      },
    ],
    services: ['smb', 'ftp', 'sftp'],
    access_count: 67,
    last_accessed: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  },
  {
    name: 'Development Git Repository',
    type: 'repository',
    status: 'active',
    credentials: [
      { username: 'git', password: 'gitpassword', access_level: 'read-write' },
      { username: 'developer', password: 'dev@2024', access_level: 'contributor' },
    ],
    files: [
      {
        name: '.env',
        type: 'environment',
        size: '2 KB',
        path: '/repos/main/',
        is_bait: true,
      },
      {
        name: 'config.production.js',
        type: 'javascript',
        size: '8 KB',
        path: '/repos/main/config/',
        is_bait: true,
      },
      {
        name: 'aws_credentials.txt',
        type: 'text',
        size: '1 KB',
        path: '/repos/main/.aws/',
        is_bait: true,
      },
    ],
    services: ['git', 'ssh'],
    access_count: 23,
    last_accessed: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  },
  {
    name: 'Email Server - Exchange',
    type: 'email',
    status: 'active',
    credentials: [
      { username: 'postmaster', password: 'mail123', access_level: 'admin' },
      { username: 'support@company.com', password: 'Support2024', access_level: 'user' },
    ],
    files: [
      {
        name: 'inbox_backup.pst',
        type: 'email',
        size: '1.2 GB',
        path: '/mail/backups/',
        is_bait: true,
      },
      {
        name: 'contacts.csv',
        type: 'csv',
        size: '234 KB',
        path: '/mail/exports/',
        is_bait: true,
      },
    ],
    services: ['smtp', 'imap', 'pop3'],
    access_count: 12,
    last_accessed: new Date(Date.now() - Math.random() * 86400000).toISOString(),
  },
];

// Attack types and metadata
const attackTypes = [
  'SQL Injection',
  'SSH Brute Force',
  'Port Scan',
  'DDoS',
  'Malware Upload',
  'XSS',
  'RCE Attempt',
];
const severities = ['critical', 'high', 'medium', 'low'];
const countries = [
  { country: 'China', city: 'Beijing', lat: 39.9042, lon: 116.4074 },
  { country: 'Russia', city: 'Moscow', lat: 55.7558, lon: 37.6173 },
  { country: 'USA', city: 'New York', lat: 40.7128, lon: -74.006 },
  { country: 'Brazil', city: 'São Paulo', lat: -23.5505, lon: -46.6333 },
  { country: 'India', city: 'Mumbai', lat: 19.076, lon: 72.8777 },
  { country: 'Germany', city: 'Berlin', lat: 52.52, lon: 13.405 },
  { country: 'UK', city: 'London', lat: 51.5074, lon: -0.1278 },
  { country: 'Japan', city: 'Tokyo', lat: 35.6762, lon: 139.6503 },
];

/**
 * Generate fake attack logs
 */
function generateFakeAttacks(count: number = 200) {
  const attacks = [];

  for (let i = 0; i < count; i++) {
    const location = countries[Math.floor(Math.random() * countries.length)];
    const attackType = attackTypes[Math.floor(Math.random() * attackTypes.length)];
    const severity = severities[Math.floor(Math.random() * severities.length)];

    attacks.push({
      source_ip: `${Math.floor(Math.random() * 256)}.${Math.floor(
        Math.random() * 256
      )}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
      target_honeypot: fakeHoneypots[Math.floor(Math.random() * fakeHoneypots.length)].name,
      attack_type: attackType,
      severity,
      protocol: ['tcp', 'udp', 'http', 'ssh'][Math.floor(Math.random() * 4)],
      payload: `${attackType} detected at ${new Date().toISOString()}`,
      location: {
        country: location.country,
        city: location.city,
        lat: location.lat,
        lon: location.lon,
      },
      timestamp: new Date(
        Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000
      ).toISOString(), // Last 7 days
      blocked: Math.random() > 0.3, // 70% blocked
    });
  }

  return attacks;
}

/**
 * Seed the Supabase database
 */
export async function seedDatabase() {
  console.log('🌱 Starting Supabase database seed...\n');

  try {
    // Step 1: Verify tables are accessible by trying to read from them
    console.log('🔍 Verifying table access...');
    const { data: testRead, error: testError } = await supabase
      .from('honeypots')
      .select('id')
      .limit(1);
    
    if (testError) {
      console.error('❌ Cannot access tables:', testError);
      
      // Give clear instructions with link to SQL file
      throw new Error(
        '🚨 TABLES NOT FOUND!\n\n' +
        '📋 FIX IN 2 MINUTES:\n\n' +
        '1. Go to: https://supabase.com/dashboard\n' +
        '2. Click your project → "SQL Editor"\n' +
        '3. Click "+ New Query"\n' +
        '4. Open file: ALL_IN_ONE_FIX.sql\n' +
        '5. Copy ALL the SQL\n' +
        '6. Paste in Supabase and click "Run"\n' +
        '7. Wait for "Success" message\n' +
        '8. Come back and click "Seed Database"\n\n' +
        '✅ Then seeding will work!'
      );
    }
    console.log('✅ Tables are accessible\n');

    // Step 2: Clear existing data
    console.log('🗑️  Clearing existing data...');
    await supabase.from('honeypots').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    await supabase
      .from('decoy_environments')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    await supabase
      .from('attack_logs')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    console.log('✅ Cleared old data\n');

    // Insert honeypots
    console.log('📡 Inserting honeypots...');
    const { data: honeypots, error: honeypotsError } = await supabase
      .from('honeypots')
      .insert(fakeHoneypots)
      .select();

    if (honeypotsError) throw honeypotsError;
    console.log(`✅ Inserted ${honeypots?.length || 0} honeypots\n`);

    // Insert decoy environments
    console.log('🎭 Inserting decoy environments...');
    const { data: decoys, error: decoysError } = await supabase
      .from('decoy_environments')
      .insert(fakeDecoyEnvironments)
      .select();

    if (decoysError) throw decoysError;
    console.log(`✅ Inserted ${decoys?.length || 0} decoy environments\n`);

    // Generate and insert fake attacks
    console.log('⚔️  Generating fake attack logs...');
    const attacks = generateFakeAttacks(200);
    const { data: attackLogs, error: attacksError } = await supabase
      .from('attack_logs')
      .insert(attacks)
      .select();

    if (attacksError) throw attacksError;
    console.log(`✅ Inserted ${attackLogs?.length || 0} attack logs\n`);

    // Summary
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✨ Database seeding completed!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(
      `📊 Total Records: ${
        (honeypots?.length || 0) + (decoys?.length || 0) + (attackLogs?.length || 0)
      }`
    );
    console.log(`   • Honeypots: ${honeypots?.length || 0}`);
    console.log(`   • Decoy Environments: ${decoys?.length || 0}`);
    console.log(`   • Attack Logs: ${attackLogs?.length || 0}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    // Display sample data
    console.log('📋 Sample Decoy Credentials (for testing):');
    decoys?.slice(0, 2).forEach((decoy: any, i: number) => {
      console.log(`\n   ${i + 1}. ${decoy.name}:`);
      decoy.credentials.forEach((cred: any) => {
        console.log(`      - ${cred.username} / ${cred.password} (${cred.access_level})`);
      });
    });
    console.log('\n');

    return {
      success: true,
      honeypots: honeypots?.length || 0,
      decoys: decoys?.length || 0,
      attacks: attackLogs?.length || 0,
    };
  } catch (error: any) {
    console.error('❌ Seeding error:', error);
    throw error;
  }
}
